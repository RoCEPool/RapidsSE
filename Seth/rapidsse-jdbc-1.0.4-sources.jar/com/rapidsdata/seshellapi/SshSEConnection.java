// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.*;

public class SshSEConnection implements SEConnection
{
  /* System property keys */
  private static final String KNOWN_HOSTS = "knownhosts";
  private static final String SSH_ACCEPT_ALL_FINGERPRINTS = "acceptsshfingerprints";
  private static final String SSH_CONNECT_TIMEOUT_MS = "sshconnecttimeoutms";


  private static final String DEFAULT_KNOWN_HOSTS = "~/.ssh/known_hosts";
  private static final String DEFAULT_SSH_ACCEPT_ALL_FINGERPRINTS = "true";
  private static final String DEFAULT_SSH_CONNECT_TIMEOUT_MS = "3000";
  private static final String DEFAULT_IDENTITY_FILE = "~/.ssh/id_rsa";

  private final String host;
  private final String user;
  private final short port;
  private final String identityPath;

  private final String exePath;
  private final String[] args;

  private Session session;
  private ChannelExec channel;


  /**
   * Contructor
   * @param host the hostname or IP address to connect to.
   * @param exePath the path to the se-shell executable.
   * @param args an array of arguments to the se-shell executable. Can be null.
   * @throws IOException if there is an error locating or executing the se-shell.
   */
  public SshSEConnection(String host, String exePath, String[] args) throws IOException, JSchException
  {
    this.host = host;
    this.user = null;
    this.port = 22;
    this.identityPath = DEFAULT_IDENTITY_FILE;
    this.exePath = exePath;
    this.args = args;

    connectSession();
  }

  /**
   * Contructor
   * @param user the username to ssh as. Can be null.
   * @param host the hostname or IP address to connect to. Not null.
   * @param port the port number to ssh to.
   * @param identityPath the path to the identity file containing the user's ssh private key. Can be null.
   * @param exePath the path to the se-shell executable. Not null.
   * @param args an array of arguments to the se-shell executable. Can be null.
   * @throws IOException if there is an error locating or executing the se-shell.
   */
  public SshSEConnection(String user, String host, short port, String identityPath,
                         String exePath, String[] args) throws IOException, JSchException
  {
    this.host = host;
    this.user = user;
    this.port = (port <= 0 ? 22 : port);
    this.identityPath = (identityPath != null ? identityPath : DEFAULT_IDENTITY_FILE);
    this.exePath = exePath;
    this.args = args;

    connectSession();

    checkFileExists();

    executeCommand();
  }

  /**
   * Creates an SSH session to the remote host.
   * @throws JSchException
   */
  private void connectSession() throws JSchException
  {
    JSch jsch = new JSch();

    // Unfortunately, if we don't set the location of the known_hosts then we will
    // get a HostKeyMisMatch exception when we connect the session. If we run this code
    // on a non Linux/Mac operating system then this location will probably be different.
    jsch.setKnownHosts(System.getProperty(KNOWN_HOSTS, DEFAULT_KNOWN_HOSTS));

    jsch.addIdentity(identityPath);

    session = jsch.getSession(user, this.host, port);

    final boolean sshAcceptAllHostFingerprints =
        Boolean.valueOf(System.getProperty(SSH_ACCEPT_ALL_FINGERPRINTS,
            DEFAULT_SSH_ACCEPT_ALL_FINGERPRINTS));

    if (sshAcceptAllHostFingerprints) {
      session.setConfig("StrictHostKeyChecking", "no");
    }

    // Authenticate using a public key only.
    // This removes the other defaults of "gssapi-with-mic" and "keyboard-interactive" and password.
    session.setConfig("PreferredAuthentications", "publickey");

    int timeout = Integer.valueOf(System.getProperty(SSH_CONNECT_TIMEOUT_MS,
        DEFAULT_SSH_CONNECT_TIMEOUT_MS));

    session.connect(timeout);
  }

  /**
   * Checks that the file we wish to execute actually exists on the remote host.
   * @throws JSchException
   * @throws FileNotFoundException if the file does not exist.
   */
  private void checkFileExists() throws JSchException, FileNotFoundException
  {
    try {
      channel = (ChannelExec) session.openChannel("exec");
      channel.setCommand("ls " + exePath);

      int timeout = Integer.valueOf(System.getProperty(SSH_CONNECT_TIMEOUT_MS,
          DEFAULT_SSH_CONNECT_TIMEOUT_MS));

      // Use a channel timeout because it will wait to a reply before returning.
      // Otherwise it will send the command to be executed but reply before any
      // message comes back.
      channel.connect(timeout);

      // Before we can get the exit status, we need to wait for the channel
      // to close (refer to the docs of JSch).
      while (!channel.isClosed()) {
        try { Thread.sleep(0); } catch (InterruptedException e) {/*ignore*/}
      }

      int exitStatus = channel.getExitStatus();
      if (exitStatus != 0) {
        throw new FileNotFoundException("Could not find file " + exePath + " on host " + host);
      }

    } finally {
      if (channel != null) {
        channel.disconnect();
      }

      channel = null;
    }
  }

  /**
   * Executes the command on the remote host.
   * @throws JSchException
   */
  private void executeCommand() throws JSchException
  {
    channel = (ChannelExec) session.openChannel("exec");
    channel.setCommand(buildCommand());

    int timeout = Integer.valueOf(System.getProperty(SSH_CONNECT_TIMEOUT_MS,
        DEFAULT_SSH_CONNECT_TIMEOUT_MS));

    // Use a channel timeout because it will wait to a reply before returning.
    // Otherwise it will send the command to be executed but reply before any
    // message comes back.
    channel.connect(timeout);
  }

  /**
   * Builds up a string containing the command and arguments we wish to execute.
   * @return a string containing the command and arguments we wish to execute.
   */
  private String buildCommand()
  {
    if (args == null) {
      return exePath;
    }

    StringBuilder sb = new StringBuilder(1024);
    sb.append(exePath);

    for (String arg : args) {
      sb.append(" ");
      sb.append(arg);
    }

    return sb.toString();
  }

  /**
   * Returns true if the connection to the SE shell is alive, otherwise false.
   * @return Returns true if the connection to the SE shell is alive, otherwise false.
   */
  @Override
  public boolean isAlive()
  {
    return channel.isConnected();
  }

  /**
   * Returns the outputstream used to send commands to the SE shell's stdin via ssh.
   * @return the outputstream used to send commands to the SE shell's stdin via ssh.
   */
  @Override
  public OutputStream getShellStdin() throws IOException
  {
    return channel.getOutputStream();
  }

  /**
   * Returns the inputstream used to read output from the SE shell's stdout via ssh.
   * @return the inputstream used to read output from the SE shell's stdout via ssh.
   */
  @Override
  public InputStream getShellStdout() throws IOException
  {
    return channel.getInputStream();
  }

  /**
   * Returns the inputstream used to read output from the SE shell's stderr via ssh.
   * @return the inputstream used to read output from the SE shell's stderr via ssh.
   */
  @Override
  public InputStream getShellStderr() throws IOException
  {
    return channel.getErrStream();
  }

  /**
   * Closes this stream and releases any system resources associated
   * with it. If the stream is already closed then invoking this
   * method has no effect.
   * <p>
   * <p> As noted in {@link AutoCloseable#close()}, cases where the
   * close may fail require careful attention. It is strongly advised
   * to relinquish the underlying resources and to internally
   * <em>mark</em> the {@code Closeable} as closed, prior to throwing
   * the {@code IOException}.
   *
   * @throws IOException if an I/O error occurs
   */
  @Override
  public void close() throws IOException
  {
    IOException ioe = null;

    try {
      if (channel != null) {
        channel.getOutputStream().close();
        channel.getInputStream().close();
        channel.getErrStream().close();
      }
    } catch (IOException e) {
      // Save it and still try to disconnect the SSH session. Then throw it later on.
      ioe = e;
    }

    if (session != null) {
      session.disconnect();
      session = null;
    }

    if (ioe != null) {
      throw ioe;
    }
  }
}
