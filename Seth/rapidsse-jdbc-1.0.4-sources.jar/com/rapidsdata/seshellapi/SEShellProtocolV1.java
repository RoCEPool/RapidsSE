// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

import com.rapidsdata.seshellapi.exceptions.MoreDataRequiredException;
import com.rapidsdata.seshellapi.exceptions.SEProtocolException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Version 1 of the SE shell protocol. */
public class SEShellProtocolV1 implements SEProtocol
{
  private static final String ERROR_MARKER    = "error:";
  private static final String SUCCESS_MARKER  = "success:";
  private static final String METADATA_MARKER = "metadata:";
  private static final String ROW_MARKER      = "row:";

  private static final String DATE_WORD      = "date";
  private static final String TIME_WORD      = "time";
  private static final String TIMESTAMP_WORD = "timestamp";
  private static final String INTERVAL_WORD  = "interval";

  private static final String WHITESPACE_SEPARATORS = " \t"; // whitespace only.
  private static final String DEFAULT_SEPARATORS = WHITESPACE_SEPARATORS + ","; // whitespace and a comma.

  /** How we actually connect to the SE shell. */
  private final SEConnection connection;

  /** The stream for reading the SE Shell's stdout. */
  private final BufferedReader shellStdOut;

  /** The stream for reading the SE Shell's stderr. */
  private final BufferedReader shellStdErr;

  /** The stream for writing to the SE Shell's stdin. */
  private final BufferedWriter shellStdIn;

  /** The maximum number of rows that any command can return. Additional rows are silently dropped.
   * A value of 0 means no limit.  */
  private long maxRows = 0;


  /**
   * Constructor
   * @param connection how we talk to the SE Shell.
   */
  public SEShellProtocolV1(SEConnection connection) throws IOException, SEProtocolException
  {
    this.connection = connection;

    this.shellStdOut = new BufferedReader(new InputStreamReader(connection.getShellStdout()));
    this.shellStdErr = new BufferedReader(new InputStreamReader(connection.getShellStderr()));
    this.shellStdIn  = new BufferedWriter(new OutputStreamWriter(connection.getShellStdin()));

    String stderr = drainOutputFrom(shellStdErr);
    String stdout = drainOutputFrom(shellStdOut);

    if (!connection.isAlive()) {
      String msg = "SE Shell failed to start up.";

      if (!stderr.isEmpty()) {
        msg += " StdErr: " + stderr.trim();
      }

      if (!stdout.isEmpty()) {
        msg += " StdOut: " + stdout.trim();
      }

      throw new SEProtocolException(msg);
    }

    // Ignore any abberant startup messages on the shell's stdout.
  }

  /**
   * Executes a command via the se-shell and returns a result object.
   * @param command the command to be executed.
   * @return the result of executing this command.
   * @throws IOException         if there is a communications problem with se-shell.
   * @throws SEProtocolException if there is a problem understanding the SE output.
   * @throws InterruptedException if the thread has received an interrupted signal.
   */
  @Override
  public SEResult executeCommand(String command) throws IOException, SEProtocolException, InterruptedException
  {
    if (!connection.isAlive()) {
      String msg = "SE Shell has terminated.";

      String stderr = drainOutputFrom(shellStdErr);
      String stdout = drainOutputFrom(shellStdOut);

      if (!stderr.isEmpty()) {
        msg += " StdErr: " + stderr;
      }

      if (!stdout.isEmpty()) {
        msg += " StdOut: " + stdout;
      }

      throw new SEProtocolException(msg);
    }

    // Drain any leftover output on the shell's stdout or stderr.
    // Ignore output on stdout.
    drainOutputFrom(shellStdOut);

    String errOutput = drainOutputFrom(shellStdErr);

    if (!errOutput.trim().isEmpty()) {
      final String msg = "Error from SE Shell: " + errOutput;
      throw new SEProtocolException(msg);
    }

    // Write the command
    writeCommandTo(shellStdIn, command);

    // Create a result object
    SEResult result = new SEResult();

    // Wait for the response
    while (true) {
      String line = readLine();
      boolean isComplete = processLine(line, result);

      if (isComplete) {
        break;
      }
    }

    return result;
  }

  /**
   * Reads a line from SE and returns it.
   * @return the line read from SE.
   * @throws IOException         if there is a communications problem with se-shell.
   * @throws SEProtocolException if there is a problem understanding the SE output.
   * @throws InterruptedException if the thread has received an interrupted signal.
   */
  private String readLine() throws IOException, InterruptedException, SEProtocolException
  {
    while (!shellStdOut.ready() && !shellStdErr.ready() && connection.isAlive()) {
      Thread.sleep(10);
    }

    if (!connection.isAlive()) {
      final String msg = "Connection to SE has terminated.";
      throw new IOException(msg);
    }

    if (shellStdErr.ready()) {
      final String msg = "Error from SE Shell: " + drainOutputFrom(shellStdErr);
      throw new SEProtocolException(msg);
    }

    String line = shellStdOut.readLine();
    return line;
  }

  /**
   * Set the maximum number of rows that can be returned by a command. Any additional rows are
   * silently dropped.
   * @param maxRows The maximum number of rows that can be returned by a command. Value must
   *                be >= 0. A value of 0 means no limit.
   */
  @Override
  public void setMaxRows(long maxRows) throws SEProtocolException
  {
    if (maxRows < 0) {
      throw new SEProtocolException("Invalid value for maxRows. Must be >= 0.");
    }

    this.maxRows = maxRows;
  }

  /**
   * Returns the maximum number of rows that any command will return. Additional rows above
   * this value are silently dropped. A value of 0 means no limit.
   * @return the maximum number of rows that any command will return.
   */
  @Override
  public long getMaxRows()
  {
    return maxRows;
  }

  /**
   * Closes this stream and releases any system resources associated
   * with it. If the stream is already closed then invoking this
   * method has no effect.
   * <p>
   * <p> As noted in {@link AutoCloseable#close()}, cases where the
   * close may fail require careful attention. It is strongly advised
   * to relinquish the underlying resources and to internally
   * <em>mark</em> the {@code Closeable} as closed, prior to throwing
   * the {@code IOException}.
   *
   * @throws IOException if an I/O error occurs
   */
  @Override
  public void close() throws IOException
  {
    shellStdOut.close();
    shellStdErr.close();
    shellStdIn.close();
    connection.close();
  }

  /**
   * Reads all the available input from a given reader (corresponding to either the SE shell's
   * stdout or stderr) and returns it as a string.
   * @param reader The stream to read from.
   * @return All the currently available data on that stream.
   * @throws IOException if there is a problem communicating with the SE Shell.
   */
  private String drainOutputFrom(BufferedReader reader) throws IOException
  {
    if (!reader.ready()) {
      return "";
    }

    StringBuilder sb = new StringBuilder(1024);

    while (reader.ready()) {
      sb.append(reader.readLine());
      sb.append(System.lineSeparator());
    }

    return sb.toString();
  }

  /**
   * Writes a command to the SE shell's stdin.
   * @param writer the stream to write to.
   * @param command the command to write.
   * @throws IOException
   */
  private void writeCommandTo(BufferedWriter writer, String command) throws IOException
  {
    writer.write(command);

    // The new line is what the SE shell uses to process the input.
    if (!command.trim().endsWith(System.lineSeparator())) {
      writer.newLine();
    }

    writer.flush();
  }

  /**
   * Processes a line read back from the SE shell.
   * @param line the line just read from the SE shell's stdout.
   * @param result the result object we are populating.
   * @return true if the execution of this command is complete, or false if we are waiting on
   *         more data to read.
   */
  private boolean processLine(String line, SEResult result)
                             throws IOException, SEProtocolException, InterruptedException
  {
    if (line.startsWith(ERROR_MARKER)) {
      processError(line, result);
      return true;

    } else if (line.startsWith(SUCCESS_MARKER)) {
      processSuccess(line, result);
      return true;

    } else if (line.startsWith(METADATA_MARKER)) {
      processMetadata(line, result);

    } else if (line.startsWith(ROW_MARKER)) {
      if (maxRows == 0 || (result.getRows() != null && result.getRows().size() < maxRows)) {
        processRow(line, result);
      }
    }
    // otherwise ignore the line.

    // Result is not complete until we get a success or failure indicator.
    return false;
  }

  /**
   * Extracts out the error information from the line and sets it in the result.
   * @param line the line we read from the se shell.
   * @param result the result object we are trying to set.
   * @throws SEProtocolException if we cannot parse the line we read from the se shell.
   */
  private void processError(String line, SEResult result) throws SEProtocolException
  {
    String errorMsg = line.substring(ERROR_MARKER.length()).trim();
    result.setErrorMsg(errorMsg);
  }

  /**
   * Extracts out the affected row count from the line and sets it in the result, if applicable.
   * @param line the line we read from the se shell.
   * @param result the result object we are trying to set.
   * @throws SEProtocolException if we cannot parse the line we read from the se shell.
   */
  private void processSuccess(String line, SEResult result) throws SEProtocolException
  {
    // We don't need to set the status - if we got row metadata then it should already
    // be set to HAS_RESULT_SET. Otherwise it should default to HAS_AFFECTED_COUNT.

    String desc = line.substring(SUCCESS_MARKER.length()).trim();

    if (result.getStatus() == SEResult.Status.HAS_RESULT_SET) {
      // We don't set the affected count as this is used to indicate that a resultset
      // was not returned. The number of rows returned is easily gettable from
      // result.getRows().length(). No need to set this data twice.
      return;
    }

    // Extract out the first integer.
    Pattern pattern = Pattern.compile("\\s*(\\d+)\\s+rows\\s+\\w+.*");
    Matcher matcher = pattern.matcher(desc);

    if (!matcher.matches()) {
      final String msg = "Could not extract out the number of affected rows from the output: " + line;
      throw new SEProtocolException(msg);
    }

    String affectedRowsStr = matcher.group(1);

    try {
      result.setAffectedCount(Long.valueOf(affectedRowsStr));

    } catch (NumberFormatException e) {
      final String msg = "Could not convert the number of affected rows to an integer from the output: " + line;
      throw new SEProtocolException(msg);
    }
  }

  /**
   * Extracts out the row metadata from the line and sets it in the result.
   * @param line the line we read from the se shell.
   * @param result the result object we are trying to set.
   * @throws SEProtocolException if we cannot parse the line we read from the se shell.
   */
  private void processMetadata(String line, SEResult result) throws SEProtocolException
  {
    String trimmed = line.substring(METADATA_MARKER.length()).trim();

    if (!trimmed.startsWith("(") && !trimmed.endsWith(")")) {
      final String msg = "Invalid row metadata format encountered: \"" + line + "\"";
      throw new SEProtocolException(msg);
    }

    String columns = trimmed.substring(1, trimmed.length() - 1).trim();

    int columnsPos = -1;
    StringBuilder sb = new StringBuilder(1024);

    String columnName;
    String columnTypeStr;
    DataType columnType;
    int ordinal = 0;
    int precision;
    int scale;

    List<ColumnInfo> rowMetadata = new ArrayList<>();

    try {
      while (columnsPos < columns.length()) {

        ++ordinal;

        // Extract out the whole column string up to the next comma or EOF.
        columnsPos = getNextToken(columns, columnsPos, sb, ",");
        String columnStr = sb.toString().trim();

        // Now we go through all the information we have for this particular column.
        int colPos = -1;

        // We should be able to read a column name
        colPos = getNextToken(columnStr, colPos, sb, WHITESPACE_SEPARATORS);
        columnName = sb.toString().trim();

        if (columnName.isEmpty()) {
          final String msg = "Missing column name from the column metadata: " + line;
          throw new SEProtocolException(msg);
        }

        // We should be able to read more.
        if (colPos >= columnStr.length()) {
          final String msg = "Read a column name but not a column type from the column metadata: " + line;
          throw new SEProtocolException(msg);
        }

        // Read the data type.
        colPos = getNextToken(columnStr, colPos, sb, WHITESPACE_SEPARATORS);
        columnTypeStr = sb.toString().toUpperCase().trim();

        if (columnTypeStr.isEmpty()) {
          final String msg = "Missing column type from the column metadata: " + line;
          throw new SEProtocolException(msg);
        }

        // Does the columnTypeStr have precision and scale?
        precision = Integer.MIN_VALUE;
        scale = Integer.MIN_VALUE;

        int openParenIndex = columnTypeStr.indexOf('(');
        int closeParenIndex = columnTypeStr.lastIndexOf(')');

        if (openParenIndex != -1 && closeParenIndex != -1) {
          // Are the parentheses properly specified?
          if ((openParenIndex > closeParenIndex) || (closeParenIndex - openParenIndex == 1)) {
            final String msg = "Invalid specification of precision/scale encountered in column type: " + columnTypeStr;
            throw new SEProtocolException(msg);
          }

          // Extract out the string inside the parentheses.
          String insideParenStr = columnTypeStr.substring(openParenIndex + 1, closeParenIndex);

          String[] components = insideParenStr.split(",");

          if (components.length < 1 || components.length > 2) {
            final String msg = "Invalid specification of precision/scale encountered in column type: " + columnTypeStr;
            throw new SEProtocolException(msg);
          }

          // Get the precision. Should always exist.
          try {
            precision = Integer.valueOf(components[0].trim());

          } catch (NumberFormatException e) {
            final String msg = "Unable to decode precision integer from column type: " + columnTypeStr;
            throw new SEProtocolException(msg);
          }

          if (components.length == 2) {
            // Get the scale.
            try {
              scale = Integer.valueOf(components[1].trim());

            } catch (NumberFormatException e) {
              final String msg = "Unable to decode scale integer from column type: " + columnTypeStr;
              throw new SEProtocolException(msg);
            }
          }

          // Finally unadorn the columnTypeStr from its parentheses so we can decode it to an enum.
          columnTypeStr = columnTypeStr.substring(0, openParenIndex);
        }

        // Decode the type
        try {
          columnType = DataType.valueOf(columnTypeStr);
        } catch (IllegalArgumentException e) {
          final String msg = "Got an unsupported column type from the column metadata: " + columnTypeStr;
          throw new SEProtocolException(msg);
        }

        // Any extra adornments go here.
        // Look for NOT NULL
        Boolean isNullable = null; // unknown.

        if (colPos < columnStr.length()) {
          String adornments = columnStr.substring(colPos);

          if (adornments.matches(".*(NOT|not)\\s+(NULL|null).*")) {
            isNullable = false;
          } else if (adornments.matches(".*(NULL|null).*")) {
            isNullable = true;
          }
        }

        // Create the ColumnInfo object and add it to the list.
        ColumnInfo columnInfo = new ColumnInfo(columnType, ordinal, columnName, precision, scale, isNullable);
        rowMetadata.add(columnInfo);
      }
    } catch (MoreDataRequiredException e) {
      final String msg = "Didn't expect to need to read more data while " +
                         "processing row metadata.";
      throw new SEProtocolException(msg, e);
    }

    if (rowMetadata.size() == 0) {
      final String msg = "Cannot have 0 columns of row metadata: " + line;
      throw new SEProtocolException(msg);
    }

    result.setRowMetadata(rowMetadata);
  }

  /**
   * Extracts out the row data from the line and sets it in the result.
   * @param line the line we read from the se shell.
   * @param result the result object we are trying to set.
   * @throws SEProtocolException if we cannot parse the line we read from the se shell.
   */
  private void processRow(String line, SEResult result)
                         throws IOException, SEProtocolException, InterruptedException
  {
    // Remove the "row:" at the start of the line.
    String trimmed = ltrim(line.substring(ROW_MARKER.length()));

    // We can check for an open paren but not a close paren because it
    // could be on a different line.
    if (!trimmed.startsWith("(")) {
      final String msg = "Invalid row format encountered: \"" + line + "\"";
      throw new SEProtocolException(msg);
    }

    if (result.getRowMetadata() == null) {
      final String msg = "Got a row record before the result set metadata.";
      throw new SEProtocolException(msg);
    }

    // Remove the open paren
    String columnsStr = ltrim(trimmed.substring(1, trimmed.length()));

    int pos = -1;
    StringBuilder sb = new StringBuilder(1024);
    String value;

    List<String> columnsList = new ArrayList<>();

    while (pos < columnsStr.length()) {

      // We should be able to read a column value
      try {
        pos = getNextToken(columnsStr, pos, sb, DEFAULT_SEPARATORS);

      } catch (MoreDataRequiredException e) {
        // Append the next line and try again.
        String nextLine = readLine();
        columnsStr = columnsStr + System.lineSeparator() + nextLine;
        continue;
      }

      value = sb.toString();

      if (value.isEmpty() && pos >= columnsStr.length()) {
        // We've read nothing and hit the end of the input
        break;
      }

      if (value.equalsIgnoreCase("null")) {
        // Special handling for nulls - convert to an actual null value.
        value = null;

      } else if (value.startsWith("'") && value.endsWith("'")) {
        // special handling for strings - remove the quotes.
        value = value.substring(1, value.length() - 1);

        // Unescape any single quotes inside the string
        value = value.replace("''", "'");

      } else if (value.equalsIgnoreCase(DATE_WORD) ||
          value.equalsIgnoreCase(TIME_WORD) ||
          value.equalsIgnoreCase(TIMESTAMP_WORD)) {
        // Special handling for dates, times and timestamps - read the next
        // token and remove quotes from it. Just store the raw value.

        // read the next token and strip the quotes.
        if (pos >= columnsStr.length()) {
          final String msg = "Invalid format for value: " + value;
          throw new SEProtocolException(msg);
        }

        try {
          pos = getNextToken(columnsStr, pos, sb, DEFAULT_SEPARATORS);
        } catch (MoreDataRequiredException e) {
          final String msg = "Didn't expect to need to read more data while " +
                             "processing a " + value + " value.";
          throw new SEProtocolException(msg, e);
        }

        value = sb.toString();

        if (!value.startsWith("'") && !value.endsWith("'")) {
          final String msg = "Invalid format for value. Expected to find quotes: " + value;
          throw new SEProtocolException(msg);
        }

        value = value.substring(1, value.length() - 1);

      } else if (value.equalsIgnoreCase(INTERVAL_WORD)) {
        // Special handling for intervals - read the rest of the input up to the next comma
        // as a single token, including all whitespace. This is because intervals have more
        // difficult parsing.
        // e.g. given: INTERVAL -'2-3' YEARS TO MONTHS
        // then we would store "-'2-3' YEARS TO MONTHS" and parse this later on.

        // read the next token and strip the quotes.
        if (pos >= columnsStr.length()) {
          final String msg = "Invalid format for value: " + value;
          throw new SEProtocolException(msg);
        }

        final String intervalSeparator = ",";

        try {
          pos = getNextToken(columnsStr, pos, sb, intervalSeparator);
        } catch (MoreDataRequiredException e) {
          final String msg = "Didn't expect to need to read more data while " +
                             "processing a " + value + " value.";
          throw new SEProtocolException(msg, e);
        }

        value = sb.toString();
      }

      // Save this string value.
      columnsList.add(value);
    }

    String[] row = columnsList.toArray(new String[0]);
    result.addRow(row);
  }


  /**
   * Iterates over a string, input, from a starting position, pos, and adds characters to a
   * StringBuilder, sb, until we hit whitespace or a separator. Returns the
   * index position of the next character it is up to in the input string.
   * @param input the string to iterate over.
   * @param pos the index position to start iterating from. Set to -1 to iterate from the
   *            beginning of the string.
   * @param sb the StringBuilder to add characters to.
   * @param separators a list of separator characters to break on.
   * @return the index position of the next character to be read. Will be == input.length
   *         when it hits the end of the input.
   */
  private int getNextToken(String input, int pos, StringBuilder sb, String separators)
                          throws MoreDataRequiredException
  {
    // clear the stringbuilder first.
    sb.setLength(0);

    boolean inQuotes = false;
    boolean inParentheses = false; // handles things like VARCHAR(128)

    char quoteChar = '\'';

    while (++pos < input.length()) {

      char c = input.charAt(pos);

      switch (c) {

        case '\'':
        case '"':
          if (!inQuotes) {
            // save the type of quote character used
            quoteChar = c;
            inQuotes = true;

          } else if (quoteChar == c) {
            // e.g. If we are in a single quoted string and we receive a
            // double quote then we are not exiting the quoted string.
            inQuotes = false;
          }

          sb.append(c);
          break;

        case '(':
          if (!inQuotes) {
            inParentheses = true;
          }
          sb.append(c);
          break;

        case ')':
          if (!inParentheses && pos == input.length() - 1) {
            // This is the closing parenthesis that wraps the row data
            // and we can ignore it. We couldn't strip it earlier because
            // the row data can be split across multiple lines.
            break;
          }

          if (!inQuotes) {
            inParentheses = false;
          }

          sb.append(c);
          break;

        default:
          if (separators.contains(String.valueOf(c)) && !inQuotes && !inParentheses) {
            // We've hit a separator.

            if (sb.length() == 0) {
              // We haven't ready anything yet, so skip over leading separator characters
              // until we read a non-separator or hit end of string.
              break;

            } else {
              // We have previously read something. Skip over any trailing whitespace and then
              // return what we have read.
              while (pos + 1 < input.length() && separators.contains(String.valueOf(input.charAt(pos + 1)))) {
                ++pos;
              }

              return pos;
            }

          } else {
            // Save this character.
            sb.append(c);
            break;
          }
      }
    }

    // If we are still in quotes and we've hit the end of the input then
    // we need to read more data and keep going.
    if (inQuotes) {
      final String msg = "In the middle of reading a string but " +
                         "reached the end of the input.";
      throw new MoreDataRequiredException(msg);
    }

    // We hit the end of input. Return what we have read.
    return pos;
  }


  private static String ltrim(String s)
  {
    int i = 0;

    while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
      i++;
    }

    return s.substring(i);
  }

  private static String rtrim(String s)
  {
    int i = s.length() - 1;

    while (i >= 0 && Character.isWhitespace(s.charAt(i))) {
      i--;
    }

    return s.substring(0, i+1);
  }
}
