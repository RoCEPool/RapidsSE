// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

import java.util.ArrayList;
import java.util.List;

public class SEResult
{
  /**
   * An enum that describes how this SEResult object is to be interpreted.
   * Depending on the value of this enum will determine which fields are valid to be read.
   *
   * Value                Valid Fields
   * ------               -------------
   * HAS_ERROR          : getErrorMsg()
   * HAS_RESULT_SET     : getRows()
   *                      getRowMetadata()
   * HAS_AFFECTED_COUNT : getAffectedCount()
   */
  public enum Status {
    HAS_RESULT_SET,
    HAS_AFFECTED_COUNT,
    HAS_ERROR
  }

  /** How should this result object be interpreted? */
  private Status status = Status.HAS_AFFECTED_COUNT;

  private List<String[]> rows = null;
  private List<ColumnInfo> rowMetadata = null;
  private long affectedCount = 0;
  private String errorMsg = null;
  //private long errorCode = 0;


  /**
   * Returns an enum value that describes how this SEResult object is to be interpreted and
   * what fields will be valid.
   * @return an enum value that describes how this SEResult object is to be interpreted.
   */
  public Status getStatus()
  {
    return status;
  }

  /**
   * Returns the rows selected by this command.
   * All column values are kept in string format so that processing can occur elsewhere.
   * @return the rows selected by this command.
   */
  public List<String[]> getRows()
  {
    return rows;
  }

  /**
   * Adds a row to the result set.
   * @param row the row to add to the result set.
   */
  public void addRow(String[] row)
  {
    this.rows.add(row);
  }

  /**
   * Returns the metadata about the rows returned by this command.
   * @return the metadata about the rows returned by this command.
   */
  public List<ColumnInfo> getRowMetadata()
  {
    return rowMetadata;
  }

  /**
   * Sets the metadata about the rows returned by this command.
   * @param rowMetadata the metadata about the rows returned by this command.
   */
  public void setRowMetadata(List<ColumnInfo> rowMetadata)
  {
    // The presence of row metadata indicates that we are getting a result set, even
    // if there are no further rows returned.
    this.status = Status.HAS_RESULT_SET;
    this.rowMetadata = rowMetadata;

    // Since we should always get metadata about even empty result sets, we should create
    // an empty list of rows just in case the result is an empty resultset. We don't want
    // a null list of rows.
    this.rows = new ArrayList<>();
  }

  /**
   * Returns a count of the number of rows affected by this command.
   * This value is 0 if the command tries to select data (e.g. SELECT)
   * or >= 0 if the command does not try to select data (e.g. INSERT).
   * @return a count of the number of rows affected by this command.
   */
  public long   getAffectedCount()
  {
    return affectedCount;
  }

  /**
   * Sets the number of rows affected by the operation.
   * @param affectedCount the number of rows affected by the operation.
   */
  public void setAffectedCount(long affectedCount)
  {
    this.affectedCount = affectedCount;
  }

  /**
   * Returns the error message that was generated from executing this command.
   * @return the error message that was generated from executing this command.
   */
  public String getErrorMsg()
  {
    return errorMsg;
  }

  /**
   * Sets the error message returned by the operation.
   * @param errorMsg the error message returned by the operation.
   */
  public void setErrorMsg(String errorMsg)
  {
    // The presence of an error message means that something went wrong. This could happen
    // even after reading a number of rows.
    this.status = Status.HAS_ERROR;
    this.errorMsg = errorMsg;
    this.affectedCount = 0;
    this.rowMetadata = null;
    this.rows = null;
  }

//  /**
//   * Returns the error code that was generated from executing this command.
//   * @return the error code that was generated from executing this command.
//   */
//  public long getErrorCode()
//  {
//    return errorCode;
//  }
//
//  /**
//   * Sets the error code returned by the operation.
//   * @param errorCode the error code returned by the operation.
//   */
//  public void setErrorCode(long errorCode)
//  {
//    this.errorCode = errorCode;
//    this.affectedCount = 0;
//    this.rowMetadata = null;
//    this.rows = null;
//  }
}
