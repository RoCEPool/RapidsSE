// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class LocalSEConnection implements SEConnection
{
  private final File executable;
  private final String[] args;

  private final Process shellProcess;


  /**
   * Contructor
   * @param exePath the path to the se-shell executable.
   * @param args an array of arguments to the se-shell executable. Can be null.
   * @throws IOException if there is an error locating or executing the se-shell.
   */
  public LocalSEConnection(String exePath, String[] args) throws IOException
  {
    this.executable = new File(exePath);

    if (!executable.exists()) {
      throw new FileNotFoundException(exePath);
    }

    if (!executable.isFile()) {
      throw new IOException("Executable is not a file: " + exePath);
    }

    this.args = args;

    // Make a list of the command line and any arguments.
    List<String> command = new ArrayList<>();
    command.add(exePath);

    if (args != null) {
      for (String arg : args) {
        command.add(arg);
      }
    }

    // Start the shell.
    ProcessBuilder pb = new ProcessBuilder(command);
    this.shellProcess = pb.start();
  }


  /**
   * Returns true if the connection to the SE shell is alive, otherwise false.
   * @return Returns true if the connection to the SE shell is alive, otherwise false.
   */
  @Override
  public boolean isAlive()
  {
    return shellProcess.isAlive();
  }

  /**
   * Returns the outputstream used to send commands to the SE shell's stdin.
   * @return the outputstream used to send commands to the SE shell's stdin.
   */
  @Override
  public OutputStream getShellStdin()
  {
    return shellProcess.getOutputStream();
  }

  /**
   * Returns the inputstream used to read output from the SE shell's stdout.
   * @return the inputstream used to read output from the SE shell's stdout.
   */
  @Override
  public InputStream getShellStdout()
  {
    return shellProcess.getInputStream();
  }

  /**
   * Returns the inputstream used to read output from the SE shell's stderr.
   * @return the inputstream used to read output from the SE shell's stderr.
   */
  @Override
  public InputStream getShellStderr()
  {
    return shellProcess.getErrorStream();
  }

  /**
   * Closes this stream and releases any system resources associated
   * with it. If the stream is already closed then invoking this
   * method has no effect.
   * <p>
   * <p> As noted in {@link AutoCloseable#close()}, cases where the
   * close may fail require careful attention. It is strongly advised
   * to relinquish the underlying resources and to internally
   * <em>mark</em> the {@code Closeable} as closed, prior to throwing
   * the {@code IOException}.
   *
   * @throws IOException if an I/O error occurs
   */
  @Override
  public void close() throws IOException
  {
    shellProcess.getOutputStream().close();
    shellProcess.getInputStream().close();
    shellProcess.getErrorStream().close();
    shellProcess.destroyForcibly();
  }
}
