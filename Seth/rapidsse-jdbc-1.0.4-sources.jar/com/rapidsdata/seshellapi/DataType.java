// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

/** The set of data types that can be returned by Rapids SE. */
public enum DataType
{
  NULL,
  BOOLEAN,
  INTEGER,
  FLOAT,
  DECIMAL,
  VARCHAR,
  DATE,
  TIME,
  TIMESTAMP,
  INTERVAL,
  BINARY
}
