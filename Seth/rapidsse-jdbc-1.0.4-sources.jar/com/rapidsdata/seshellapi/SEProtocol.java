// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

import com.rapidsdata.seshellapi.exceptions.SEProtocolException;

import java.io.Closeable;
import java.io.IOException;

public interface SEProtocol extends Closeable
{
  /**
   * Executes a command via the se-shell and returns a result object.
   * @param command the command to be executed.
   * @return the result of executing this command.
   * @throws IOException if there is a communications problem with se-shell.
   * @throws SEProtocolException if there is a problem understanding the SE output.
   */
  public SEResult executeCommand(String command) throws IOException, SEProtocolException, InterruptedException;

  /**
   * Set the maximum number of rows that can be returned by a command. Any additional rows are
   * silently dropped.
   * @param maxRows The maximum number of rows that can be returned by a command. Value must
   *                be >= 0. A value of 0 means no limit.
   */
  public void setMaxRows(long maxRows) throws SEProtocolException;

  /**
   * Returns the maximum number of rows that any command will return. Additional rows above
   * this value are silently dropped. A value of 0 means no limit.
   * @return the maximum number of rows that any command will return.
   */
  public long getMaxRows();

}
