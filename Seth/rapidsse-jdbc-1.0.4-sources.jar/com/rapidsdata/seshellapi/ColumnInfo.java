
// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

import java.util.Objects;

/**
 * Describes columns of a result set.
 */
public class ColumnInfo implements Cloneable
{
  /** The data type returned by RapidsSE. */
  public final DataType type;

  /** The 1-based index of this column in the row. */
  public final int ordinal;

  /** Column label/name */
  public final String name;

  /** Column decimal precision */
  public final int precision;

  /** Column decimal scale */
  public final int scale;

  /** Column data type supports SQL NULL. If set to null then nullability is unknown. */
  public Boolean isNullable;

  // *** Other fields that could be added later on, depending on support from RapidsSE. ***

  /** Column actual table name */
  //public String realName;

  /** Database owning this column */
  //public String catalog;

  /** User owning this column */
  //public String schema;

  /** Table name owning this column */
  //public String tableName;

  /** Column name is case sensitive */
  //public boolean isCaseSensitive;

  /** Column may be updated */
  //public boolean isWriteable;

  /** Column is an identity column */
  //public boolean isIdentity;

  /** Column may be used as a key */
  //public boolean isKey;

  /** Column should be hidden */
  //public boolean isHidden;

  /** Database ID for UDT */
  //public int userType;

  /** collation */
  //public byte[] collation;

  /** Character set descriptor (if different from default) */
  //public CharsetInfo charsetInfo;

  /** Column display size */
  //public int displaySize;

  /** Column buffer (max) size */
  //public int bufferSize;

  /** The SQL type name for this column. */
  //public String sqlType;

  /**
   * Constructor
   * @param type the data type of the column
   * @param ordinal the 1-based index of this column in the row.
   * @param name the name of the column. Can be null.
   * @param precision the precision of the column
   * @param scale the scale of the column
   */
  public ColumnInfo(DataType type, int ordinal, String name, int precision,
                    int scale, Boolean isNullable)
  {
    this.type = type;
    this.ordinal = ordinal;
    this.name = (name != null ? name : "COL" + ordinal);
    this.precision = precision;
    this.scale = scale;
    this.isNullable = isNullable;
  }

  /**
   * Constructor. Sets precision and scale to largest negative integer to denote it is not set.
   * @param type the data type of the column.
   * @param ordinal the 1-based index of this column in the row.
   * @param name the name of the column.
   */
  public ColumnInfo(DataType type, int ordinal, String name)
  {
    this.type = type;
    this.ordinal = ordinal;
    this.name = (name != null ? name : "COL" + ordinal);
    this.precision = Integer.MIN_VALUE;
    this.scale = Integer.MIN_VALUE;
  }

  @Override
  public String toString()
  {
    return name;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(
        type,
        ordinal,
        name,
        precision,
        scale,
        isNullable
//      realName,
//      catalog,
//      schema,
//      tableName,
//      isCaseSensitive,
//      isWriteable,
//      isIdentity,
//      isKey,
//      isHidden,
//      userType,
//      collation,
//      charsetInfo,
//      displaySize,
//      bufferSize,
//      sqlType

    );
    //return System.identityHashCode(this);
  }

  @Override
  public boolean equals(Object other)
  {
    if (other == null) {
      return false;
    }

    if (!(other instanceof ColumnInfo)) {
      return false;
    }

    if (other == this) {
      return true;
    }

    ColumnInfo o = (ColumnInfo) other;

    // compare primitive fields
    return
        type            == o.type
            && ordinal         == o.ordinal
            && precision       == o.precision
            && scale           == o.scale
            && isNullable      == o.isNullable
//   && jdbcType        == o.jdbcType
//   && userType        == o.userType
//   && displaySize     == o.displaySize
//   && bufferSize      == o.bufferSize
//   && isCaseSensitive == o.isCaseSensitive
//   && isWriteable     == o.isWriteable
//   && isIdentity      == o.isIdentity
//   && isKey           == o.isKey
//   && isHidden        == o.isHidden

            // compare non-primitive fields
            && compare(name, o.name)
//   && compare(realName, o.realName)
//   && compare(tableName, o.tableName)
//   && compare(catalog, o.catalog)
//   && compare(schema, o.schema)
//   && compare(sqlType, o.sqlType)
//   && compare(charsetInfo, o.charsetInfo)
//
//   // compare collation
//   && Arrays.equals(collation, o.collation)
        ;
  }

  /////////////////////////////////////////////////////////////////////////////
  // private methods
  /////////////////////////////////////////////////////////////////////////////

  /**
   * <p> Compares two object.   p>
   *
   * @return {@code true} if either both values are {@code null} or comparing them
   * using the equals method of <i>o1  i> returns {@code true}
   */
  private final boolean compare(Object o1, Object o2)
  {
    return o1 == o2 || o1 != null && o1.equals(o2);
  }

}