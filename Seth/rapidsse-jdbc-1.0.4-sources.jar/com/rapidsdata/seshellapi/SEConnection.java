// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface SEConnection extends Closeable
{
  /**
   * Returns true if the connection to the SE shell is alive, otherwise false.
   * @return Returns true if the connection to the SE shell is alive, otherwise false.
   */
  public boolean isAlive();

  /**
   * Returns the outputstream used to send commands to the SE shell's stdin.
   * @return the outputstream used to send commands to the SE shell's stdin.
   */
  public OutputStream getShellStdin() throws IOException;

  /**
   * Returns the inputstream used to read output from the SE shell's stdout.
   * @return the inputstream used to read output from the SE shell's stdout.
   */
  public InputStream  getShellStdout() throws IOException;

  /**
   * Returns the inputstream used to read output from the SE shell's stderr.
   * @return the inputstream used to read output from the SE shell's stderr.
   */
  public InputStream  getShellStderr() throws IOException;
}
