// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi.exceptions;

public class SEProtocolException extends Exception
{
  public SEProtocolException(String message)
  {
    super(message);
  }

  public SEProtocolException(String message, Throwable throwable)
  {
    super(message, throwable);
  }

//  public SEProtocolException(Throwable throwable)
//  {
//    super(throwable.getMessage(), throwable);
//  }
}
