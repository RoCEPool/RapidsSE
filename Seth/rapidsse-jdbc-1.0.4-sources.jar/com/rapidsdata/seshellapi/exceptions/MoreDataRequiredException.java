// Copyright (c) 2017 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.seshellapi.exceptions;

public class MoreDataRequiredException extends Exception
{
  public MoreDataRequiredException(String message)
  {
    super(message);
  }
}
