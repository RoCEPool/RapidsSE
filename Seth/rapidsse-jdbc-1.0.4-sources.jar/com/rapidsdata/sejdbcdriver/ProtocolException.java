// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

/**
 * Exception class used to report errors in the RDP protocol.
 */
public class ProtocolException extends Exception
{
  /**
   * Construct a ProtocolException with message.
   *
   * @param message The explanatory message.
   */
  public ProtocolException(String message)
  {
    super(message);
  }
}
