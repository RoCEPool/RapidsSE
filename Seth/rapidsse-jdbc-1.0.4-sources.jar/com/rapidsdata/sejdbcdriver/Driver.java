
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver;

import com.jcabi.aspects.Loggable;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * implementation of the java.sql.Driver interface.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class Driver implements java.sql.Driver
{
  /**
   * URL prefix used by the driver
   */
  private static String JDBC = "jdbc";
  private static String DRIVER_NAME = "rapidsse";
  private static String DRIVER_PREFIX = JDBC + ":" + DRIVER_NAME + ":";

  /**
   * Driver major version and minor version.
   */
  static final int MAJOR_VERSION = 1;
  static final int MINOR_VERSION = 0;


  // Property name keys
  public static final String BUFFERDIR    = "bufferdir";
  public static final String CATALOGNAME  = "catalogname";
  public static final String SCHEMANAME   = "schemaname";
  public static final String SESHELLPATH  = "seshellpath";
  public static final String SESHELLARGS  = "args";
  public static final String SESHELLEXTRAARGS = "extraargs";
  public static final String SSHUSER      = "sshuser";
  public static final String SSHHOST      = "sshhost";
  public static final String SSHPORT      = "sshport";
  public static final String USELOBS      = "uselobs";


  static {
    try {
      // Register this with the DriverManager
      DriverManager.registerDriver(new Driver());
    } catch (SQLException e) {
      throw new RuntimeException("Can't register driver!");
    }
  }

  public int getMajorVersion()
  {
    return MAJOR_VERSION;
  }

  public int getMinorVersion()
  {
    return MINOR_VERSION;
  }

  /**
   * Returns the driver version.
   */
  public static final String getVersion()
  {
    return MAJOR_VERSION + "." + MINOR_VERSION;
  }

  /**
   * Returns the string form of the object.
   *
   * @return the driver version
   */
  public String toString()
  {
    return "com.rapidsdata.sejdbcdriver.Driver " + getVersion();
  }

  public boolean jdbcCompliant()
  {
    return false;
  }

  public boolean acceptsURL(String url) throws SQLException
  {
    if (url == null || url.isEmpty()) {
      return false;
    }

    Properties properties = parseURL(url, null);
    return (properties != null);
  }

  public Connection connect(String url, Properties info)
      throws SQLException
  {
    if (url == null || !url.startsWith(DRIVER_PREFIX)) {
      throw new SQLException("BAD Connection URL: " + url);
    }

    Properties props = setupConnectProperties(url, info);

    return new JdbcConnection(url, props);
  }

  public DriverPropertyInfo[] getPropertyInfo(final String url, final Properties props)
      throws SQLException
  {
    Properties parsedProps = parseURL(url, (props == null ? new Properties() : props));

    if (parsedProps == null) {
      throw new SQLException("error.driver.badurl", "08001");
    }

    parsedProps = DefaultProperties.addDefaultProperties(parsedProps);

    final Map propertyMap = new HashMap();
    final Map descriptionMap = new HashMap();


    final Map choicesMap = createChoicesMap();
    final Map requiredTrueMap = createRequiredTrueMap();

    final DriverPropertyInfo[] dpi = new DriverPropertyInfo[propertyMap.size()];
    final Iterator iterator = propertyMap.entrySet().iterator();
    for (int i = 0; iterator.hasNext(); i++) {

      final Map.Entry entry = (Map.Entry) iterator.next();
      final String key = (String) entry.getKey();
      final String name = (String) entry.getValue();

      final DriverPropertyInfo info = new DriverPropertyInfo(name, parsedProps.getProperty(name));
      info.description = (String) descriptionMap.get(key);
      info.required = requiredTrueMap.containsKey(name);

      if (choicesMap.containsKey(name)) {
        info.choices = (String[]) choicesMap.get(name);
      }

      dpi[i] = info;
    }

    return dpi;
  }

  /**
   * @param url  the URL of the database to which to connect
   * @param info a list of arbitrary string tag/value pairs as
   *             connection arguments.
   * @return the set of properties for the connection
   * @throws SQLException if an error occurs parsing the URL
   */
  private Properties setupConnectProperties(String url, Properties info) throws SQLException
  {

    Properties props = parseURL(url, info);

    if (props == null) {
      throw new SQLException("error.driver.badurl", "08001");
    }

    // Set default properties
    props = DefaultProperties.addDefaultProperties(props);
    return props;
  }

  /**
   * Creates a map of driver properties which can be used later
   */
  private static Map createChoicesMap()
  {
    final HashMap choicesMap = new HashMap();

    return choicesMap;
  }

  /**
   * Creates a map of driver properties
   */
  private static Map createRequiredTrueMap()
  {
    final HashMap requiredTrueMap = new HashMap();
    // Fill with any property names that must be set.
    // e.g.
    //requiredTrueMap.put(Driver.SERVERNAME, null);

    return requiredTrueMap;
  }

  /**
   * Parse the driver URL and extract the properties.
   * Due to the non-standard/database product specific, there is no
   * easy rule for parsing the URL.
   *
   * @param url  the URL to parse
   * @param info any existing properties already loaded in a
   *             object
   * @return the URL properties as a   object
   */
  private static Properties parseURL(String url, Properties info)
  {
    final String componentSeparators = ":?";
    final String pathSeparator = "?";

    Properties props;

    // Take local copy of existing properties
    if (info == null) {
      props = new Properties();

    } else {
      props = new Properties(info);
    }

    if (!url.startsWith(DRIVER_PREFIX)) {
      Logger.println("Not a RapidsSE JDBC driver.");
      return null;
    }

    StringBuilder token = new StringBuilder(256);
    int pos = 0;

    // Pull apart the connection url
    pos = nextToken(url, pos, componentSeparators, token); // token = "jdbc"
    if (!JDBC.equals(token.toString())) {
      Logger.println("Not a JDBC driver.");
      return null; // missing: jdbc
    }

    pos = nextToken(url, pos, componentSeparators, token); // token = "rapidsse"
    if (!DRIVER_NAME.equals(token.toString())) {
      Logger.println("Not a rapidsse JDBC driver.");
      return null; // missing: rapidsse
    }

    // Now get the path to the se-shell, or the ssh endpoint. Peek ahead to see
    // if we've got a "//" as this indicates an ssh endpoint.
    if ((url.length() > pos + 1) && url.charAt(pos) == '/' && url.charAt(pos+1) == '/') {

      // Advance past the "//"
      pos += 2;

      // Read the whole ssh string, up to the next semicolon or question mark
      pos = nextToken(url, pos, componentSeparators, token);

      // We've read a ssh hostname. Extract the various details.
      // First remove the 2 leading forward slashes.
      String sshStr = token.toString();
      boolean result = urlExtractSshComponents(sshStr, props);

      if (!result) {
        return null;
      }
    }

    if (url.length() > pos) {

      if (url.charAt(pos - 1) == '?') {
        // We don't have a SE shell path, but we do have parameters to read next.
        if (!urlExtractParameters(url, pos, token, props)) {
          return null;
        }

      } else {
        // Read the path to the SE Shell, then read any parameters.
        // First get the next token, which should be the SE shell path.
        pos = nextToken(url, pos, pathSeparator, token);

        if (!urlExtractSeShellPath(token.toString().trim(), props)) {
          return null;
        }

        if (!urlExtractParameters(url, pos, token, props)) {
          return null;
        }
      }
    }

    return props;
  }

  private static boolean urlExtractSshComponents(String sshStr, Properties props)
  {
    // We've got an ssh hostname coming up. Extract the various details.
    if (sshStr.contains("@")) {
      // We need to extract out the ssh username.
      String[] sshComponents = sshStr.split("@");

      if (sshComponents.length != 2 || sshComponents[0].trim().isEmpty()) {
        Logger.println("SSH username extraction failed.");
        return false;
      }

      // Save the SSH username
      props.setProperty(SSHUSER, sshComponents[0]);
      sshStr = sshComponents[1];
    }

    // We should now be left with a hostname and potentially a port.
    Pattern pattern = Pattern.compile("(.+?)(\\[:\\d+\\])?");
    Matcher matcher = pattern.matcher(sshStr);

    if (!matcher.matches()) {
      Logger.println("SSH host:port matching failed.");
      return false;
    }

    if (matcher.groupCount() != 1 && matcher.groupCount() != 2) {
      Logger.println("Invalid number of groups for SSH host:port matching.");
      return false;
    }

    String sshHost = matcher.group(1).trim(); // Should be non null.
    String sshPort = matcher.group(2);        // May be null.

    if (sshHost.isEmpty()) {
      Logger.println("Invalid SSH host.");
      return false;
    }

    // The SSH host might be an IPv6 address in square brackets. Check if there are square brackets
    if (sshHost.startsWith("[") && sshHost.endsWith("]")) {
      // Strip the square brackets.
      sshHost = sshHost.substring(1, sshHost.length() - 1);
    }

    props.setProperty(SSHHOST, sshHost);

    if (sshPort != null) {

      // Remove the square brackets and colon
      if (sshPort.startsWith("[:") && sshPort.endsWith("]")) {
        sshPort = sshPort.substring(2, sshPort.length() - 1);
      }

      try {
        short portNum = Short.parseShort(sshPort);

        if (portNum < 0) {
          Logger.println("Cannot have a negative SSH port value.");
          return false;
        }

      } catch (NumberFormatException e) {
        Logger.println("Invalid SSH port value.");
        return false;
      }

      props.setProperty(SSHPORT, sshPort);
    }

    return true;
  }

  private static boolean urlExtractSeShellPath(String path, Properties props)
  {
    // A path may be absolute, relative, unix format or windows format. It may also contain a tilde.
    if (path.isEmpty()) {
      // Use the default path.
      return true;
    }

    // Strip any quotes around the path.
    if ( (path.startsWith("'")  && path.endsWith("'")) ||
         (path.startsWith("\"") && path.endsWith("\"")) ) {
      path = path.substring(1, path.length());
    }

    // If the path starts with a tilde and we don't have a ssh hostname then expand the meaning of the tilde.
    if (path.startsWith("~") && props.getProperty(SSHHOST) == null) {
      String slash = "/";

      if (path.charAt(1) == '/') {
        slash = "";
      }

      path = System.getProperty("user.home") + slash + path.substring(1);
    }

    props.setProperty(SESHELLPATH, path);

    return true;
  }

  private static boolean urlExtractParameters(String url, int pos, StringBuilder token, Properties props)
  {
    final String separator = "&";

    if (pos == url.length()) {
      // No properties
      return true;
    }

    if (url.charAt(pos - 1) != '?') {
      Logger.println("URL '?' separator missing.");
      return false;
    }

    boolean firstParam = true;

    while (pos < url.length()) {

      if (url.charAt(pos - 1) != '&' && !firstParam) {
        Logger.println("URL is missing appropriate parameter separator '&'.");
        return false;
      }

      firstParam = false;

      pos = nextToken(url, pos, separator, token);
      String param = token.toString();

      if (param.trim().isEmpty()) {
        continue;
      }

      int index = param.indexOf('=');

      if (index == -1) {
        props.setProperty(param.toLowerCase(), "");

      } else if (index == param.length() - 1) {
        Logger.println("Invalid URL parameter: " + param);
        return false;

      } else {
        String key = param.substring(0, index);

        if ((key.startsWith("'")  && key.endsWith("'") ||
            (key.startsWith("\"") && key.endsWith("\"")))) {
          key = key.substring(1, key.length() - 1);

        } else {
          key = key.toLowerCase();
        }

        String val = param.substring(index + 1, param.length());

        if ((val.startsWith("'")  && val.endsWith("'") ||
            (val.startsWith("\"") && val.endsWith("\"")))) {
          val = val.substring(1, val.length() - 1);
        }

        props.setProperty(key, val);
      }
    }



    return true;
  }

  /**
   * Extract the next lexical token from the URL.
   *
   * @param url   The URL being parsed
   * @param pos   The current position in the URL string.
   * @param token The buffer containing the extracted token.
   * @return The updated position as an int.
   */
  private static int nextToken(String url, int pos, String separators, StringBuilder token)
  {
    token.setLength(0);
    boolean inQuote = false;
    boolean useSquareQuote = false;

    if (separators.contains(":")) {
      useSquareQuote = true;
    }

    while (pos < url.length()) {
      char ch = url.charAt(pos++);

      if (!inQuote) {
        if (separators.contains(String.valueOf(ch))) {
        //if (ch == ':' || ch == ';' || ch == '?' || ch == '&') {
          break;
        }
      }

      if (useSquareQuote && ch == '[') {
        inQuote = true;

      } else if (useSquareQuote && ch == ']') {
        inQuote = false;
      }

      token.append(ch);
    }

    return pos;
  }

  //// JDBC4.1 demarcation, do NOT put any JDBC3/4.0 code below this line ////

  @Override
  public java.util.logging.Logger getParentLogger() throws java.sql.SQLFeatureNotSupportedException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }
}