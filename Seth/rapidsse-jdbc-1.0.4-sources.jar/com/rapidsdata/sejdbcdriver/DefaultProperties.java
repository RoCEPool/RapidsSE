// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

import java.io.*;
import java.util.Properties;

/**
 * Container for default property constants.
 * <p/>
 * This class also provides static utility methods for
 * {@link Properties} and  Settings    objects.
 * <p/>
 * To add new properties to the RDP driver, do the following:
 * <ol>
 * <li>Add  prop.<em>foo  em>    and  prop.desc.<em>foo  em>
 * properties to  Messages.properties   .  li>
 * <li>Add a  static final    default field to {@link DefaultProperties}.  li>
 * <li>Update {@link #addDefaultProperties(java.util.Properties)} to set the default.  li>
 * <li>Update  Driver.createChoicesMap()    and
 * DriverUnitTest.test_getPropertyInfo_Choices()    if the property
 * has a specific set of inputs, e.g., "true" and "false", or "1" and "2".  li>
 * <li>Update  Driver.createRequiredTrueMap()    and
 * DriverUnitTest.test_getPropertyInfo_Required()    if the property
 * is required.  li>
 * <li>Add a new test to  DefaultPropertiesTestLibrary    for the new
 * property.  li>
 * ol>
 */
public final class DefaultProperties
{
  /** Default autoCommit property. */
  public static final String DEFAULT_AUTO_COMMIT = "true";

  /** Default schemaName property. */
  public static final String DEFAULT_SCHEMA_NAME = "";

  /** Default tmpDir property. */
  public static final String DEFAULT_BUFFER_DIR = new File(System.getProperty("java.io.tmpdir")).toString();

  /** Default sendStringParametersAsUnicode property. */
  public static final String DEFAULT_USE_UNICODE = "true";

  /** Default useLOBs property. */
  public static final String DEFAULT_USELOBS = "true";

  /** Where do we look for the SE Shell executable? */
  public static final String DEFAULT_SE_SHELL_PATH = "/opt/rdp/current/se-shell.sh";

  /** What are the default arguments to the SE shell? */
  public static final String DEFAULT_SE_SHELL_ARGS = "--metadata --script";

  /** These are always concatenated in addition to the SESHELLARGS property.
   * This allows a user to use the default se shell args and then specify
   * any extra ones they wish to use (as opposed to overwriting all the args). */
  public static final String DEFAULT_SE_SHELL_EXTRA_ARGS = "";

  /** What username do we use, if we are using SSH? */
  public static final String DEFAULT_SSH_USER = System.getProperty("user.name");

  /** Which host/ip do we connect to, if we are using SSH? */
  public static final String DEFAULT_SSH_HOST = "";

  /** Which SSH port number do we connect to, if we are using SSH? */
  public static final String DEFAULT_SSH_PORT = "22";

  /**
   * Add default properties to the  props    properties object.
   *
   * @param props The properties object.
   * @return The updated  props    object, or  null
   * if the  serverType    property is not set.
   */
  public static Properties addDefaultProperties(final Properties props)
  {
    addDefaultPropertyIfNotSet(props, Driver.SCHEMANAME, DEFAULT_SCHEMA_NAME);
    addDefaultPropertyIfNotSet(props, Driver.USELOBS, DEFAULT_USELOBS);
    addDefaultPropertyIfNotSet(props, Driver.BUFFERDIR, DEFAULT_BUFFER_DIR);

    addDefaultPropertyIfNotSet(props, Driver.SESHELLPATH, DEFAULT_SE_SHELL_PATH);
    addDefaultPropertyIfNotSet(props, Driver.SESHELLARGS, DEFAULT_SE_SHELL_ARGS);
    addDefaultPropertyIfNotSet(props, Driver.SESHELLEXTRAARGS, DEFAULT_SE_SHELL_EXTRA_ARGS);
    addDefaultPropertyIfNotSet(props, Driver.SSHUSER, DEFAULT_SSH_USER);
    addDefaultPropertyIfNotSet(props, Driver.SSHHOST, DEFAULT_SSH_HOST);
    addDefaultPropertyIfNotSet(props, Driver.SSHPORT, DEFAULT_SSH_PORT);

    return props;
  }

  /**
   * Sets a default property if the property is not already set.
   *
   * @param props        The properties object.
   * @param key          The message key to set.
   * @param defaultValue The default value to set.
   */
  private static void addDefaultPropertyIfNotSet(
      final Properties props, final String key, final String defaultValue)
  {
    final String messageKey = key;

    if (props.getProperty(messageKey) == null) {
      props.setProperty(messageKey, defaultValue);
    }
  }
}
