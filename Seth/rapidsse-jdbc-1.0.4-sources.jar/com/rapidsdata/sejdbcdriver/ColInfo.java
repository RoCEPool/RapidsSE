
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver;

import com.rapidsdata.sejdbcdriver.exceptions.JdbcDriverRuntimeException;
import com.rapidsdata.sejdbcdriver.sesupport.TypeHelper;
import com.rapidsdata.seshellapi.ColumnInfo;
import com.rapidsdata.seshellapi.DataType;

import java.sql.Types;
import java.util.Arrays;

import static java.sql.ResultSetMetaData.columnNoNulls;
import static java.sql.ResultSetMetaData.columnNullable;
import static java.sql.ResultSetMetaData.columnNullableUnknown;

/**
 * <p> Instances of this class serve as descriptor for result set columns.   p>
 */
public class ColInfo implements Cloneable
{
  /** Internal RapidsSE data type */
  DataType seType;

  /** JDBC type constant from java.sql.Types */
  int jdbcType;

  /** Column actual table name */
  String realName;

  /** Column label / name */
  String name;

  /** Database owning this column */
  String catalog;

  /** User owning this column */
  String schema;

  /** Table name owning this column */
  String tableName;

  /** Column data type supports SQL NULL */
  int nullable;

  /** Column name is case sensitive */
  boolean isCaseSensitive;

  /** Column may be updated */
  boolean isWriteable;

  /** Column is an identity column */
  boolean isIdentity;

  /** Column may be used as a key */
  boolean isKey;

  /** Column should be hidden */
  boolean isHidden;

  /** Database ID for UDT */
  int userType;

  /** collation */
  byte[] collation;

  /** Character set descriptor (if different from default) */
  CharsetInfo charsetInfo;

  /** Column display size */
  int displaySize;

  /** Column buffer (max) size */
  int bufferSize;

  /** Column decimal precision */
  int precision;

  /** Column decimal scale */
  int scale;

  /** The SQL type name for this column. */
  String sqlType;


  /**
   * Constructor to create a JDBC ColInfo from an SE ColumnInfo.
   * @param seCol
   */
  public ColInfo(ColumnInfo seCol)
  {
    // Fields that we can set appropriately from the SE metadata
    this.seType     = seCol.type;
    this.jdbcType   = TypeHelper.convertSeTypeToJdbcType(seCol.type);
    this.name       = seCol.name;
    this.precision  = (seCol.precision == Integer.MIN_VALUE ? 0 : seCol.precision);
    this.scale      = (seCol.scale == Integer.MIN_VALUE ? 0 : seCol.scale);
    this.nullable   = (seCol.isNullable == null ?
                        columnNullableUnknown :
                        (seCol.isNullable ?
                            columnNullable :
                            columnNoNulls
                        )
                      );

    // Fields that we don't have values for. Use defaults.
    this.realName         = null;
    this.catalog          = null;
    this.schema           = null;
    this.tableName        = null;
    this.isCaseSensitive  = false;
    this.isWriteable      = false;
    this.isIdentity       = false;
    this.isKey            = false;
    this.isHidden         = false;
    this.userType         = 0;
    this.collation        = null;
    this.charsetInfo      = null;
    this.displaySize      = 0;
    this.bufferSize       = 0;
    this.sqlType          = TypeHelper.convertJdbcTypeToString(this.jdbcType);
  }

  /**
   * Constructor for creating a ColInfo from only a name and a JDBC type.
   * Typically used for hand-made result sets that the JDBC driver makes.
   * @param columnName the name/label of the column.
   * @param jdbcType the JDBC data type of the column.
   */
  public ColInfo(String columnName, int jdbcType)
  {
    // Fields that we can set appropriately from the SE metadata
    this.name       = columnName;
    this.realName   = columnName;
    this.jdbcType   = jdbcType;

    // Fields that we don't have values for. Use defaults.
    this.seType           = null;
    this.precision        = 0;
    this.scale            = 0;
    this.catalog          = null;
    this.schema           = null;
    this.tableName        = null;
    this.nullable         = columnNullableUnknown;
    this.isCaseSensitive  = false;
    this.isWriteable      = false;
    this.isIdentity       = false;
    this.isKey            = false;
    this.isHidden         = false;
    this.userType         = 0;
    this.collation        = null;
    this.charsetInfo      = null;
    this.displaySize      = 0;
    this.bufferSize       = 0;
    this.sqlType          = TypeHelper.convertJdbcTypeToString(this.jdbcType);

    // We can set some of the above fields based on the column type.
    switch (jdbcType) {

      case Types.VARCHAR:
        this.seType = DataType.VARCHAR;
        this.bufferSize = 8000;
        this.displaySize = 8000;
        this.precision = 8000;
        break;

      case Types.BIGINT:
        this.seType = DataType.INTEGER;
        this.bufferSize = 8;
        this.displaySize = 20;
        this.precision = 19;
        break;

      case Types.INTEGER:
        this.seType = DataType.INTEGER;
        this.bufferSize = 4;
        this.displaySize = 11;
        this.precision = 10;
        break;

      case Types.SMALLINT:
        this.seType = DataType.INTEGER;
        this.bufferSize = 2;
        this.displaySize = 6;
        this.precision = 5;
        break;

      case Types.FLOAT:
        this.seType = DataType.FLOAT;
        this.bufferSize = 8;
        this.displaySize = 21;
        this.precision = 16;
        break;

      case Types.BIT:
        this.seType = DataType.INTEGER;
        this.bufferSize = 1;
        this.displaySize = 1;
        this.precision = 1;
        break;

      case Types.BOOLEAN:
        this.seType = DataType.BOOLEAN;
        this.bufferSize = 1;
        this.displaySize = 1;
        this.precision = 1;
        break;

      // TODO: Add in other data types here.

      default:
        throw new JdbcDriverRuntimeException("Unimplemented data type: " + TypeHelper.convertJdbcTypeToString(jdbcType));
    }
  }

  /**
   * Returns a string with the name of the class for the current jdbc data type.
   * @return a string with the name of the class for the current jdbc data type.
   */
  public String getClassName()
  {
    return TypeHelper.getClassName(this.jdbcType);
  }


  @Override
  public String toString()
  {
    return name;
  }

  @Override
  public int hashCode()
  {
    return System.identityHashCode(this);
  }

  @Override
  public boolean equals(Object other)
  {
    if (!(other instanceof ColInfo))
      return false;

    if (other == this)
      return true;

    ColInfo o = (ColInfo) other;

    return

        // compare primitive fields
        seType == o.seType
            && jdbcType == o.jdbcType
            && nullable == o.nullable
            && userType == o.userType
            && displaySize == o.displaySize
            && bufferSize == o.bufferSize
            && precision == o.precision
            && scale == o.scale
            && isCaseSensitive == o.isCaseSensitive
            && isWriteable == o.isWriteable
            && isIdentity == o.isIdentity
            && isKey == o.isKey
            && isHidden == o.isHidden

            // compare non-primitive fields
            && compare(realName, o.realName)
            && compare(name, o.name)
            && compare(tableName, o.tableName)
            && compare(catalog, o.catalog)
            && compare(schema, o.schema)
            && compare(sqlType, o.sqlType)
            && compare(charsetInfo, o.charsetInfo)

            // compare collation
            && Arrays.equals(collation, o.collation);
  }

  /////////////////////////////////////////////////////////////////////////////
  // private methods
  /////////////////////////////////////////////////////////////////////////////

  /**
   * <p> Compares two object.   p>
   *
   * @return {@code true} if either both values are {@code null} or comparing them
   * using the equals method of <i>o1  i> returns {@code true}
   */
  private final boolean compare(Object o1, Object o2)
  {
    return o1 == o2 || o1 != null && o1.equals(o2);
  }

}