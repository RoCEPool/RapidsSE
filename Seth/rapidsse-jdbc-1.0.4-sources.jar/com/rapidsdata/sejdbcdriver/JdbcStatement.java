
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver;

import com.jcabi.aspects.Loggable;
import com.rapidsdata.sejdbcdriver.exceptions.JdbcDriverRuntimeException;
import com.rapidsdata.sejdbcdriver.exceptions.ResourceClosedException;
import com.rapidsdata.seshellapi.SEResult;
import org.slf4j.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicInteger;
import static java.lang.Math.toIntExact;

/**
 * implementation of the java.sql.Statement interface.<p>
 * NB. As allowed by the JDBC standard and like most other drivers,
 * this implementation only allows one open result set at a time.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class JdbcStatement implements java.sql.Statement
{

  /**
   * Column name to be used for retrieving generated keys from the server:
   * "_JRDP_GENE_RATED_KEYS_"
   */
  static final String GENKEYCOL = "_JRDP_GENE_R_ATED_KEYS_";
  /**
   * The logger for this class.
   */
  private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(JdbcStatement.class.getName());
  /*
   * Constants used for backwards compatibility with JDK 1.3
   */
  static final int RETURN_GENERATED_KEYS = 1;
  static final int NO_GENERATED_KEYS = 2;
  static final int CLOSE_CURRENT_RESULT = 1;
  static final int KEEP_CURRENT_RESULT = 2;
  static final int CLOSE_ALL_RESULTS = 3;
  public static final int BOOLEAN = 16;
  public static final int DATALINK = 70;
  static final Integer SUCCESS_NO_INFO = new Integer(-2);
  static final Integer EXECUTE_FAILED = new Integer(-3);
  static final int DEFAULT_FETCH_SIZE = 0;

  /**
   * The connection owning this statement object.
   */
  protected JdbcConnection connection;


  /** The read query timeout in seconds */
  protected int queryTimeout;

  protected JdbcResultSet currentResult;

  /** The current update count. */
  private int updateCount = -1;

  /** The fetch direction for result sets. */
  protected int fetchDirection = ResultSet.FETCH_FORWARD;

  /** The type of result sets created by this statement. */
  protected int resultSetType = ResultSet.TYPE_FORWARD_ONLY;

  /** The concurrency of result sets created by this statement. */
  protected int resultSetConcurrency = ResultSet.CONCUR_READ_ONLY;

  /** The fetch size (default 100, only used by cursor ResultSets). */
  protected int fetchSize = DEFAULT_FETCH_SIZE;

  /** The cursor name to be used for positioned updates. */
  protected String cursorName;

  /** The maximum field size (not used at present). */
  protected int maxFieldSize = 0;

  /** The maximum number of rows to return (not used at present). */
  protected long maxRows;

  /** True if SQL statements should be preprocessed. */
  protected boolean escapeProcessing = false;

  /** SQL Diagnostic exceptions and warnings. */
  protected final SQLDiagnostic messages;

  /** Batched SQL Statement array. */
  protected ArrayList batchValues;

  /** Dummy result set for getGeneratedKeys. */
  protected CachedResultSet genKeyResultSet;

  /** List of queued results (update counts, possibly followed by a ResultSet). */
  protected final LinkedList resultQueue = new LinkedList();

  /** List of open result sets. */
  protected ArrayList openResultSets;

  /** The cached column meta data. */
  protected ColInfo[] colMetaData;

  private boolean closeOnCompletion = false;

  /**
   * 0 - this statement is open  td>
   * 1 - this statement is currently being closed  td>
   * 2 - this statement is closed  td>
   */
  private final AtomicInteger _Closed = new AtomicInteger();

  /** The last sql string executed through this Statement. */
  protected String lastSql = null;

  /**
   * Construct a new Statement object.
   *
   * @param connection           The parent connection.
   * @param resultSetType        The result set type for example TYPE_FORWARD_ONLY.
   * @param resultSetConcurrency The concurrency for example CONCUR_READ_ONLY.
   */
  JdbcStatement(JdbcConnection connection,
                int resultSetType,
                int resultSetConcurrency) throws SQLException
  {
    //
    // This is a good point to do common validation of the result set type
    //
    if (resultSetType < ResultSet.TYPE_FORWARD_ONLY
        || resultSetType > ResultSet.TYPE_SCROLL_SENSITIVE + 1) {
      throw new SQLException(
          "error.generic.badparam",
          "HY092");
    }
    //
    // Ditto for the result set concurrency
    //
    if (resultSetConcurrency < ResultSet.CONCUR_READ_ONLY
        || resultSetConcurrency > ResultSet.CONCUR_UPDATABLE + 2) {
      throw new SQLException(
          "error.generic.badparam",
          "HY092");
    }

    // Let's limit ourselves to TYPE_SCROLL_INSENSITIVE and CONCUR_READ_ONLY.
    // JMeter uses these two values
    if (resultSetType != ResultSet.TYPE_SCROLL_INSENSITIVE ||
        resultSetConcurrency != ResultSet.CONCUR_READ_ONLY) {

      final String msg = "JDBC Statement is only supported with a ResultSet type of " +
                         "TYPE_SCROLL_INSENSITIVE and ResultSet concurrency of " +
                         "CONCUR_READ_ONLY.";
      throw new SQLFeatureNotSupportedException(msg);
    }

    maxRows = 0;

    this.connection = connection;
    this.resultSetType = resultSetType;
    this.resultSetConcurrency = resultSetConcurrency;

    messages = new SQLDiagnostic(connection.getServerType());
  }

  /**
   * Called when this object goes out of scope to close any
   */
  protected void finalize() throws Throwable
  {
    super.finalize();
    try {
      close();
    } catch (SQLException e) {
      // Ignore errors
    }
  }

  protected SEResult executeCommand(String sql) throws SQLException
  {
    lastSql = sql;
    return connection.executeCommand(sql, maxRows);
  }

  /**
   * Get the statement's warnings list.
   */
  SQLDiagnostic getMessages()
  {
    return messages;
  }

  /**
   * Check that this statement is still open.
   */
  protected void checkOpen() throws SQLException
  {
    if (isClosed())
      throw new ResourceClosedException("Statement object is closed.", "HY010");
  }

  /**
   * Check that the exception is caused by the failure to open a
   * cursor and not by a more serious SQL error.
   *
   * @param e the exception returned by the cursor class
   * @throws SQLException if exception is not due to a cursor error
   */
  protected void checkCursorException(SQLException e) throws SQLException
  {
    if (connection == null
        || connection.isClosed()
        || "HYT00".equals(e.getSQLState())
        || "HY008".equals(e.getSQLState())) {
      // Serious error or timeout so return exception to caller
      throw e;
    }
    //
    // Check cursor specific errors and ranges for SQL Server
    //
    int error = e.getErrorCode();
    if (error >= 16900 && error <= 16999) {
      // Errors in this range are all related to the cursor API.
      // This is true for all versions of SQL Server.
      return;
    }
    if (error == 6819) {
      // A FOR XML clause was found
      return;
    }
    if (error == 8654) {
      // A inrow textptr exists
      return;
    }
    if (error == 8162) {
      // Formal parameter '%.*ls' was defined as OUTPUT but the actual
      // parameter not declared OUTPUT. This happens when trying to
      // execute a stored procedure with output parameters via a cursor.
      return;
    }
    //
    // More serious error we should rethrow the error and
    // not allow the driver to re-execute sql.
    //
    throw e;
  }

  /**
   * Report that user tried to call a method which has not been implemented.
   *
   * @param method The method name to report in the error message.
   * @throws SQLException
   */
  static void notImplemented(String method) throws SQLException
  {
    throw new SQLException(
        "error.generic.notimp", "HYC00");
  }

  /**
   * Close current result set (if any).
   */
  void closeCurrentResultSet() throws SQLException
  {
    try {
      if (currentResult != null) {
        currentResult.close();
      }
    } catch (SQLException e) {
      // Ignore
    } finally {
      currentResult = null;
    }
  }

  /**
   * Close all result sets.
   */
  void closeAllResultSets() throws SQLException
  {
    try {
      if (openResultSets != null) {
        for (int i = 0; i < openResultSets.size(); i++) {
          JdbcResultSet rs = (JdbcResultSet) openResultSets.get(i);
          if (rs != null) {
            rs.close();
          }
        }
      }
      closeCurrentResultSet();
    } finally {
      openResultSets = null;
    }
  }

  /**
   * Add an SQLWarning object to the statement warnings list.
   *
   * @param w The SQLWarning to add.
   */
  void addWarning(SQLWarning w)
  {
    messages.addWarning(w);
  }


  /**
   * Executes SQL to obtain a result set.
   *
   * @param sql       the SQL statement to execute
   * @param spName    optional stored procedure name
   * @param params    optional parameters
   * @param useCursor whether a cursor should be created for the SQL
   * @return the result set generated by the query
   */
  protected ResultSet executeSQLQuery(String sql,
                                      String spName,
                                      ParamInfo[] params,
                                      boolean useCursor)
      throws SQLException
  {
    if (spName != null || params != null) {
      throw new SQLFeatureNotSupportedException("stored procedures not supported.");
    }

    SEResult seResult = executeCommand(sql);

    switch (seResult.getStatus()) {
      case HAS_ERROR:
        throw new SQLException(seResult.getErrorMsg(), "24000");

      case HAS_AFFECTED_COUNT:
        // Expected to get a result set back.
        throw new SQLException("error.statement.noresult", "24000");

      case HAS_RESULT_SET:
        currentResult = new JdbcResultSet(this,
                                          ResultSet.TYPE_SCROLL_INSENSITIVE,
                                          ResultSet.CONCUR_READ_ONLY,
                                          seResult);
        return currentResult;

      default:
        final String msg = "Result status not implemented: " + seResult.getStatus().name();
        throw new JdbcDriverRuntimeException(msg);
    }
  }

  /**
   * Executes any type of SQL.
   *
   * @param sql       the SQL statement to execute
   * @param spName    optional stored procedure name
   * @param params    optional parameters
   * @param isUpdate    whether the caller is {@link #executeUpdate}
   * @param useCursor whether the requested result set type or concurrency
   *                  or connection properties request usage of a cursor
   * @return true    if the first result is a result set
   * @throws SQLException if an error condition occurs
   */
  protected boolean executeSQL(String sql,
                               String spName,
                               ParamInfo[] params,
                               boolean isUpdate,
                               boolean useCursor)
      throws SQLException
  {
    if (spName != null || params != null) {
      throw new SQLFeatureNotSupportedException("stored procedures not supported.");
    }

    SEResult seResult = executeCommand(sql);

    switch (seResult.getStatus()) {
      case HAS_ERROR:
        throw new SQLException(seResult.getErrorMsg(), "07000");

      case HAS_AFFECTED_COUNT:
        updateCount = (int) seResult.getAffectedCount();
        return false;

      case HAS_RESULT_SET:
        if (isUpdate) {
          // We were not supposed to receive a result set back.
          throw new SQLException("error.statement.gotresultset");
        }

        currentResult = new JdbcResultSet(this,
                                          ResultSet.TYPE_SCROLL_INSENSITIVE,
                                          ResultSet.CONCUR_READ_ONLY,
                                          seResult);
        return true;

      default:
        final String msg = "Result status not implemented: " + seResult.getStatus().name();
        throw new JdbcDriverRuntimeException(msg);
    }
  }

  /**
   * Resets the  Statement, by cleaning up all queued and
   * unprocessed results. Called by all execute methods and {@link #close()}
   *
   * @throws SQLException if an error occurs
   */
  protected void reset()
      throws SQLException
  {
    updateCount = -1;
    resultQueue.clear();
    genKeyResultSet = null;

    // don't throw old exceptions, they belong to a previous execution
    messages.clearWarnings();
    messages.exceptions = null;

    closeAllResultSets();
  }

  /**
   * Implements the common functionality for plain statement {@link #execute}
   * and {#link #executeUpdate}: basic checks, cleaning up of previous
   * results, setting up and executing the query and loading the first
   * results.
   *
   * @param sql               an SQL  INSERT   ,  UPDATE    or
   *                          DELETE    statement or an SQL statement that
   *                          returns nothing, such as an SQL DDL statement
   * @param autoGeneratedKeys a flag indicating whether auto-generated keys
   *                          should be made available for retrieval
   * @param update            boolean flag indicating whether the caller is
   *                          {@link #executeUpdate} -- in this case an exception is
   *                          thrown if the first result is not an update count and no
   *                          cursor is created (direct execution)
   * @return true    if the first result is a
   * ResultSet   ,  false    if it's an update
   * count
   * @see #execute
   * @see #executeUpdate
   */
  private boolean executeImpl(String sql, int autoGeneratedKeys, boolean update)
      throws SQLException
  {
    reset();
    if (sql == null || sql.length() == 0) {
      throw new SQLException("error.generic.nosql", "HY000");
    }

    String sqlWord = "";
    if (escapeProcessing) {
      String tmp[] = SQLParser.parse(sql, null, connection, false);

      if (tmp[1].length() != 0) {
        throw new SQLException(
            "error.statement.badsql", "07000");
      }

      sql = tmp[0];
      sqlWord = tmp[2];
    } else {
      // Escape processing turned off so
      // see if we can extract "insert" from start of statement
      sql = sql.trim();
      if (sql.length() > 5) {
        sqlWord = sql.substring(0, 6).toLowerCase();
      }
    }

    boolean returnKeys;

    if (autoGeneratedKeys == RETURN_GENERATED_KEYS) {

      // REVIEW: how would this fail and why?
      //
      // this will fail if we execute multiple statements at once and the first isn't an INSERT
      // returnKeys = "insert".equals(sqlWord);

      returnKeys = true;
    } else if (autoGeneratedKeys == NO_GENERATED_KEYS) {
      returnKeys = false;
    } else {
      throw new SQLException(
          "error.generic.badoption",
          "HY092");
    }



    return executeSQL(sql, null, null, update,
        !update && useCursor(returnKeys, sqlWord));
  }

  /**
   * Determines whether a cursor should be used based on the requested result
   * set type and concurrency, whether a cursor name has been set, the
   * useCursors    connection property has been set, the first
   * word in the SQL query is either SELECT or EXEC/EXECUTE and no generated
   * keys are returned.
   *
   * @param returnKeys indicates whether keys will be returned by the query
   * @param sqlWord    the first word in the SQL query; can be
   *                   null    if the caller is
   *                   {@link #executeQuery}
   * @return true    if a cursor should be used,  false
   * if not
   */
  protected boolean useCursor(boolean returnKeys, String sqlWord)
  {
    return false;
  }

  /**
   * Retrieve the default fetch size for this statement.
   *
   * @return the default fetch size for a new  ResultSet
   */
  int getDefaultFetchSize()
  {
    return (int) ((0 < maxRows && maxRows < DEFAULT_FETCH_SIZE)
                  ? maxRows : DEFAULT_FETCH_SIZE);
  }

// ------------------ java.sql.Statement methods ----------------------

  public int getFetchDirection() throws SQLException
  {
    checkOpen();

    return fetchDirection;
  }

  public int getFetchSize() throws SQLException
  {
    checkOpen();

    return fetchSize;
  }

  public int getMaxFieldSize() throws SQLException
  {
    checkOpen();

    return maxFieldSize;
  }

  public int getMaxRows() throws SQLException
  {
    checkOpen();

    return (int) maxRows;
  }

  public int getQueryTimeout() throws SQLException
  {
    checkOpen();

    return queryTimeout;
  }

  public int getResultSetConcurrency() throws SQLException
  {
    checkOpen();

    return resultSetConcurrency;
  }

  public int getResultSetHoldability() throws SQLException
  {
    checkOpen();

    return com.rapidsdata.sejdbcdriver.JdbcResultSet.HOLD_CURSORS_OVER_COMMIT;
  }

  public int getResultSetType() throws SQLException
  {
    checkOpen();

    return resultSetType;
  }

  /**
   * Retrieves the current result as an update count;
   * if the result is a ResultSet object or there are no more results, -1 is returned.
   * This method should be called only once per result.
   *
   * If the method getResultSet has already returned null,
   * which means that the result is not a ResultSet object,
   * then a return value of -1 of getUpdateCount means that there are no more results.
   *
   * @return the current result as an update count; -1 if the current result is a ResultSet object
   * or there are no more results
   */
  public int getUpdateCount() throws SQLException
  {
    checkOpen();
    return updateCount;
  }

  public long getLargeUpdateCount() throws SQLException {
    checkOpen();

    return (long)getUpdateCount();
  }

  public void cancel() throws SQLException
  {
    //checkOpen();

    //if (rdp != null) {
    //  rdp.cancel(false);
    //}
    throw new SQLFeatureNotSupportedException("cancel()");
  }

  public void clearBatch() throws SQLException
  {
    checkOpen();

    if (batchValues != null) {
      batchValues.clear();
    }
  }

  public void clearWarnings() throws SQLException
  {
    checkOpen();

    messages.clearWarnings();
  }

  @Override
  public void close()
      throws SQLException
  {
    // set to 'now closing'
    if (_Closed.compareAndSet(0, 1)) {
      // drop previous errors and warnings and consume all response tokens
      reset();

      // set closed flag, closeAllResultSets() still required statement
      // to be 'open'
      _Closed.set(2);

      // clean up everything
      connection.removeStatement(this);
      connection = null;
    }
  }

  public boolean getMoreResults() throws SQLException
  {
    checkOpen();

    return getMoreResults(CLOSE_ALL_RESULTS);
  }


  /**
   * Execute the SQL batch on a rdp datasource server.
   *
   * @param size the total size of the batch
   * @param executeSize the maximum number of statements to send in one request
   * @param counts the returned update counts
   * @return chained exceptions linked to a SQLException
   * @throws SQLException if a serious error occurs during execution
   */
  protected SQLException executeBatch(int size, int executeSize, ArrayList counts) throws SQLException {
    SQLException sqlEx = null;

    if (size == 0) {
      sqlEx = new SQLException("No statements found in batch list.");
      throw sqlEx;
    }

    for (int i = 0; i < size;) {
      String sql = (String) batchValues.get(i);
      String tmp[] = SQLParser.parse(sql, null, connection, false);

      ++i;

      if (tmp[2].equalsIgnoreCase("select")) {
        // TODO: Need to clean up any existing executed batched statements.
        return new SQLException("Not supported SELECT in batch execution");
      }


      SEResult result = executeCommand(sql);

      switch (result.getStatus()) {
        case HAS_AFFECTED_COUNT:
          counts.add(result.getAffectedCount());
          break;

        case HAS_RESULT_SET:
          return new SQLException("Result set not supported in statement batch.");

        case HAS_ERROR:
          return new SQLException(result.getErrorMsg());

        default:
          throw new JdbcDriverRuntimeException("Unimplemented result status: " + result.getStatus().name());
      }
    }
    return sqlEx;
  }

  /**
   * Submits a batch of commands to the database for execution and
   * if all commands execute successfully, returns an array of update counts.
   * The <code>long</code> elements of the array that is returned are ordered
   * to correspond to the commands in the batch, which are ordered
   * according to the order in which they were added to the batch.
   * The elements in the array returned by the method {@code executeLargeBatch}
   * may be one of the following:
   * <OL>
   * <LI>A number greater than or equal to zero -- indicates that the
   * command was processed successfully and is an update count giving the
   * number of rows in the database that were affected by the command's
   * execution
   * <LI>A value of <code>SUCCESS_NO_INFO</code> -- indicates that the command was
   * processed successfully but that the number of rows affected is
   * unknown
   * <P>
   * If one of the commands in a batch update fails to execute properly,
   * this method throws a <code>BatchUpdateException</code>, and a JDBC
   * driver may or may not continue to process the remaining commands in
   * the batch.  However, the driver's behavior must be consistent with a
   * particular DBMS, either always continuing to process commands or never
   * continuing to process commands.  If the driver continues processing
   * after a failure, the array returned by the method
   * <code>BatchUpdateException.getLargeUpdateCounts</code>
   * will contain as many elements as there are commands in the batch, and
   * at least one of the elements will be the following:
   *
   * <LI>A value of <code>EXECUTE_FAILED</code> -- indicates that the command failed
   * to execute successfully and occurs only if a driver continues to
   * process commands after a command fails
   * </OL>
   * <p>
   * This method should be used when the returned row count may exceed
   * {@link Integer#MAX_VALUE}.
   *<p>
   * The default implementation will throw {@code UnsupportedOperationException}
   *
   * @return an array of update counts containing one element for each
   * command in the batch.  The elements of the array are ordered according
   * to the order in which commands were added to the batch.
   * @exception SQLException if a database access error occurs,
   * this method is called on a closed <code>Statement</code> or the
   * driver does not support batch statements. Throws {@link BatchUpdateException}
   * (a subclass of <code>SQLException</code>) if one of the commands sent to the
   * database fails to execute properly or attempts to return a result set.
   * @throws SQLTimeoutException when the driver has determined that the
   * timeout value that was specified by the {@code setQueryTimeout}
   * method has been exceeded and has at least attempted to cancel
   * the currently running {@code Statement}
   *
   * @see #addBatch
   * @see DatabaseMetaData#supportsBatchUpdates
   * @since 1.8
   */
  public long[] executeLargeBatch()
      throws SQLException, BatchUpdateException
  {
    checkOpen();
    reset();

    if (batchValues == null || batchValues.size() == 0) {
      throw new SQLException("No statement found in batch list");
    }

    int size = batchValues.size();
    int executeSize = Integer.MAX_VALUE;
    SQLException sqlEx = null;
    ArrayList counts = new ArrayList(size);

    try {
      // Lock the connection, making sure the batch executes atomically. This is especially important in the
      // case of prepared statement batches (where we don't want the prepares rolled back before being executed)
      // but should also provide some level of sanity in the general case.
      synchronized (connection) {
        sqlEx = executeBatch(size, executeSize, counts);
      }

      // Ensure array is the same size as the original statement list
      long updateCounts[] = new long[size];
      // Copy the update counts into the int array
      int results = counts.size();
      for (int i = 0; i < results && i < size; i++) {
        updateCounts[i] = (long)counts.get(i);
      }
      // Pad any remaining slots with EXECUTE_FAILED
      for (int i = results; i < updateCounts.length; i++) {
        updateCounts[i] = EXECUTE_FAILED.longValue();
      }

      // See if we should return an exception
      if (sqlEx != null) {
        BatchUpdateException batchEx =
            new BatchUpdateException(sqlEx.getMessage(),
                sqlEx.getSQLState(),
                sqlEx.getErrorCode(),
                updateCounts,sqlEx); //(long[])updateCounts);
        // Chain any other exceptions
        batchEx.setNextException(sqlEx.getNextException());
        throw batchEx;
      }
      return updateCounts;
    } catch (BatchUpdateException ex) {
      // If it's a BatchUpdateException let it go
      throw ex;
    } catch (SQLException ex) {
      // An SQLException can only occur while sending the batch
      // (getBatchCounts() doesn't throw SQLExceptions), so we have to
      // end the batch and return the partial results

      throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(),
          ex.getErrorCode(), new int[0]);
    } finally {
      clearBatch();
    }
  }

  /**
   * Execute batch of SQL Statements.
   * <p/>
   * The JDBC3 standard says that the behavior of this method must be
   * consistent for any DBMS. As Sybase (and to a lesser extent SQL Server)
   * will sometimes continue after a batch execution error, the only way to
   * comply with the standard is to always return an array of update counts
   * the same size as the batch list. Slots in the array beyond the last
   * executed statement are set to  EXECUTE_FAILED   . <p/>
   * <p>
   * There is a problem with certain statements, returning more update counts
   * than there are batch operations. (see bug [])
   *
   * @return update counts as an  int[]
   */
  public int[] executeBatch()
      throws SQLException, BatchUpdateException
  {
    checkOpen();
    reset();

    if (batchValues == null || batchValues.size() == 0) {
    //  return new int[0];
      throw new SQLException("No statement found in batch list");
    }

    int size = batchValues.size();
    int executeSize = Integer.MAX_VALUE;
    SQLException sqlEx = null;
    ArrayList counts = new ArrayList(size);

    try {
      // Lock the connection, making sure the batch executes atomically. This is especially important in the
      // case of prepared statement batches (where we don't want the prepares rolled back before being executed)
      // but should also provide some level of sanity in the general case.
      synchronized (connection) {
          sqlEx = executeBatch(size, executeSize, counts);
      }

      // Ensure array is the same size as the original statement list
      int updateCounts[] = new int[size];
      // Copy the update counts into the int array
      int results = counts.size();
      for (int i = 0; i < results && i < size; i++) {
        updateCounts[i] = toIntExact((long)counts.get(i));
      }
      // Pad any remaining slots with EXECUTE_FAILED
      for (int i = results; i < updateCounts.length; i++) {
        updateCounts[i] = EXECUTE_FAILED.intValue();
      }

      // See if we should return an exception
      if (sqlEx != null) {
        BatchUpdateException batchEx =
            new BatchUpdateException(sqlEx.getMessage(),
                sqlEx.getSQLState(),
                sqlEx.getErrorCode(),
                updateCounts);
        // Chain any other exceptions
        batchEx.setNextException(sqlEx.getNextException());
        throw batchEx;
      }
      return updateCounts;
    } catch (BatchUpdateException ex) {
      // If it's a BatchUpdateException let it go
      throw ex;
    } catch (SQLException ex) {
      // An SQLException can only occur while sending the batch
      // (getBatchCounts() doesn't throw SQLExceptions), so we have to
      // end the batch and return the partial results

      throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(),
          ex.getErrorCode(), new int[0]);
    } finally {
      clearBatch();
    }
  }

  public void setFetchDirection(int direction) throws SQLException
  {
    checkOpen();
    switch (direction) {
      case ResultSet.FETCH_FORWARD:
        fetchDirection = direction;
        break;

      case ResultSet.FETCH_UNKNOWN:
        throw new SQLFeatureNotSupportedException("setFetchDirection(FETCH_UNKNOWN)");

      case ResultSet.FETCH_REVERSE:
        throw new SQLFeatureNotSupportedException("setFetchDirection(FETCH_REVERSE)");

      default:
        throw new SQLException(
            "error.generic.badoption",
            "24000");
    }
  }

  public void setFetchSize(int rows) throws SQLException
  {
    checkOpen();

    if (rows < 0) {
      throw new SQLException(
          "error.generic.optltzero",
          "HY092");
    } else if (maxRows > 0 && rows > maxRows) {
      throw new SQLException(
          "error.statement.gtmaxrows", "HY092");
    }
    if (rows == 0) {
      rows = getDefaultFetchSize();
    }
    fetchSize = rows;
  }

  public void setMaxFieldSize(int max) throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("setMaxFieldSize()");
//
//    if (max < 0) {
//      throw new SQLException(
//          "error.generic.optltzero",
//          "HY092");
//    }
//
//    maxFieldSize = max;
  }

  public void setMaxRows(int max) throws SQLException
  {
    checkOpen();

    if (max < 0) {
      throw new SQLException(
          "error.generic.optltzero",
          "HY092");
    }
    if (max > 0 && max < fetchSize) {
      // Just for consistency with setFetchSize()
      fetchSize = max;
    }
    maxRows = max;
  }

  public void setQueryTimeout(int seconds) throws SQLException
  {
    checkOpen();

    if (seconds < 0) {
      throw new SQLException(
          "error.generic.optltzero",
          "HY092");
    }

    queryTimeout = seconds;

    throw new SQLFeatureNotSupportedException("setQueryTimeout(int seconds)");
  }

  public boolean getMoreResults(int current) throws SQLException
  {
    checkOpen();

    switch (current) {
      case CLOSE_ALL_RESULTS:
        updateCount = -1;
        closeAllResultSets();
        break;
      case CLOSE_CURRENT_RESULT:
        updateCount = -1;
        closeCurrentResultSet();
        break;
      case KEEP_CURRENT_RESULT:
        updateCount = -1;
        // If there is an open result set it is transferred to
        // the list of open result sets. For JdbcResultSet
        // result sets we cache the remaining data. For CachedResultSet
        // result sets the data is already cached.
        if (openResultSets == null) {
          openResultSets = new ArrayList();
        }
        if (currentResult != null) {
          currentResult.cacheResultSetRows();
          openResultSets.add(currentResult);
        }
        currentResult = null;
        break;
      default:
        throw new SQLException(
            "error.generic.badoption",
            "HY092");
    }

    // Check for server side errors
    messages.checkErrors();

    // Dequeue any results
    if (!resultQueue.isEmpty()) {
      Object nextResult = resultQueue.removeFirst();

      // Next result is an update count
      if (nextResult instanceof Integer) {
        updateCount = ((Integer) nextResult).intValue();
        return false;
      }

      // Next result is a ResultSet. Set currentResult and remove it.
      currentResult = (JdbcResultSet) nextResult;
      return true;
    } else {
      return false;
    }
  }

  public void setEscapeProcessing(boolean enable) throws SQLException
  {
    checkOpen();

    escapeProcessing = enable;
  }

  public int executeUpdate(String sql) throws SQLException
  {
    return executeUpdate(sql, NO_GENERATED_KEYS);
  }

  /**
   * Executes the given SQL statement, which may be an <code>INSERT</code>,
   * <code>UPDATE</code>, or <code>DELETE</code> statement or an
   * SQL statement that returns nothing, such as an SQL DDL statement.
   * <p>
   * This method should be used when the returned row count may exceed
   * {@link Integer#MAX_VALUE}.
   * <p>
   * <strong>Note:</strong>This method cannot be called on a
   * <code>PreparedStatement</code> or <code>CallableStatement</code>.
   *<p>
   * The default implementation will throw {@code UnsupportedOperationException}
   *
   * @param sql an SQL Data Manipulation Language (DML) statement,
   * such as <code>INSERT</code>, <code>UPDATE</code> or
   * <code>DELETE</code>; or an SQL statement that returns nothing,
   * such as a DDL statement.
   *
   * @return either (1) the row count for SQL Data Manipulation Language
   * (DML) statements or (2) 0 for SQL statements that return nothing
   *
   * @exception SQLException if a database access error occurs,
   * this method is called on a closed <code>Statement</code>, the given
   * SQL statement produces a <code>ResultSet</code> object, the method is called on a
   * <code>PreparedStatement</code> or <code>CallableStatement</code>
   * @throws SQLTimeoutException when the driver has determined that the
   * timeout value that was specified by the {@code setQueryTimeout}
   * method has been exceeded and has at least attempted to cancel
   * the currently running {@code Statement}
   * @since 1.8
   */
  public long executeLargeUpdate(String sql) throws SQLException
  {
    int iVal = executeUpdate(sql, NO_GENERATED_KEYS);
    return Long.valueOf(iVal);
  }

  public long executeLargeUpdate(String sql, int autoGeneratedKeys) throws SQLException
  {
    if (autoGeneratedKeys != NO_GENERATED_KEYS) {
      throw new SQLFeatureNotSupportedException("executeLargeUpdate(String,int)");
    }

    int iVal = executeUpdate(sql, NO_GENERATED_KEYS);
    return Long.valueOf(iVal);
  }

  public void addBatch(String sql) throws SQLException
  {
    checkOpen();

    if (sql == null) {
      throw new NullPointerException();
    }

    if (batchValues == null) {
      batchValues = new ArrayList();
    }

    if (escapeProcessing) {
      String tmp[] = SQLParser.parse(sql, null, connection, false);

      if (tmp[1].length() != 0) {
        throw new SQLException(
            "error.statement.badsql", "07000");
      }

      sql = tmp[0];
    }

    batchValues.add(sql);
  }

  public void setCursorName(String name) throws SQLException
  {
    checkOpen();
    /*
    cursorName = name;
    if (name != null) {
      // Reset statement type to JDBC 1 default.
      resultSetType = ResultSet.TYPE_FORWARD_ONLY;
      fetchSize = 1; // Needed for positioned updates
    }*/
    throw new SQLFeatureNotSupportedException("setCursorName(String name)");
  }

  public boolean execute(String sql) throws SQLException
  {
    checkOpen();

    return executeImpl(sql, NO_GENERATED_KEYS, false);
  }

  public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException
  {
    checkOpen();
    if (autoGeneratedKeys == Statement.NO_GENERATED_KEYS) {
      executeImpl(sql, autoGeneratedKeys, true);

      int res = getUpdateCount();
      return res == -1 ? 0 : res;
    } else {
      throw new SQLFeatureNotSupportedException("executeUpdate(String sql, int autoGeneratedKeys)");
    }
  }

  public boolean execute(String sql, int autoGeneratedKeys) throws SQLException
  {
    checkOpen();

    if (autoGeneratedKeys != Statement.NO_GENERATED_KEYS) {
      throw new SQLFeatureNotSupportedException("execute(String, int)");
    }

    return executeImpl(sql, autoGeneratedKeys, false);
  }

  public int executeUpdate(String sql, int[] columnIndexes) throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("executeUpdate(String,int[]");

//    if (columnIndexes == null) {
//      throw new SQLException(
//          "error.generic.nullparam", "HY092");
//    } else if (columnIndexes.length != 1) {
//      throw new SQLException(
//          "error.generic.needcolindex", "HY092");
//    }
//
//    return executeUpdate(sql, RETURN_GENERATED_KEYS);
  }

  public boolean execute(String sql, int[] columnIndexes) throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("execute(String,int[]");

//    if (columnIndexes == null) {
//      throw new SQLException(
//          "error.generic.nullparam", "HY092");
//    } else if (columnIndexes.length != 1) {
//      throw new SQLException(
//          "error.generic.needcolindex", "HY092");
//    }
//
//    return executeImpl(sql, RETURN_GENERATED_KEYS, false);
  }

  @Override
  public Connection getConnection() throws SQLException
  {
    checkOpen();
    return connection;
  }

  @Override
  public ResultSet getGeneratedKeys()
      throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("getGeneratedKeys()");

//    if (genKeyResultSet == null) {
//      // create and return an empty result set
//      genKeyResultSet = new CachedResultSet(this, new String[]{"ID"}, new int[]{Types.INTEGER});
//    }
//
//    // non't allow manipulation
//    genKeyResultSet.setConcurrency(ResultSet.CONCUR_READ_ONLY);
//
//    return genKeyResultSet;
  }

  public ResultSet getResultSet() throws SQLException
  {
    checkOpen();
    //
    //
    // See if we are returning a forward read only resultset
    //
    if (currentResult == null ||
        (resultSetType == ResultSet.TYPE_FORWARD_ONLY &&
            resultSetConcurrency == ResultSet.CONCUR_READ_ONLY)) {
      return currentResult;
    }
    //
    // OK Now create a CachedResultSet based on the existng result set.
    //
    currentResult = new CachedResultSet(currentResult, true);

    return currentResult;
  }

  public SQLWarning getWarnings() throws SQLException
  {
    checkOpen();

    return messages.getWarnings();
  }

  public int executeUpdate(String sql, String[] columnNames) throws SQLException
  {
    checkOpen();

    /*
    if (columnNames == null) {
      throw new SQLException(
          "error.generic.nullparam", "HY092");
    } else if (columnNames.length != 1) {
      throw new SQLException(
          "error.generic.needcolname", "HY092");
    }*/

    //return executeUpdate(sql, RETURN_GENERATED_KEYS);
    throw new SQLFeatureNotSupportedException("executeUpdate(String sql, String[] columnNames)");
  }

  public boolean execute(String sql, String[] columnNames) throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("execute(String,String[]");

//    if (columnNames == null) {
//      throw new SQLException(
//          "error.generic.nullparam", "HY092");
//    } else if (columnNames.length != 1) {
//      throw new SQLException(
//          "error.generic.needcolname", "HY092");
//    }
//
//    return executeImpl(sql, RETURN_GENERATED_KEYS, false);
  }

  public ResultSet executeQuery(String sql) throws SQLException
  {
    checkOpen();
    reset();

    if (sql == null || sql.length() <= 1) {
      throw new SQLException("error.generic.nosql", "HY000");
    }
    if (escapeProcessing) {
      String tmp[] = SQLParser.parse(sql, null, connection, false);

      if (tmp[1].length() != 0) {
        throw new SQLException(
            "error.statement.badsql", "07000");
      }

      sql = tmp[0];
    }

    return executeSQLQuery(sql, null, null, useCursor(false, null));
  }


  /**
   * @return whether this {@link JdbcStatement} has been closed
   */
  @Override
  public boolean isClosed()
      throws SQLException
  {
    return _Closed.get() == 2;
  }

  /* (non-Javadoc)
   * @see java.sql.Statement#isPoolable()
   */
  public boolean isPoolable() throws SQLException
  {
    checkOpen();
    return false;
  }

  /* (non-Javadoc)
   * @see java.sql.Statement#setPoolable(boolean)
   */
  public void setPoolable(boolean poolable) throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException("setPoolable(boolean poolable)");
  }

  /* (non-Javadoc)
   * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
   */
  public boolean isWrapperFor(Class arg0) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

  @Override
  public <T> T unwrap(Class<T> iface) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

  //// JDBC4.1 demarcation, do NOT put any JDBC3/4.0 code below this line ////

  @Override
  public void closeOnCompletion() throws SQLException
  {
    closeOnCompletion = true;
  }

  @Override
  public boolean isCloseOnCompletion() throws SQLException
  {

    return closeOnCompletion;
  }

  @Override
  public long getLargeMaxRows() throws SQLException
  {
    checkOpen();
    return maxRows;
  }

  @Override
  public void setLargeMaxRows(long maxRows) throws SQLException
  {
    checkOpen();

    if (maxRows < 0) {
      throw new SQLException("error.statement.invalidValue");
    }

    this.maxRows = maxRows;
  }
}