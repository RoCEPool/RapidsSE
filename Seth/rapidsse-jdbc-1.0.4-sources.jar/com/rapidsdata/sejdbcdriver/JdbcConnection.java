
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

// Note that many APIs that we don't support, such as prepared statement

package com.rapidsdata.sejdbcdriver;

import java.lang.ref.WeakReference;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.Semaphore;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jcabi.aspects.Loggable;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.rapidsdata.sejdbcdriver.exceptions.JdbcDriverRuntimeException;
import com.rapidsdata.sejdbcdriver.exceptions.ResourceClosedException;
import com.rapidsdata.seshellapi.*;
import com.rapidsdata.seshellapi.exceptions.SEProtocolException;
import org.slf4j.LoggerFactory;


/**
 * Rapids JDBC implementation of the java.sql.Connection interface.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class JdbcConnection implements java.sql.Connection
{
  /**
   * The logger for this class.
   */
  private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(JdbcConnection.class.getName());

  /** The orginal connection URL. */
  private final String url;

  /** The requested catalog name. */
  private String catalogName;

  /** The requested schema name. */
  private String schemaName;

  /** The cached currentCatalog name from the last time the current catalog was set. */
  private String currentCatalog=null;

  /** The cached currentSchema name from the last time the current schema was set. */
  private String currentSchema=null;

  /** True if this connection is closed. */
  private boolean closed;

  /** True if this connection is read only. */
  private boolean readOnly = false;

  /** List of statements associated with this connection. */
  private final ArrayList statements = new ArrayList();

  /** Default transaction isolation level. */
  private int transactionIsolation = java.sql.Connection.TRANSACTION_NONE;

  /** Default auto commit state. */
  private boolean autoCommit = true;

  /** Diagnostc messages for this connection. */
  private final SQLDiagnostic messages;

  /** Maximum decimal precision. */
  private int maxPrecision = 28;

  /** Send parameters as unicode. */
  private boolean useUnicode = false;

  /** Mutual exclusion lock to control access to connection. */
  private final Semaphore mutex = new Semaphore(1);

  /** The directory to buffer data to. */
  private File bufferDir;

  /** Map large types (IMAGE and TEXT/NTEXT) to LOBs by default. */
  private boolean useLOBs;

  /** The class we use for communicating with RapidsSE. */
  private final SEProtocol seProtocol;

  /** The path to the SE Shell executable. */
  private String pathToSeShell;

  /** The arguments to SE Shell. */
  private String seShellArgs;

  /** Used when the user wishes to use the default arguments and then add
   * additional ones, as opposed to rewriting over the top of the default args. */
  private String seShellExtraArgs;

  /** The hostname/IP address to use where the SE Shell resides. */
  private String sshHost;

  /** The SSH port number to use where the SE Shell resides. */
  private short sshPort;

  /**
   * The username to use for authenticating with SSH, if SSH is being used
   * to execute SE Shell.
   */
  private String sshUser;

  /** Cached version string of SE. */
  private String versionString = null;

  /** Cached major version number of SE. */
  private int majorVersion = -1;

  /** Cached minor version number of SE. */
  private int minorVersion = -1;

  /**
   * Create a new database connection.
   *
   * @param url  The connection URL starting jdbc:jrdp:.
   * @param info The additional connection properties.
   * @throws SQLException
   */
  JdbcConnection(String url, Properties info)
      throws SQLException
  {
    this.url = url;

    //
    // Extract properties into instance variables
    //
    unpackProperties(info);

    messages = new SQLDiagnostic(1);

    try {
      // TODO: Create the SEConnection with a timeout value, so that we fail
      // TODO: if it takes too long.
      SEConnection seConnection = createSEConnection();

      // Now create the SE that uses the seConnection.
      seProtocol = new SEShellProtocolV1(seConnection);

      if (catalogName != null && !catalogName.isEmpty()) {
        setCatalog(catalogName);
      }
      if (schemaName != null && !schemaName.isEmpty()) {
        setSchema(schemaName);
      }

    } catch (SEProtocolException e) {
      close();
      throw new SQLException(e.getMessage(), e);

    } catch (IOException e) {
      close();
      throw new SQLException(e.getMessage(), "08S01");

    } catch (SQLException e) {
      close();
      throw e;

    } catch (RuntimeException e) {
      close();
      throw new SQLException(e.getMessage());
    }
  }

  /**
   * Ensure all resources are released.
   */
  protected void finalize()
      throws Throwable
  {
    try {
      close();
    } finally {
      super.finalize();
    }
  }

  /**
   * Creates a new connection to SE, either locally or via SSH.
   * @return the SE Connection.
   * @throws IOException
   */
  private SEConnection createSEConnection() throws IOException
  {
    SEConnection connection;
    String[] args = seShellArgs.split(" ");
    String[] extraArgs = seShellExtraArgs.split(" ");

    String[] allArgs = args;

    if (extraArgs.length > 0) {
      // concatenate them!
      allArgs = Arrays.copyOf(args, args.length + extraArgs.length);
      System.arraycopy(extraArgs, 0, allArgs, args.length, extraArgs.length);
    }

    if (sshHost.isEmpty()) {
      connection = new LocalSEConnection(pathToSeShell, allArgs);

    } else {
      try {
        connection = new SshSEConnection(sshUser, sshHost, sshPort, null, pathToSeShell, allArgs);

      } catch (JSchException e) {
        throw new IOException(e.getMessage(), e);
      }
    }

    return connection;
  }

  /**
   * Executes a SQL command against RapidsSE.
   * @param command the command to execute.
   * @return a RapidsSE result object.
   * @throws SQLException
   */
  protected SEResult executeCommand(String command) throws SQLException
  {
    return executeCommand(command, 0);
  }

  /**
   * Executes a SQL command against RapidsSE.
   * @param command the command to execute.
   * @param maxRows the maximum number of rows for this statement to return.
   *                Additional rows will be silently dropped. Set to 0
   *                for no limit.
   * @return a RapidsSE result object.
   * @throws SQLException
   */
  protected SEResult executeCommand(String command, long maxRows) throws SQLException
  {
    SEResult result;

    checkOpen();

    long oldMaxRows = seProtocol.getMaxRows();

    try {
      seProtocol.setMaxRows(maxRows);
      result = seProtocol.executeCommand(command);

    } catch (SEProtocolException | InterruptedException | IOException e) {
      // TODO: Set SQLState error codes.
      throw new SQLException(e);

    } finally {
      try {
        seProtocol.setMaxRows(oldMaxRows);
      } catch (SEProtocolException e) {/*ignore*/}
    }

    return result;
  }

  /**
   * Retrieves the server type. Always type 1
   */
  public int getServerType()
  {
    return 1;
  }

  /**
   * Retrieves the maximum decimal precision.
   *
   * @return the precision as an  int
   */
  public int getMaxPrecision()
  {
    return maxPrecision;
  }


  /**
   * Indicates whether large types (IMAGE and TEXT/NTEXT) should be mapped by
   * default to LOB types or  String    and  byte[]
   * respectively.
   *
   * @return true    if the default mapping should be to LOBs,
   * false    otherwise
   */
  boolean getUseLOBs()
  {
    return useLOBs;
  }

  /**
   * Returns the directory where data should be buffered to.
   *
   * @return the directory where data should be buffered to.
   */
  File getBufferDir()
  {
    return bufferDir;
  }

  /**
   * Retrieves the database name for this connection.
   *
   * @return the database name
   */
  //@Override
  public String getSchema() throws SQLException
  {
    checkOpen();

    return null;

//    try {
//      Statement stmt = createStatement();
//      ResultSet rs = stmt.executeQuery("SELECT CURRENT_SCHEMA FROM RAPIDS.SYSTEM.SCHEMAS LIMIT 1;");
//      rs.next();
//      String schema = rs.getString(1);
//      rs.close();
//      stmt.close();
//      currentSchema = schema;
//    } catch (SQLException se) {
//     throw se;
//    } catch (Exception e) {
//      throw new SQLException(e);
//    }
//    return currentSchema;
  }

  /**
   * Transfers the properties to the local instance variables.
   *
   * @param info The connection properties Object.
   * @throws SQLException If an invalid property value is found.
   */
  protected void unpackProperties(Properties info)
      throws SQLException
  {
    schemaName  = info.getProperty(Driver.SCHEMANAME);
    catalogName = info.getProperty(Driver.CATALOGNAME);
    useLOBs     = parseBooleanProperty(info, Driver.USELOBS);
    bufferDir   = new File(info.getProperty(Driver.BUFFERDIR));
    if (!bufferDir.isDirectory()) {
      if (!bufferDir.mkdirs()) {
        throw new SQLException(Driver.BUFFERDIR, "08001");
      }
    }

    pathToSeShell = info.getProperty(Driver.SESHELLPATH);
    seShellArgs   = info.getProperty(Driver.SESHELLARGS);
    seShellExtraArgs = info.getProperty(Driver.SESHELLEXTRAARGS);

    sshHost       = info.getProperty(Driver.SSHHOST);
    sshPort       = parseShortProperty(info, Driver.SSHPORT);
    sshUser       = info.getProperty(Driver.SSHUSER);
  }

  /**
   * Parse a string property value into an boolean value.
   *
   * @param info The connection properties object.
   * @param key  The message key used to retrieve the property name.
   * @return The boolean value of the string property value.
   * @throws SQLException If the property value can't be parsed.
   */
  private static boolean parseBooleanProperty(final Properties info, final String key)
      throws SQLException
  {
    final String propertyName = key;
    String prop = info.getProperty(propertyName);
    if (!(prop == null || "true".equalsIgnoreCase(prop) || "false".equalsIgnoreCase(prop)))
      throw new SQLException("error.connection.badprop", "08001");

    return "true".equalsIgnoreCase(prop);
  }

  /**
   * Parse a string property value into an short value.
   *
   * @param info The connection properties object.
   * @param key  The message key used to retrieve the property name.
   * @return The short value of the string property value.
   * @throws SQLException If the property value can't be parsed.
   */
  private static short parseShortProperty(final Properties info, final String key)
      throws SQLException
  {

    final String propertyName = key;
    try {
      return Short.parseShort(info.getProperty(propertyName));
    } catch (NumberFormatException e) {
      throw new SQLException(
          propertyName, "08001");
    }
  }

  /**
   * Parse a string property value into an integer value.
   *
   * @param info The connection properties object.
   * @param key  The message key used to retrieve the property name.
   * @return The integer value of the string property value.
   * @throws SQLException If the property value can't be parsed.
   */
  private static int parseIntegerProperty(final Properties info, final String key)
      throws SQLException
  {

    final String propertyName = key;
    try {
      return Integer.parseInt(info.getProperty(propertyName));
    } catch (NumberFormatException e) {
      throw new SQLException(
          propertyName, "08001");
    }
  }

  /**
   * Parse a string property value into a long value.
   *
   * @param info The connection properties object.
   * @param key  The message key used to retrieve the property name.
   * @return The long value of the string property value.
   * @throws SQLException If the property value can't be parsed.
   */
  private static long parseLongProperty(final Properties info, final String key)
      throws SQLException
  {

    final String propertyName = key;
    try {
      return Long.parseLong(info.getProperty(propertyName));
    } catch (NumberFormatException e) {
      throw new SQLException(
          propertyName, "08001");
    }
  }

  /**
   * Retrieve the Java charset to use for encoding.
   *
   * @return the Charset name as a  String
   */
  protected String getCharset()
  {
    //return charsetInfo.getCharset();
    return "ISO-8859-1";
  }

  /**
   * Retrieve the sendParametersAsUnicode flag.
   *
   * @return boolean    true if parameters should be sent as unicode.
   */
  protected boolean getUseUnicode()
  {
    return useUnicode;
  }

  /**
   * Removes a statement object from the list maintained by the connection
   * and cleans up the statement cache if necessary.
   * <p>
   * Synchronized because it accesses the statement list, the statement cache
   * and the  rdpProt   .
   *
   * @param statement the statement to remove
   */
  synchronized void removeStatement(JdbcStatement statement)
      throws SQLException
  {
    // Remove the JdbcStatement from the statement list
    synchronized (statements) {
      for (int i = 0; i < statements.size(); i++) {
        WeakReference wr = (WeakReference) statements.get(i);

        if (wr != null) {
          Statement stmt = (Statement) wr.get();

          // Remove the statement if found but also remove all
          // statements that have already been garbage collected
          if (stmt == null || stmt == statement) {
            statements.set(i, null);
          }
        }
      }
    }


  }

  /**
   * Adds a statement object to the list maintained by the connection.
   * <p/>
   * WeakReferences are used so that statements can still be closed and
   * garbage collected even if not explicitly closed by the connection.
   *
   * @param statement statement to add
   */
  void addStatement(JdbcStatement statement)
  {
    synchronized (statements) {
      for (int i = 0; i < statements.size(); i++) {
        WeakReference wr = (WeakReference) statements.get(i);

        // FIXME: entries from statements should be dropped immediately
        // FIXME: on GC, instead of being kept until overwritten or connection
        // FIXME: being closed

        if (wr == null || wr.get() == null) {
          statements.set(i, new WeakReference(statement));
          return;
        }
      }

      statements.add(new WeakReference(statement));
    }
  }

  /**
   * Checks that the connection is still open.
   *
   * @throws SQLException if the connection is closed
   */
  void checkOpen() throws ResourceClosedException
  {
    if (closed) {
      throw new ResourceClosedException("Connection object is closed.", "HY010");
    }
  }

  /**
   * Checks that this connection is in local transaction mode.
   *
   * @param method the method name being tested
   * @throws SQLException if in XA distributed transaction mode
   */
  void checkLocal(String method) throws SQLException
  {
    if (closed) {
      //xaTransaction)
      throw new SQLException(method, "HY010");
    }
  }

  /**
   * Retrieves the original connection URL.
   *
   * @return the connection url as a  String
   */
  String getURL()
  {
    return url;
  }


  /**
   * Retrieves the connection mutex and acquires an exclusive lock on the
   * network connection.
   *
   * @return the mutex object as a  Semaphore
   */
  Semaphore getMutex()
  {
    boolean interrupted = false;

    while (true) {
      // JDBC can not be interrupted, retry on InterruptedException
      try {
        mutex.acquire();
        break;
      } catch (InterruptedException e) {
        // interrupt status is cleared now
        interrupted = true;
      }
    }


    if (interrupted) {
      Thread.currentThread().interrupt();
    }

    return mutex;
  }

  //
  // ------------------- java.sql.Connection interface methods -------------------
  //

  public int getHoldability() throws SQLException
  {
    checkOpen();

    return com.rapidsdata.sejdbcdriver.JdbcResultSet.HOLD_CURSORS_OVER_COMMIT;
  }

  synchronized public int getTransactionIsolation() throws SQLException
  {
    checkOpen();
    return transactionIsolation;
  }

  synchronized public void clearWarnings() throws SQLException
  {
    checkOpen();
    messages.clearWarnings();
  }

  /**
   * Releases this  Connection    object's database and JDBC
   * resources immediately instead of waiting for them to be automatically
   * released.
   * Synchronized because it accesses the statement list and the
   * rdpProt.
   *
   * @throws SQLException if a database access error occurs
   */
  synchronized public void close() throws SQLException
  {
    //checkOpen();
    if (!closed) {
      try {
        // Close any open statements
        ArrayList tmpList;

        synchronized (statements) {
          tmpList = new ArrayList(statements);
          statements.clear();
        }

        for (int i = 0; i < tmpList.size(); i++) {
          WeakReference wr = (WeakReference) tmpList.get(i);

          if (wr != null) {
            Statement stmt = (Statement) wr.get();
            if (stmt != null) {
              try {
                stmt.close();
              } catch (SQLException ex) {
                // Ignore
              }
            }
          }
        }

        try {
          // Tell the server the session is ending, close network connection
          if (seProtocol != null) {
            // Send a bye command so that we don't leak SE processes.
            seProtocol.executeCommand("bye;");
            seProtocol.close();
          }
        } catch (IOException | SEProtocolException | InterruptedException ex) {
          // Ignore
        }

      } finally {
        closed = true;
      }
    }
  }

  public void commit() throws SQLException
  {
    checkOpen();
    checkLocal("commit");

    throw new SQLFeatureNotSupportedException("commit()", "25000");
  }

  public void rollback() throws SQLException
  {
    checkOpen();
    checkLocal("rollback");

    throw new SQLFeatureNotSupportedException("rollback()", "25000");
  }

  public boolean getAutoCommit() throws SQLException
  {
    checkOpen();

    return autoCommit;
  }

  public boolean isClosed() throws SQLException
  {
    return closed;
  }

  public boolean isReadOnly() throws SQLException
  {
    checkOpen();

    return readOnly;
  }

  public void setHoldability(int holdability) throws SQLException
  {
    checkOpen();

    switch (holdability) {
      case com.rapidsdata.sejdbcdriver.JdbcResultSet.HOLD_CURSORS_OVER_COMMIT:
        break;

      case com.rapidsdata.sejdbcdriver.JdbcResultSet.CLOSE_CURSORS_AT_COMMIT:
        throw new SQLFeatureNotSupportedException("setHoldability: CLOSE_CURSORS_AT_COMMIT", "HY092");

      default:
        throw new SQLException("Invalid holdability value: " + Integer.toString(holdability), "HY092");
    }
  }

  synchronized public void setTransactionIsolation(int level) throws SQLException
  {
    checkOpen();
    if (level < TRANSACTION_NONE || level > TRANSACTION_SERIALIZABLE) {
      final String msg = "Invalid value (" + level + ") passed to setTransactionIsolation(int)";
      throw new SQLException(msg);
    }

    if (level != TRANSACTION_NONE) {
      final String msg = "setTransactionIsolation(int) is not supported except at the TRANSACTION_NONE level.";
      throw new SQLFeatureNotSupportedException(msg);
    }

    transactionIsolation = level;

  }

  public void setAutoCommit(boolean autoCommit) throws SQLException
  {
    checkOpen();
    // RDP will only support autocommit at present.
    if (!autoCommit) {
      throw new SQLFeatureNotSupportedException("setAutoCommit(false)");
    }

    checkLocal("setAutoCommit");
    if (this.autoCommit == autoCommit) {
      return;
    }


    this.autoCommit = autoCommit;
  }

  public void setReadOnly(boolean readOnly) throws SQLException
  {
    checkOpen();

    if (readOnly) {
      final String msg = "setReadOnly(true) not supported.";
      throw new SQLFeatureNotSupportedException(msg);
    }

    this.readOnly = readOnly;
  }

  synchronized public String getCatalog() throws SQLException
  {
    checkOpen();

    return null;

//    Statement stmt = null;
//    ResultSet rs = null;
//
//    try {
//      stmt = createStatement();
//      // TODO: Update SQL statement for SE
//      rs = stmt.executeQuery("SELECT CURRENT_CATALOG FROM RAPIDS.SYSTEM.CATALOGS LIMIT 1;");
//      rs.next();
//      String catalog = rs.getString(1);
//      currentCatalog = catalog;
//
//    } catch (SQLException se) {
//      //Handle errors for JDBC
//      throw se;
//
//    } catch (Exception e) {
//      throw new SQLException(e.getMessage());
//
//    } finally {
//      if (rs != null) {
//        rs.close();
//      }
//
//      if (stmt != null) {
//        stmt.close();
//      }
//    }
//
//    return currentCatalog;
  }

  synchronized public void setCatalog(String catalog) throws SQLException
  {
    checkOpen();

    if (currentCatalog != null && currentCatalog.equals(catalog)) {
      return;
    }

    throw new SQLFeatureNotSupportedException("setCatalog(String)");

    // TODO: Update sql for SE.
//    String sql = "SET CATALOG ";
//    sql += catalog;
//    sql += ";";
//
//    Statement stmt = null;
//
//    try {
//      stmt = createStatement();
//      stmt.executeUpdate(sql);
//      currentCatalog = catalog;
//
//    } catch (SQLException se) {
//      //Handle errors for JDBC
//      throw se;
//
//    } catch (Exception e) {
//      throw new SQLException(e.getMessage());
//
//    } finally {
//      if (stmt != null) {
//        stmt.close();
//      }
//    }
  }


  synchronized public void setSchema(String schema) throws SQLException
  {
    checkOpen();

    if (currentSchema != null && currentSchema.equals(schema)) {
      return;
    }

    throw new SQLFeatureNotSupportedException("setSchema(String)");

    // TODO: Update sql for SE.
//    String sql = "SET SCHEMA ";
//    sql += schema;
//    sql += ";";
//
//    Statement stmt = null;
//
//    try {
//      stmt = createStatement();
//      stmt.executeUpdate(sql);
//      currentSchema = schema;
//
//    } catch (SQLException se) {
//      throw se;
//
//    } catch (Exception e) {
//      throw new SQLException(e.getMessage());
//
//    } finally {
//      if (stmt != null) {
//        stmt.close();
//      }
//    }
  }

  public DatabaseMetaData getMetaData() throws SQLException
  {
    checkOpen();
    return new JdbcDatabaseMetaData(this);
  }

  public SQLWarning getWarnings() throws SQLException
  {
    checkOpen();

    return messages.getWarnings();
  }

  public Statement createStatement() throws SQLException
  {
    checkOpen();

    // Changed type from TYPE_FORWARD_ONLY to TYPE_SCROLL_INSENSITIVE to support forwards and backwards scrolling.
    return createStatement(java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, java.sql.ResultSet.CONCUR_READ_ONLY);
  }

  synchronized public Statement createStatement(int type, int concurrency) throws SQLException
  {
    checkOpen();

    JdbcStatement stmt = new JdbcStatement(this, type, concurrency);
    addStatement(stmt);

    return stmt;
  }

  public Statement createStatement(int type, int concurrency, int holdability) throws SQLException
  {
    checkOpen();
    setHoldability(holdability);

    return createStatement(type, concurrency);
  }

  public Map getTypeMap() throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException();
  }

  public void setTypeMap(Map map) throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException("setTypeMap(Map)");
  }

  public String nativeSQL(String sql) throws SQLException
  {

    checkOpen();
    throw new SQLFeatureNotSupportedException("nativeSQL(String)");
  }

  public CallableStatement prepareCall(String sql) throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException("prepareCall(String)");
  }

  synchronized public CallableStatement prepareCall(String sql, int type,
                                                    int concurrency)
      throws SQLException
  {

    checkOpen();

    if (sql == null || sql.length() == 0) {
      throw new SQLException("error.generic.nosql", "HY000");
    }

    throw new SQLFeatureNotSupportedException("prepareCall(String, int, int)");
  }

  public CallableStatement prepareCall(
      String sql,
      int type,
      int concurrency,
      int holdability)
      throws SQLException
  {
    checkOpen();
    setHoldability(holdability);
    return prepareCall(sql, type, concurrency);
  }

  public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
      throws SQLException
  {
    checkOpen();

    // We don't support prepare statement
    throw new SQLFeatureNotSupportedException("prepareStatement(String, int)");
  }


  public PreparedStatement prepareStatement(String sql)
      throws SQLException
  {
    checkOpen();

    // For JMeter
    if (sql.equalsIgnoreCase("Select 1")) {
      String newSql = "select 1 from RAPIDS.SYSTEM.TABLES limit 1;";
      return prepareStatement(newSql,
                              java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                              java.sql.ResultSet.CONCUR_READ_ONLY);
    }

    throw new SQLFeatureNotSupportedException("prepareStatement(String sql)");
  }

  synchronized public PreparedStatement prepareStatement(String sql,
                                                         int type,
                                                         int concurrency)
      throws SQLException
  {
    checkOpen();
    // We don't support prepare statement yet. We do this for JMeter only
    if (sql.equalsIgnoreCase("Select 1") || sql.equalsIgnoreCase("select 1 from RAPIDS.SYSTEM.TABLES limit 1;")) {
      JdbcPreparedStatement stmt = new JdbcPreparedStatement(this,
                                                              sql,
                                                              type,
                                                              concurrency,
                                                              false);

      return stmt;
    }
    // We don't support prepare statement
    throw new SQLFeatureNotSupportedException("prepareStatement(String, int, int)");
  }

  public PreparedStatement prepareStatement(
      String sql,
      int type,
      int concurrency,
      int holdability)
      throws SQLException
  {
    // We don't support prepare statement
    setHoldability(holdability);

    return prepareStatement(sql, type, concurrency);
  }

  public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
      throws SQLException
  {
    // We don't support prepare statement
    return prepareStatement(sql, JdbcStatement.RETURN_GENERATED_KEYS);
  }

  public PreparedStatement prepareStatement(String sql, String[] columnNames)
      throws SQLException
  {
    // We don't support prepare statement
    return prepareStatement(sql, JdbcStatement.RETURN_GENERATED_KEYS);
  }

  // JDBC 3

  public synchronized void releaseSavepoint(Savepoint savepoint)
      throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("releaseSavepoint(Savepoint)", "25000");
  }

  public synchronized void rollback(Savepoint savepoint) throws SQLException
  {
    checkOpen();
    checkLocal("rollback");

    throw new SQLFeatureNotSupportedException("rollback(Savepoint)");
  }

  synchronized public Savepoint setSavepoint() throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException("setSavepoint()");
  }

  synchronized public Savepoint setSavepoint(String name) throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException("setSavepoint(String)");
  }


  /////// JDBC4 demarcation, do NOT put any JDBC3 code below this line ///////

  public Array createArrayOf(String typeName, Object[] elements) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("createArrayOf(String,Object[])");
  }

  public Blob createBlob() throws SQLException
  {
    throw new SQLFeatureNotSupportedException("createBlob()");
  }

  public Clob createClob() throws SQLException
  {
    throw new SQLFeatureNotSupportedException("createClob()");
  }

  public NClob createNClob() throws SQLException
  {
    throw new SQLFeatureNotSupportedException("createNClob()");
  }

  public SQLXML createSQLXML() throws SQLException
  {
    throw new SQLFeatureNotSupportedException("createSQLXML()");
  }

  public Struct createStruct(String typeName, Object[] attributes)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("createStruct(String,Object[])");
  }

  public Properties getClientInfo() throws SQLException
  {
    checkOpen();
    return new Properties();
  }

  public String getClientInfo(String name) throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException();
  }

  public boolean isValid(int timeout) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("isValid(int)");

    //checkOpen();
//    boolean ret = false;
//
//    if (closed) {
//      // If we don't return here, the create statement will fail and the exception will be thrown.
//      return ret;
//    }
//
//    Statement stmt = createStatement();
//    // TODO: Update SQL statement here.
//    boolean result = stmt.execute("select SCHEMA_NAME from tables limit 1;");
//
//    if (result) {
//      stmt.getResultSet().close();
//    }
//
//    ret = true;
//
//    stmt.close();
//    return ret;
  }

  public void setClientInfo(Properties properties)
      throws SQLClientInfoException
  {
    throw new SQLClientInfoException();
  }

  public void setClientInfo(String name, String value)
      throws SQLClientInfoException
  {
    throw new SQLClientInfoException("Not implemented.", new HashMap());
  }

  public boolean isWrapperFor(Class arg0) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("isWrapperFor(Class)");
  }

  public Object unwrap(Class arg0) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("unwrap(Class)");
  }

  //// JDBC4.1 demarcation, do NOT put any JDBC3/4.0 code below this line ////

  @Override
  public void abort(java.util.concurrent.Executor executor) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("abort()");
  }

  @Override
  public void setNetworkTimeout(java.util.concurrent.Executor executor, int milliseconds) throws SQLException
  {
    //checkOpen();
    throw new SQLFeatureNotSupportedException("setNetworkTimeout(Executor, int)");
  }

  @Override
  public int getNetworkTimeout() throws SQLException
  {
    checkOpen();
    throw new SQLFeatureNotSupportedException("getNetworkTimeout()");
  }

  /**
   * Get the minor version of RapidsSE. This is the number after the first period.
   * e.g. "2" in version 1.2.3.
   * @return the minor version of RapidsSE
   */
  public int getDatabaseMinorVersion()
  {
    if (minorVersion != -1) {
      return minorVersion;
    }

    final String versionString = getDatabaseProductVersion();

    Pattern pattern = Pattern.compile("\\s*(\\d+).(\\d+).*");
    Matcher matcher = pattern.matcher(versionString);

    if (!matcher.matches()) {
      final String msg = "Unable to parse database version string.";
      throw new JdbcDriverRuntimeException(msg);
    }

    if (matcher.groupCount() != 2) {
      final String msg = "Not able to parse all the version components of the database version string.";
      throw new JdbcDriverRuntimeException(msg);
    }

    String majorVersionString = matcher.group(2);

    if (majorVersionString == null ) {
      final String msg = "Cannot have a null database minor version string.";
      throw new JdbcDriverRuntimeException(msg);
    }

    try {
      minorVersion = Integer.valueOf(majorVersionString);

    } catch (NumberFormatException e) {
      final String msg = "Unable to parse the database minor version number.";
      throw new JdbcDriverRuntimeException(msg);
    }

    return minorVersion;
  }

  /**
   * Get the major version of RapidsSE. This is the number before the first period.
   * e.g. "1" in version 1.2.3.
   * @return the minor version of RapidsSE
   */
  public int getDatabaseMajorVersion()
  {
    if (majorVersion != -1) {
      return majorVersion;
    }


    final String versionString = getDatabaseProductVersion();

    Pattern pattern = Pattern.compile("\\s*(\\d+).(\\d+).*");
    Matcher matcher = pattern.matcher(versionString);

    if (!matcher.matches()) {
      final String msg = "Unable to parse database version string.";
      throw new JdbcDriverRuntimeException(msg);
    }

    if (matcher.groupCount() != 2) {
      final String msg = "Not able to parse all the version components of the database version string.";
      throw new JdbcDriverRuntimeException(msg);
    }

    String majorVersionString = matcher.group(1);

    if (majorVersionString == null ) {
      final String msg = "Cannot have a null database major version string.";
      throw new JdbcDriverRuntimeException(msg);
    }

    try {
      majorVersion = Integer.valueOf(majorVersionString);

    } catch (NumberFormatException e) {
      final String msg = "Unable to parse the database major version number.";
      throw new JdbcDriverRuntimeException(msg);
    }

    return majorVersion;
  }

  /**
   * Get the version of RapidsSE as a string.
   * @return the version of RapidsSE as a string.
   */
  public String getDatabaseProductVersion()
  {
    if (versionString != null) {
      return versionString;
    }

    final String command = "version;";

    try  {

      SEResult result = this.executeCommand(command);
      if (result.getStatus() != SEResult.Status.HAS_RESULT_SET) {
        final String msg = "Version command didn't return a ResultSet.";
        throw new SQLException(msg);
      }

      List<String[]> rows = result.getRows();

      if (rows == null || rows.size() != 1) {
        final String msg = "Invalid number of rows returned for version command.";
        throw new SQLException(msg);
      }

      String[] row = rows.get(0);

      if (row.length == 0) {
        final String msg = "Version command returned zero columns.";
        throw new SQLException(msg);
      }

      versionString = row[0];
      return versionString;

    } catch (SQLException e) {
      throw new JdbcDriverRuntimeException(e);
    }
  }
}