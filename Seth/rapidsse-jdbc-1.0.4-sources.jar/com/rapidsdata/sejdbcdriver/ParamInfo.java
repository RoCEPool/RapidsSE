// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

import com.rapidsdata.sejdbcdriver.sesupport.TypeConversion;
import com.rapidsdata.seshellapi.DataType;

import java.sql.SQLException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * This class is a descriptor for procedure and prepared statement parameters.
 */
public class ParamInfo implements Cloneable
{
  /**
   * Flag as an input parameter.
   */
  final static int INPUT = 0;
  /**
   * Flag as an output parameter.
   */
  final static int OUTPUT = 1;
  /**
   * Flag as an return value parameter.
   */
  final static int RETVAL = 2;
  /**
   * Flag as a unicode parameter.
   */
  final static int UNICODE = 4;

  /**
   * Internal RapidsSE data type
   */
  public DataType seType;
  /**
   * JDBC type constant from java.sql.Types
   */
  public int jdbcType;
  /**
   * Formal parameter name eg @P1
   */
  public String name;
  /**
   * SQL type name eg varchar(10)
   */
  public String sqlType;
  /**
   * Parameter offset in target SQL statement
   */
  public int markerPos = -1;
  /**
   * Current parameter value
   */
  public Object value;
  /**
   * Parameter decimal precision
   */
  public int precision = -1;
  /**
   * Parameter decimal scale
   */
  public int scale = -1;
  /**
   * Length of InputStream
   */
  public int length = -1;
  /**
   * Parameter is an output parameter
   */
  public boolean isOutput;
  /**
   * Parameter is used as  SP return value
   */
  public boolean isRetVal;
  /**
   * IN parameter has been set
   */
  public boolean isSet;
  /**
   * Parameter should be sent as unicode
   */
  public boolean isUnicode;
  /**
   * RDP 8 Collation string.
   */
  public byte collation[];
  /**
   * Character set descriptor (if different from default)
   */
  public CharsetInfo charsetInfo;
  /**
   * OUT parameter value is set.
   */
  public boolean isSetOut;
  /**
   * OUT Parameter value.
   */
  public Object outValue;

  /**
   * Construct a parameter with parameter marker offset.
   *
   * @param pos       the offset of the ? symbol in the target SQL string
   * @param isUnicode true    if the parameter is Unicode encoded
   */
  ParamInfo(int pos, boolean isUnicode)
  {
    markerPos = pos;
    this.isUnicode = isUnicode;
  }

  /**
   * Construct a parameter for statement caching.
   *
   * @param name      the formal name of the parameter
   * @param pos       the offset of the ? symbol in the parsed SQL string
   * @param isRetVal  true    if the parameter is a return value
   * @param isUnicode true    if the parameter is Unicode encoded
   */
  ParamInfo(String name, int pos, boolean isRetVal, boolean isUnicode)
  {
    this.name = name;
    this.markerPos = pos;
    this.isRetVal = isRetVal;
    this.isUnicode = isUnicode;
  }

  /**
   * Construct an initialised parameter with extra attributes.
   *
   * @param jdbcType the  java.sql.Type    constant describing this type
   * @param value    the initial parameter value
   * @param flags    the additional attributes eg OUTPUT, RETVAL, UNICODE etc.
   */
  ParamInfo(int jdbcType, Object value, int flags)
  {
    this.jdbcType = jdbcType;
    this.value = value;
    this.isSet = true;
    this.isOutput = ((flags & OUTPUT) > 0) || ((flags & RETVAL) > 0);
    this.isRetVal = ((flags & RETVAL) > 0);
    this.isUnicode = ((flags & UNICODE) > 0);
    if (value instanceof String) {
      this.length = ((String) value).length();
    } else if (value instanceof byte[]) {
      this.length = ((byte[]) value).length;
    }
  }

  /**
   * Construct a parameter based on a result set column.
   *
   * @param ci     the column descriptor
   * @param name   the name for this parameter or null
   * @param value  the column data value
   * @param length the column data length
   */
  ParamInfo(ColInfo ci, String name, Object value, int length)
  {
    this.name = name;
    this.seType = ci.seType;
    this.scale = ci.scale;
    this.precision = ci.precision;
    this.jdbcType = ci.jdbcType;
    this.sqlType = ci.sqlType;
    this.collation = ci.collation;
    this.charsetInfo = ci.charsetInfo;
    this.isUnicode = false;
    this.isSet = true;
    this.value = value;
    this.length = length;
  }

  /**
   * Get the output parameter value.
   *
   * @return the OUT value as an  Object
   * @throws SQLException if the parameter has not been set
   */
  Object getOutValue()
      throws SQLException
  {
    if (!isSetOut) {
      throw new SQLException(
          "error.callable.outparamnotset", "HY010");
    }
    return outValue;
  }

  /**
   * Set the OUT parameter value.
   *
   * @param value The data value.
   */
  void setOutValue(Object value)
  {
    outValue = value;
    isSetOut = true;
  }

  /**
   * Clear the OUT parameter value and status.
   */
  void clearOutValue()
  {
    outValue = null;
    isSetOut = false;
  }

  /**
   * Clear the IN parameter value and status.
   */
  void clearInValue()
  {
    value = null;
    isSet = false;
  }

  /**
   * Get the string value of the parameter.
   *
   * @return The data value as a  String    or null.
   */
  public String getString(String charset) throws IOException
  {
    if (value == null || value instanceof String) {
      return (String) value;
    }

    if (value instanceof InputStream) {
      try {
        value = loadFromReader(new InputStreamReader((InputStream) value, charset), length);
        length = ((String) value).length();

        return (String) value;
      } catch (UnsupportedEncodingException e) {
        throw new IOException("I/O Error: UnsupportedEncodingException: " + e.getMessage());
      }
    }

    if (value instanceof Reader) {
      value = loadFromReader((Reader) value, length);
      return (String) value;
    }

    return value.toString();
  }

  /**
   * Get the byte array value of the parameter.
   *
   * @return The data value as a  byte[]    or null.
   */
  public byte[] getBytes(String charset) throws IOException
  {
    if (value == null || value instanceof byte[]) {
      return (byte[]) value;
    }

    if (value instanceof InputStream) {
      value = loadFromStream((InputStream) value, length);

      return (byte[]) value;
    }

    if (value instanceof Reader) {
      String tmp = loadFromReader((Reader) value, length);
      value = TypeConversion.encodeString(charset, tmp);
      return (byte[]) value;
    }

    if (value instanceof String) {
      return TypeConversion.encodeString(charset, (String) value);
    }

    return new byte[0];
  }

  /**
   * Load a byte array from an InputStream
   *
   * @param in     The InputStream to read from.
   * @param length The length of the stream.
   * @return The data as a  byte[]   .
   * @throws IOException
   */
  private static byte[] loadFromStream(InputStream in, int length)
      throws IOException
  {
    byte[] buf = new byte[length];

    int pos = 0, res;
    while (pos != length && (res = in.read(buf, pos, length - pos)) != -1) {
      pos += res;
    }
    if (pos != length) {
      throw new java.io.IOException(
          "Data in stream less than specified by length");
    }

    if (in.read() >= 0) {
      throw new java.io.IOException(
          "More data in stream than specified by length");
    }

    return buf;
  }

  /**
   * Create a String from a Reader stream.
   *
   * @param in     The Reader object with the data.
   * @param length Number of characters to read.
   * @return The data as a  String   .
   * @throws IOException
   */
  private static String loadFromReader(Reader in, int length)
      throws IOException
  {
    char[] buf = new char[length];

    int pos = 0, res;
    while (pos != length && (res = in.read(buf, pos, length - pos)) != -1) {
      pos += res;
    }
    if (pos != length) {
      throw new java.io.IOException(
          "Data in stream less than specified by length");
    }

    if (in.read() >= 0) {
      throw new java.io.IOException(
          "More data in stream than specified by length");
    }

    return new String(buf);
  }

  /**
   * Creates a shallow copy of this  ParamInfo    instance. Used by
   * the  PreparedStatement    batching implementation to duplicate
   * parameters.
   */
  public Object clone()
  {
    try {
      return super.clone();
    } catch (CloneNotSupportedException ex) {
      // Will not happen
      return null;
    }
  }
}
