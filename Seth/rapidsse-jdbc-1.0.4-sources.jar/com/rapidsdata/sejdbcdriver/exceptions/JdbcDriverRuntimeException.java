// Copyright 2014 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

public class JdbcDriverRuntimeException extends RuntimeException
{
  public JdbcDriverRuntimeException(String message)
  {
    super(message);
  }

  public JdbcDriverRuntimeException(String message, Throwable throwable)
  {
    super(message, throwable);
  }

  public JdbcDriverRuntimeException(Throwable t)
  {
    super(t);
  }
}
