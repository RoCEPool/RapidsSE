// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

/**
 * An exception to indicate that we couldn't match up the message type value to a
 * message enumeration value.
 */
public class JdbcDriverInvalidMessageTypeException extends JdbcDriverProtocolHandlerException
{
  public JdbcDriverInvalidMessageTypeException(String message)                        { super(message); }
  public JdbcDriverInvalidMessageTypeException(String message, Throwable throwable)   { super(message, throwable); }
  public JdbcDriverInvalidMessageTypeException(Throwable throwable)                   { super(throwable); }
}
