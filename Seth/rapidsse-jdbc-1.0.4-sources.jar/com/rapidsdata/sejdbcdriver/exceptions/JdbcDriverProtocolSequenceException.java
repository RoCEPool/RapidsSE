// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

/**
 * Thrown when there is an invalid messaging sequence detected.
 * E.g., the client sends a valid message at the wrong point in a dialog.
 */
public class JdbcDriverProtocolSequenceException extends JdbcDriverProtocolHandlerException
{
  public JdbcDriverProtocolSequenceException(String message)                        { super(message); }
  public JdbcDriverProtocolSequenceException(String message, Throwable throwable)   { super(message, throwable); }
  public JdbcDriverProtocolSequenceException(Throwable throwable)                   { super(throwable); }
}
