// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

/**
 * A general purpose exception to capture the fact that there was an error reading or writing
 * a message to a client.
 */
public class JdbcDriverProtocolIOException extends JdbcDriverProtocolHandlerException
{
  public JdbcDriverProtocolIOException(String message)                        { super(message); }
  public JdbcDriverProtocolIOException(String message, Throwable throwable)   { super(message, throwable); }
  public JdbcDriverProtocolIOException(Throwable throwable)                   { super(throwable); }
}
