// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

/**
 * An exception sent if a message payload is too big to represent its size in the 3 bytes
 * allocated to the message size in the message header.
 */
public class JdbcDriverPayloadTooBigException extends JdbcDriverProtocolHandlerException
{
  private final int payloadSize;

  public JdbcDriverPayloadTooBigException(String message, int payloadSize)
  {
    super(message);
    this.payloadSize = payloadSize;
  }
  public JdbcDriverPayloadTooBigException(String message, int payloadSize, Throwable throwable)
  {
    super(message, throwable);
    this.payloadSize = payloadSize;
  }

  public int getPayloadSize()
  {
    return payloadSize;
  }
}
