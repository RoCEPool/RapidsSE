// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

/**
 * An error indicating that a message could not be encoded to send to a client.
 */
public class JdbcDriverProtocolEncodingException extends JdbcDriverProtocolHandlerException
{
  public JdbcDriverProtocolEncodingException(String message)                        { super(message); }
  public JdbcDriverProtocolEncodingException(String message, Throwable throwable)   { super(message, throwable); }
  public JdbcDriverProtocolEncodingException(Throwable throwable)                   { super(throwable); }
}
