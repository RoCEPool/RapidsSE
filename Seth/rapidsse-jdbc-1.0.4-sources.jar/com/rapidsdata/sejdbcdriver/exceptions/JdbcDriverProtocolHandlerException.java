// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;


/**
 * A generic base class for all types of exceptions emanating from a protocol handler.
 */
public abstract class JdbcDriverProtocolHandlerException extends JdbcDriverException
{
  public JdbcDriverProtocolHandlerException(String message)                        { super(message); }
  public JdbcDriverProtocolHandlerException(String message, Throwable throwable)   { super(message, throwable); }
  public JdbcDriverProtocolHandlerException(Throwable throwable)                   { super(throwable); }
}
