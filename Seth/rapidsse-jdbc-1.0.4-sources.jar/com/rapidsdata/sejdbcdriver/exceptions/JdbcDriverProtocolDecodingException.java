// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

/**
 * An error indicating that a message from the client could not be decoded.
 */
public class JdbcDriverProtocolDecodingException extends JdbcDriverProtocolHandlerException
{
  public JdbcDriverProtocolDecodingException(String message)                        { super(message); }
  public JdbcDriverProtocolDecodingException(String message, Throwable throwable)   { super(message, throwable); }
  public JdbcDriverProtocolDecodingException(Throwable throwable)                   { super(throwable); }
}
