// Copyright 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

public class JdbcDriverSocketClosedException extends JdbcDriverProtocolHandlerException
{
  public JdbcDriverSocketClosedException(String message)                        { super(message); }
  public JdbcDriverSocketClosedException(String message, Throwable throwable)   { super(message, throwable); }
  public JdbcDriverSocketClosedException(Throwable throwable)                   { super(throwable); }
}
