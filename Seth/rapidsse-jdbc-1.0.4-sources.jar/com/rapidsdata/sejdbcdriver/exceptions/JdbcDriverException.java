// Copyright 2014 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver.exceptions;

public class JdbcDriverException extends Exception
{
  public JdbcDriverException ()
  {}

  public JdbcDriverException (String message)
  {
    super(message);
  }

  public JdbcDriverException (String message, Throwable throwable)
  {
    super(message, throwable);
  }

  public JdbcDriverException (Throwable throwable)
  {
    super(throwable.getMessage(), throwable);
  }
}
