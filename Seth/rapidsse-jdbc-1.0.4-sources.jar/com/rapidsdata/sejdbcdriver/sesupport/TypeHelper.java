package com.rapidsdata.sejdbcdriver.sesupport;

import com.rapidsdata.sejdbcdriver.JdbcStatement;
import com.rapidsdata.sejdbcdriver.RdpBlobImpl;
import com.rapidsdata.sejdbcdriver.RdpClobImpl;
import com.rapidsdata.sejdbcdriver.RdpInterval;
import com.rapidsdata.sejdbcdriver.exceptions.JdbcDriverRuntimeException;
import com.rapidsdata.seshellapi.DataType;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Types;
import java.util.HashMap;

/** A class for converting between SE data types and JDBC data types. */
public class TypeHelper {

  /** Used to convert java classes to java.sql.Type constant. */
  private static final HashMap<Class,Integer> classToJdbcTypeMap = new HashMap<Class, Integer>();

  static {
    classToJdbcTypeMap.put(Byte.class,               new Integer(java.sql.Types.TINYINT));
    classToJdbcTypeMap.put(byte.class,               new Integer(java.sql.Types.TINYINT));
    classToJdbcTypeMap.put(Short.class,              new Integer(java.sql.Types.SMALLINT));
    classToJdbcTypeMap.put(short.class,              new Integer(java.sql.Types.SMALLINT));
    classToJdbcTypeMap.put(Integer.class,            new Integer(java.sql.Types.INTEGER));
    classToJdbcTypeMap.put(int.class,                new Integer(java.sql.Types.INTEGER));
    classToJdbcTypeMap.put(Long.class,               new Integer(java.sql.Types.BIGINT));
    classToJdbcTypeMap.put(long.class,               new Integer(java.sql.Types.BIGINT));
    classToJdbcTypeMap.put(Float.class,              new Integer(java.sql.Types.REAL));
    classToJdbcTypeMap.put(float.class,              new Integer(java.sql.Types.REAL));
    classToJdbcTypeMap.put(Double.class,             new Integer(java.sql.Types.DOUBLE));
    classToJdbcTypeMap.put(double.class,             new Integer(java.sql.Types.DOUBLE));
    classToJdbcTypeMap.put(BigDecimal.class,         new Integer(java.sql.Types.DECIMAL));
    classToJdbcTypeMap.put(Boolean.class,            new Integer(JdbcStatement.BOOLEAN));
    classToJdbcTypeMap.put(boolean.class,            new Integer(JdbcStatement.BOOLEAN));
    classToJdbcTypeMap.put(byte[].class,             new Integer(java.sql.Types.VARBINARY));
    classToJdbcTypeMap.put(java.sql.Date.class,      new Integer(java.sql.Types.DATE));
    classToJdbcTypeMap.put(java.sql.Time.class,      new Integer(java.sql.Types.TIME));
    classToJdbcTypeMap.put(java.sql.Timestamp.class, new Integer(java.sql.Types.TIMESTAMP));
    classToJdbcTypeMap.put(RdpBlobImpl.class,        new Integer(java.sql.Types.LONGVARBINARY));
    classToJdbcTypeMap.put(RdpClobImpl.class,        new Integer(java.sql.Types.LONGVARCHAR));
    classToJdbcTypeMap.put(String.class,             new Integer(java.sql.Types.VARCHAR));
    classToJdbcTypeMap.put(Blob.class,               new Integer(java.sql.Types.LONGVARBINARY));
    classToJdbcTypeMap.put(Clob.class,               new Integer(java.sql.Types.LONGVARCHAR));
    classToJdbcTypeMap.put(BigInteger.class,         new Integer(java.sql.Types.BIGINT));
    classToJdbcTypeMap.put(RdpInterval.class,        new Integer(Types.OTHER));
  }

  /**
   * Private constructor so it can't be instantiated.
   */
  private TypeHelper() { }

  /**
   * Converts a data type from RapidsSE to a JDBC data type integer.
   * @param seType The data type from RapidsSE to be converted to a JDBC type.
   * @return The JDBC type constant
   */
  public static int convertSeTypeToJdbcType(DataType seType)
  {
    switch (seType) {

      case NULL:
        return java.sql.Types.NULL;

      case BOOLEAN:
        return JdbcStatement.BOOLEAN;

      case INTEGER:
        return java.sql.Types.BIGINT;

      case FLOAT:
        return java.sql.Types.FLOAT;

      case DECIMAL:
        return java.sql.Types.DECIMAL;

      case VARCHAR:
        return java.sql.Types.VARCHAR;

      case DATE:
        return java.sql.Types.DATE;

      case TIME:
        return java.sql.Types.TIME;

      case TIMESTAMP:
        return java.sql.Types.TIMESTAMP;

      case INTERVAL:
        return java.sql.Types.JAVA_OBJECT;

      case BINARY:
        return java.sql.Types.VARBINARY;

      default:
        final String msg = "Unimplemented data type conversion to JDBC: " + seType.name();
        throw new JdbcDriverRuntimeException(msg);
    }
  }

  /**
   * Get a String describing the supplied JDBC type constant.
   * @param jdbcType The JDBC type integer to be translated to a name.
   * @return The text decode of the type constant as a  String.
   */
  public static String convertJdbcTypeToString(int jdbcType)
  {
    switch (jdbcType) {
      case java.sql.Types.ARRAY:
        return "ARRAY";

      case java.sql.Types.BIGINT:   // RDP refers to all integers as INTEGER. It doesn't have BIGINTs.
        return "INTEGER";

      case java.sql.Types.BINARY:
        return "BINARY";

      case java.sql.Types.BIT:
        return "BIT";

      case java.sql.Types.BLOB:
        return "BLOB";

      case JdbcStatement.BOOLEAN:
        return "BOOLEAN";

      case java.sql.Types.CHAR:
        return "CHAR";

      case java.sql.Types.CLOB:
        return "CLOB";

      case JdbcStatement.DATALINK:
        return "DATALINK";

      case java.sql.Types.DATE:
        return "DATE";

      case java.sql.Types.DECIMAL:
        return "DECIMAL";

      case java.sql.Types.DISTINCT:
        return "DISTINCT";

      case java.sql.Types.DOUBLE:
        return "DOUBLE";

      case java.sql.Types.FLOAT:
        return "FLOAT";

      case java.sql.Types.INTEGER:
        return "INTEGER";

      case java.sql.Types.JAVA_OBJECT:
        return "JAVA_OBJECT";

      case java.sql.Types.LONGVARBINARY:
        return "LONGVARBINARY";

      case java.sql.Types.LONGVARCHAR:
        return "LONGVARCHAR";

      case java.sql.Types.NULL:
        return "NULL";

      case java.sql.Types.NUMERIC:
        return "NUMERIC";

      case java.sql.Types.OTHER:
        return "OTHER";

      case java.sql.Types.REAL:
        return "REAL";

      case java.sql.Types.REF:
        return "REF";

      case java.sql.Types.SMALLINT:  // RDP refers to all integers as INTEGER. It doesn't have BIGINTs.
        return "INTEGER";

      case java.sql.Types.STRUCT:
        return "STRUCT";

      case java.sql.Types.TIME:
        return "TIME";

      case java.sql.Types.TIMESTAMP:
        return "TIMESTAMP";

      case java.sql.Types.TINYINT:  // RDP refers to all integers as INTEGER. It doesn't have BIGINTs.
        return "INTEGER";

      case java.sql.Types.VARBINARY:
        return "VARBINARY";

      case java.sql.Types.VARCHAR:
        return "VARCHAR";

      case java.sql.Types.SQLXML:
        return "XML";

      default:
        return "ERROR";
    }
  }

  /**
   * Get a String describing the supplied JDBC type constant.
   *
   * @param seTypeString The constant to be decoded.
   * @return The the type constant
   */
  public static int convertSeTypeStringToJdbcType(String seTypeString)
  {
    // Convert the string describing the SE data type into an
    // SE data type enum.
    DataType seType = DataType.valueOf(seTypeString.toUpperCase());

    // Then convert that SE data type to a JDBC data type.
    int jdbcType = convertSeTypeToJdbcType(seType);

    return jdbcType;
  }

  /**
   * Retrieve the fully qualified java class name for the
   * supplied JDBC Types constant.
   *
   * @param jdbcType The JDBC Types constant.
   * @return The fully qualified java class name as a  String   .
   */
  public static String getClassName(int jdbcType) {
    switch (jdbcType) {

      case JdbcStatement.BOOLEAN:
      case java.sql.Types.BIT:
        return "java.lang.Boolean";

      case java.sql.Types.TINYINT:
      case java.sql.Types.SMALLINT:
      case java.sql.Types.INTEGER:
        return "java.lang.Integer";

      case java.sql.Types.BIGINT:
        return "java.lang.Long";

      case java.sql.Types.NUMERIC:
      case java.sql.Types.DECIMAL:
        return "java.math.BigDecimal";

      case java.sql.Types.REAL:
        return "java.lang.Float";

      case java.sql.Types.FLOAT:
      case java.sql.Types.DOUBLE:
        return "java.lang.Double";

      case java.sql.Types.CHAR:
      case java.sql.Types.VARCHAR:
        return "java.lang.String";

      case java.sql.Types.BINARY:
      case java.sql.Types.VARBINARY:
        return "[B";

      case java.sql.Types.LONGVARBINARY:
      case java.sql.Types.BLOB:
        return "java.sql.Blob";

      case java.sql.Types.LONGVARCHAR:
      case java.sql.Types.CLOB:
        return "java.sql.Clob";

      case java.sql.Types.DATE:
        return "java.sql.Date";

      case java.sql.Types.TIME:
        return "java.sql.Time";

      case java.sql.Types.TIMESTAMP:
        return "java.sql.Timestamp";

      default:
        return "java.lang.Object";
    }
  }

  /**
   * Get the JDBC type constant which matches the supplied Class parameter.
   * @param typeClass the  Class to convert to a JDBC type.
   * @return the JDBC type constant as an int.
   */
  public static int getJdbcTypeFromClass(Class typeClass)
  {
    if (typeClass == null) {
      return java.sql.Types.JAVA_OBJECT;
    }

    Integer type = classToJdbcTypeMap.get(typeClass);

    if (type == null) {
      // not in typeMap - try recursion through superclass hierarchy
      return getJdbcTypeFromClass(typeClass.getSuperclass());
    }

    return type.intValue();
  }

  /**
   * Get the JDBC type constant which matches the supplied Object type.
   * @param value The object to analyse.
   * @return The JDBC type constant as an  int   .
   */
  public static int getJdbcTypeFromObject(Object value)
  {
    if (value == null) {
      return java.sql.Types.NULL;
    }

    return getJdbcTypeFromClass(value.getClass());
  }

}
