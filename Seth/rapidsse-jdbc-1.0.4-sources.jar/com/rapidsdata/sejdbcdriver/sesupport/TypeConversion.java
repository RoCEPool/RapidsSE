// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver.sesupport;

import com.rapidsdata.sejdbcdriver.*;
import com.rapidsdata.sejdbcdriver.exceptions.NumericOverflowException;
import com.rapidsdata.seshellapi.DataType;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Duration;
import java.time.Period;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class TypeConversion
{
  // Constants used in datatype conversions to avoid object allocations.
  private static final Integer INTEGER_ZERO = new Integer(0);
  private static final Integer INTEGER_ONE = new Integer(1);
  private static final Long LONG_ZERO = new Long(0L);
  private static final Long LONG_ONE = new Long(1L);
  private static final Float FLOAT_ZERO = new Float(0.0);
  private static final Float FLOAT_ONE = new Float(1.0);
  private static final Double DOUBLE_ZERO = new Double(0.0);
  private static final Double DOUBLE_ONE = new Double(1.0);
  private static final BigDecimal BIG_DECIMAL_ZERO = new BigDecimal(0.0);
  private static final BigDecimal BIG_DECIMAL_ONE = new BigDecimal(1.0);
  private static final java.sql.Date DATE_ZERO = new java.sql.Date(0);
  private static final java.sql.Time TIME_ZERO = new java.sql.Time(0);
  private static final BigInteger MIN_VALUE_LONG_BI = new BigInteger(String.valueOf(Long.MIN_VALUE));
  private static final BigInteger MAX_VALUE_LONG_BI = new BigInteger(String.valueOf(Long.MAX_VALUE));
  private static final BigDecimal MIN_VALUE_LONG_BD = new BigDecimal(String.valueOf(Long.MIN_VALUE));
  private static final BigDecimal MAX_VALUE_LONG_BD = new BigDecimal(String.valueOf(Long.MAX_VALUE));
  private static final BigInteger MAX_VALUE_28 = new BigInteger("9999999999999999999999999999");
  private static final BigInteger MAX_VALUE_38 = new BigInteger("99999999999999999999999999999999999999");



  /**
   * Hex constants to use in conversion routines.
   */
  private static final char hex[] = {'0', '1', '2', '3', '4', '5', '6', '7',
      '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
  };

  /**
   * Convert a byte[] object to a hex string.
   *
   * @param bytes The byte array to convert.
   * @return The hex equivalent as a  String   .
   */
  public static String toHex(byte[] bytes)
  {
    int len = bytes.length;

    if (len > 0) {
      StringBuilder buf = new StringBuilder(len * 2);

      for (int i = 0; i < len; i++) {
        int b1 = bytes[i] & 0xFF;

        buf.append(hex[b1 >> 4]);
        buf.append(hex[b1 & 0x0F]);
      }

      return buf.toString();
    }

    return "";
  }

  /**
   * Normalize a BigDecimal value so that it fits within the
   * available precision.
   *
   * @param value        The decimal value to normalize.
   * @param maxPrecision The decimal precision supported by the server
   *                     (assumed to be a value of either 28 or 38).
   * @return The possibly normalized decimal value as a  BigDecimal   .
   * @throws SQLException If the number is too big.
   */
  public static BigDecimal normalizeBigDecimal(BigDecimal value, int maxPrecision)
      throws SQLException
  {

    if (value == null) {
      return null;
    }

    if (value.scale() < 0) {
      // Java 1.5 BigDecimal allows negative scales.
      // RDP cannot send these so re-scale.
      value = value.setScale(0);
    }

    if (value.scale() > maxPrecision) {
      // This is an optimization to quickly adjust the scale of a
      // very precise BD value. For example
      // BigDecimal((double)1.0/3.0) yields a BD 54 digits long!
      value = value.setScale(maxPrecision, BigDecimal.ROUND_HALF_UP);
    }

    BigInteger max = MAX_VALUE_38;

    while (value.abs().unscaledValue().compareTo(max) > 0) {
      // OK we need to reduce the scale if possible to preserve
      // the integer part of the number and still fit within the
      // available precision.
      int scale = value.scale() - 1;

      if (scale < 0) {
        // Can't do it number just too big
        throw new SQLException("error.normalize.numtoobig",
            "22000");
      }

      value = value.setScale(scale, BigDecimal.ROUND_HALF_UP);
    }

    return value;
  }

  public static Object castNumeric(Object orig, int sourceType, int targetType)
  {


    return null;
  }


  /**
   * Convert an existing data object to the specified JDBC type.
   *
   * @param callerReference an object reference to the caller of this method;
   *                        must be a  Connection   ,
   *                        Statement    or  ResultSet
   * @param x               the data object to convert
   * @param jdbcType        the required type constant from
   *                        java.sql.Types that the data is to be converted to.
   * @return the converted data object
   * @throws SQLException if the conversion is not supported or fails
   */
  public static Object convert(Object callerReference, Object x, int jdbcType, String charSet)
      throws SQLException
  {
    // handle null value
    if (x == null) {
      switch (jdbcType) {
        case java.sql.Types.BIT:
        case JdbcStatement.BOOLEAN:
          return Boolean.FALSE;

        case java.sql.Types.TINYINT:
        case java.sql.Types.SMALLINT:
        case java.sql.Types.INTEGER:
          return INTEGER_ZERO;

        case java.sql.Types.BIGINT:
          return LONG_ZERO;

        case java.sql.Types.REAL:
          return FLOAT_ZERO;

        case java.sql.Types.FLOAT:
        case java.sql.Types.DOUBLE:
          return DOUBLE_ZERO;

        default:
          return null;
      }
    }

    try {
      switch (jdbcType) {
        case java.sql.Types.TINYINT:
          if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? INTEGER_ONE : INTEGER_ZERO;
          } else if (x instanceof Byte) {
            return new Integer(((Byte) x).byteValue() & 0xFF);
          } else {
            long val;
            if (x instanceof Number) {
              val = ((Number) x).longValue();
            } else if (x instanceof String) {
              try {
                val = new BigDecimal(((String) x).trim()).longValue();
              } catch (NumberFormatException e) {
                throw new SQLException("Unable to convert value: " + e.getMessage(), "22000");
              }
            } else {
              break;
            }
            if (val < Byte.MIN_VALUE || val > Byte.MAX_VALUE) {
              throw new NumericOverflowException();
            } else {
              return new Integer(new Long(val).intValue());
            }
          }

        case java.sql.Types.SMALLINT:
          if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? INTEGER_ONE : INTEGER_ZERO;
          } else if (x instanceof Short) {
            return new Integer(((Short) x).shortValue());
          } else if (x instanceof Byte) {
            return new Integer(((Byte) x).byteValue() & 0xFF);
          } else {
            long val;
            if (x instanceof Number) {
              val = ((Number) x).longValue();
            } else if (x instanceof String) {
              try {
                val = new BigDecimal(((String) x).trim()).longValue();
              } catch (NumberFormatException e) {
                throw new SQLException("Unable to convert value: " + e.getMessage(), "22000");
              }
            } else {
              break;
            }
            if (val < Short.MIN_VALUE || val > Short.MAX_VALUE) {
              throw new NumericOverflowException();
            } else {
              return new Integer(new Long(val).intValue());
            }
          }

        case java.sql.Types.INTEGER:
          if (x instanceof Integer) {
            return x;
          } else if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? INTEGER_ONE : INTEGER_ZERO;
          } else if (x instanceof Short) {
            return new Integer(((Short) x).shortValue());
          } else if (x instanceof Byte) {
            return new Integer(((Byte) x).byteValue() & 0xFF);
          } else {
            long val;
            if (x instanceof Number) {
              val = ((Number) x).longValue();
            } else if (x instanceof String) {
              try {
                val = new BigDecimal(((String) x).trim()).longValue();
              } catch (NumberFormatException e) {
                throw new SQLException("Unable to convert value: " + e.getMessage(), "22000");
              }
            } else {
              break;
            }
            if (val < Integer.MIN_VALUE || val > Integer.MAX_VALUE) {
              throw new NumericOverflowException();
            } else {
              return new Integer(new Long(val).intValue());
            }
          }

        case java.sql.Types.BIGINT:
          if (x instanceof BigDecimal) {
            BigDecimal val = (BigDecimal) x;
            if (val.compareTo(MIN_VALUE_LONG_BD) < 0 || val.compareTo(MAX_VALUE_LONG_BD) > 0) {
              throw new NumericOverflowException();
            } else {
              return new Long(val.longValue());
            }
          } else if (x instanceof Long) {
            return x;
          } else if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? LONG_ONE : LONG_ZERO;
          } else if (x instanceof Byte) {
            return new Long(((Byte) x).byteValue() & 0xFF);
          } else if (x instanceof BigInteger) {
            BigInteger val = (BigInteger) x;
            if (val.compareTo(MIN_VALUE_LONG_BI) < 0 || val.compareTo(MAX_VALUE_LONG_BI) > 0) {
              throw new NumericOverflowException();
            } else {
              return new Long(val.longValue());
            }
          } else if (x instanceof Number) {
            return new Long(((Number) x).longValue());
          } else if (x instanceof String) {
            BigDecimal bd;
            try {
              bd = new BigDecimal(((String) x).trim());
            } catch (NumberFormatException e) {
              throw new SQLException("Unable to convert value: " + e.getMessage(), "22000");
            }
            return bd.longValue();
          } else {
            break;
          }

        case java.sql.Types.REAL:
          if (x instanceof Float) {
            return x;
          } else if (x instanceof Double) {
            double val = (double) x;
            if (val < -Float.MAX_VALUE || val > Float.MAX_VALUE || Double.isNaN(val)) {  // ref: http://stackoverflow.com/questions/9746850/min-value-of-float-in-java-is-positive-why
              throw new NumericOverflowException();
            }
            return new Float((Double)x);
          } else if (x instanceof Byte) {
            return new Float(((Byte) x).byteValue() & 0xFF);
          } else if (x instanceof Number) {
            float val = ((Number) x).floatValue();
            if (val < -Float.MAX_VALUE || val > Float.MAX_VALUE || Float.isNaN(val)) {  // ref: http://stackoverflow.com/questions/9746850/min-value-of-float-in-java-is-positive-why
              throw new NumericOverflowException();
            }
            return val;
          } else if (x instanceof String) {
            double val;
            try {
              val = Double.valueOf(((String) x).trim());
            } catch (NumberFormatException e) {
              throw new SQLException("Unable to convert value: " + e.getMessage(), "22000");
            }
            if (val < -Float.MAX_VALUE || val > Float.MAX_VALUE || Double.isNaN(val)) {  // ref: http://stackoverflow.com/questions/9746850/min-value-of-float-in-java-is-positive-why
              throw new NumericOverflowException();
            }
            return new Float(val);
          } else if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? FLOAT_ONE : FLOAT_ZERO;
          }

          break;

        case java.sql.Types.FLOAT:
        case java.sql.Types.DOUBLE:
          if (x instanceof Double) {
            return x;
          } else if (x instanceof Byte) {
            return new Double(((Byte) x).byteValue() & 0xFF);
          } else if (x instanceof Number) {
            return new Double(((Number) x).doubleValue());
          } else if (x instanceof String) {
            double val;
            try {
              val = Double.valueOf(((String) x).trim());
            } catch (NumberFormatException e) {
              throw new SQLException("Unable to convert value: " + e.getMessage(), "22000");
            }
            if (val < -Double.MAX_VALUE || val > Double.MAX_VALUE || Double.isNaN(val)) {  // ref: http://stackoverflow.com/questions/9746850/min-value-of-float-in-java-is-positive-why
              throw new NumericOverflowException();
            }
            return val;
          } else if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? DOUBLE_ONE : DOUBLE_ZERO;
          }

          break;

        case java.sql.Types.NUMERIC:
        case java.sql.Types.DECIMAL:
          if (x instanceof BigDecimal) {
            return x;
          } else if (x instanceof Number) {
            return new BigDecimal(x.toString());
          } else if (x instanceof String) {
            BigDecimal bd;
            try {
              bd = new BigDecimal((String) x);
            } catch (NumberFormatException e) {
              throw new SQLException("Unable to convert value: " + e.getMessage(), "22000");
            }
            return bd;
          } else if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? BIG_DECIMAL_ONE : BIG_DECIMAL_ZERO;
          }

          break;

        case java.sql.Types.VARCHAR:
        case java.sql.Types.CHAR:
          if (x instanceof String) {
            return x;
          } else if (x instanceof Number) {
            return x.toString();
          } else if (x instanceof Boolean) {
            return ((Boolean) x).booleanValue() ? "TRUE" : "FALSE";
          } else if (x instanceof Clob) {
            Clob clob = (Clob) x;
            long length = clob.length();

            if (length > Integer.MAX_VALUE) {
              throw new SQLException("error.normalize.lobtoobig",
                  "22000");
            }

            return clob.getSubString(1, (int) length);
          } else if (x instanceof Blob) {
            Blob blob = (Blob) x;
            long length = blob.length();

            if (length > Integer.MAX_VALUE) {
              throw new SQLException("error.normalize.lobtoobig",
                  "22000");
            }

            x = blob.getBytes(1, (int) length);
          } else if (x instanceof Period || x instanceof Duration) {
            return formatInterval(x);
          }

          if (x instanceof byte[]) {
            return toHex((byte[]) x);
          }

          return x.toString(); // Last hope!

        case java.sql.Types.BIT:
        case JdbcStatement.BOOLEAN:
          if (x instanceof Boolean) {
            return x;
          } else if (x instanceof Number) {
            return (((Number) x).intValue() == 0) ? Boolean.FALSE : Boolean.TRUE;
          } else if (x instanceof String) {
            String tmp = ((String) x).trim();

            if ("1".equals(tmp) || "true".equalsIgnoreCase(tmp)) {
              return Boolean.TRUE;
            } else if ("0".equals(tmp) || "false".equalsIgnoreCase(tmp)) {
              return Boolean.FALSE;
            }

            throw new SQLException("error.convert.badstring", "22000");
          }

          break;

        case java.sql.Types.VARBINARY:
        case java.sql.Types.BINARY:
          if (x instanceof byte[]) {
            return x;
          } else if (x instanceof Blob) {
            Blob blob = (Blob) x;

            return blob.getBytes(1, (int) blob.length());
          } else if (x instanceof Clob) {
            Clob clob = (Clob) x;
            long length = clob.length();

            if (length > Integer.MAX_VALUE) {
              throw new SQLException("error.normalize.lobtoobig",
                  "22000");
            }

            x = clob.getSubString(1, (int) length);
          }

          if (x instanceof String) {
            //
            // Strictly speaking this conversion is not required by
            // the JDBC standard but RDP has always supported it.
            //
            if (charSet == null) {
              charSet = "ISO-8859-1";
            }

            try {
              return ((String) x).getBytes(charSet);
            } catch (UnsupportedEncodingException e) {
              return ((String) x).getBytes();
            }
          }

          break;

        case java.sql.Types.TIMESTAMP:
          if (x instanceof utilDateTime) {
            return ((utilDateTime) x).toTimestamp();
          } else if (x instanceof java.sql.Timestamp) {
            return x;
          } else if (x instanceof java.sql.Date) {
            return new java.sql.Timestamp(((java.sql.Date) x).getTime());
          } else if (x instanceof java.sql.Time) {
            return new java.sql.Timestamp(((java.sql.Time) x).getTime());
          } else if (x instanceof java.lang.String) {
            String val = ((String) x).trim();
            int len = val.length();

            try {
              // TIMESTAMP (format: yyyy-[m]m-[d]d [h]h:[m]m:[s]s[.f...])
              if (len > 10 && val.charAt(4) == '-') {
                return Timestamp.valueOf(val);
              }
              // maybe a DATE (format: yyyy-[m]m-[d]d)
              else if (len > 7 && val.charAt(4) == '-') {
                return new Timestamp(Date.valueOf(val).getTime());
              }
              // maybe a TIME (format: [h]h:[m]m:[s]s)
              else if (len > 7 && val.charAt(2) == ':') {
                // get rid of fractions of seconds
                return new Timestamp(Time.valueOf(val.split("\\.")[0].trim()).getTime());
              }
            } catch (IllegalArgumentException ie) {
              // format exception thrown below
            }

            throw new SQLException("error.convert.badnumber", "22000");
          }
          break;

        case java.sql.Types.DATE:
          if (x instanceof utilDateTime) {
            return ((utilDateTime) x).toDate();
          } else if (x instanceof java.sql.Date) {
            return x;
          } else if (x instanceof java.sql.Time) {
            return DATE_ZERO;
          } else if (x instanceof java.sql.Timestamp) {
            GregorianCalendar cal = new GregorianCalendar();
            cal.setTime((java.util.Date) x);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            return new java.sql.Date(cal.getTime().getTime());
          } else if (x instanceof java.lang.String) {
            String val = ((String) x).trim();
            int len = val.length();

            try {
              // DATE (format: yyyy-[m]m-[d]d)
              if (len > 7 && len < 11 && val.charAt(4) == '-') {
                return Date.valueOf(val);
              }
              // maybe a TIMESTAMP (format: yyyy-[m]m-[d]d [h]h:[m]m:[s]s[.f...])
              else if (len > 10 && val.charAt(4) == '-') {
                // get rid of the time part
                return Date.valueOf(val.split(" ")[0].trim());
              }
              // maybe a TIME (format: [h]h:[m]m:[s]s)
              // optional conversion not required by the JDBC specs
              else if (len > 7 && val.charAt(2) == ':') {
                // get rid of fractions of seconds
                Time.valueOf(val.split("\\.")[0].trim()); // ensure parsable date
                return DATE_ZERO;
              }
            } catch (IllegalArgumentException ie) {
              // format exception thrown below
            }

            throw new SQLException("error.convert.badnumber", "22000");
          }

          break;

        case java.sql.Types.TIME:
          if (x instanceof utilDateTime) {
            return ((utilDateTime) x).toTime();
          } else if (x instanceof java.sql.Time) {
            return x;
          } else if (x instanceof java.sql.Date) {
            return TIME_ZERO;
          } else if (x instanceof java.sql.Timestamp) {
            GregorianCalendar cal = new GregorianCalendar();
            cal.setTime((java.util.Date) x);
            cal.set(Calendar.YEAR, 1970);
            cal.set(Calendar.MONTH, 0);
            cal.set(Calendar.DAY_OF_MONTH, 1);
            cal.set(Calendar.MILLISECOND, 0);
            return new java.sql.Time(cal.getTime().getTime());
          } else if (x instanceof java.lang.String) {
            // get rid of fractions of seconds
            String val = ((String) x).trim().split("\\.")[0].trim();
            int len = val.length();

            try {
              // TIME (format: [h]h:[m]m:[s]s)
              if (len == 8 && val.charAt(2) == ':') {
                return Time.valueOf(val);
              }
              // maybe a TIMESTAMP (format: yyyy-[m]m-[d]d [h]h:[m]m:[s]s[.f...])
              else if (len > 10 && val.charAt(4) == '-') {
                // get rid of the date part
                String[] lines = val.split(" ");
                if (lines.length > 1) {
                  return Time.valueOf(lines[1].trim());
                }
              }
              // maybe a DATE (format: yyyy-[m]m-[d]d)
              // optional conversion not required by the JDBC specs
              else if (len > 7 && val.charAt(4) == '-') {
                Date.valueOf(val); // ensure parsable date
                return TIME_ZERO;
              }
            } catch (IllegalArgumentException ie) {
              // format exception thrown below
            }

            throw new SQLException("error.convert.badnumber", "22000");
          }

          break;

        case java.sql.Types.OTHER:
          return x;

        case java.sql.Types.JAVA_OBJECT:
          return x;

        case java.sql.Types.LONGVARBINARY:
        case java.sql.Types.BLOB:
          if (x instanceof Blob) {
            return x;
          } else if (x instanceof byte[]) {
            return new RdpBlobImpl(getConnection(callerReference), (byte[]) x);
          } else if (x instanceof Clob) {
            //
            // Convert CLOB to BLOB. Not required by the standard but we will
            // do it anyway.
            //
            Clob clob = (Clob) x;
            try {
              if (charSet == null) {
                charSet = "ISO-8859-1";
              }
              Reader rdr = clob.getCharacterStream();
              RdpBlobImpl blob = new RdpBlobImpl(getConnection(callerReference));
              BufferedWriter out =
                  new BufferedWriter(new OutputStreamWriter(blob.setBinaryStream(1), charSet));
              // TODO Use a buffer to improve performance
              int c;
              while ((c = rdr.read()) >= 0) {
                out.write(c);
              }
              out.close();
              rdr.close();
              return blob;
            } catch (UnsupportedEncodingException e) {
              // Unlikely to happen but fall back on in memory copy
              x = clob.getSubString(1, (int) clob.length());
            } catch (IOException e) {
              throw new SQLException("error.generic.ioerror",
                  "HY000");
            }
          }

          if (x instanceof String) {
            //
            // Strictly speaking this conversion is also not required by
            // the JDBC standard but RDP has always supported it.
            //
            RdpBlobImpl blob = new RdpBlobImpl(getConnection(callerReference));
            String data = (String) x;

            if (charSet == null) {
              charSet = "ISO-8859-1";
            }

            try {
              blob.setBytes(1, data.getBytes(charSet));
            } catch (UnsupportedEncodingException e) {
              blob.setBytes(1, data.getBytes());
            }

            return blob;
          }

          break;

        case java.sql.Types.LONGVARCHAR:
        case java.sql.Types.CLOB:
          if (x instanceof Clob) {
            return x;
          } else if (x instanceof Blob) {
            //
            // Convert BLOB to CLOB
            //
            Blob blob = (Blob) x;
            try {
              InputStream is = blob.getBinaryStream();
              RdpClobImpl clob = new RdpClobImpl(getConnection(callerReference));
              Writer out = clob.setCharacterStream(1);
              // TODO Use a buffer to improve performance
              int b;
              // These reads/writes are buffered by the underlying blob buffers
              while ((b = is.read()) >= 0) {
                out.write(hex[b >> 4]);
                out.write(hex[b & 0x0F]);
              }
              out.close();
              is.close();
              return clob;
            } catch (IOException e) {
              throw new SQLException("error.generic.ioerror",
                  "HY000");
            }
          } else if (x instanceof Boolean) {
            x = ((Boolean) x).booleanValue() ? "TRUE" : "FALSE";
          } else if (x instanceof Period || x instanceof Duration) {
            x = formatInterval(x);
          } else if (!(x instanceof byte[])) {
            x = x.toString();
          }

          if (x instanceof byte[]) {
            RdpClobImpl clob = new RdpClobImpl(getConnection(callerReference));
            clob.setString(1, toHex((byte[]) x));

            return clob;
          } else if (x instanceof String) {
            return new RdpClobImpl(getConnection(callerReference), (String) x);
          }

          break;

        default:
          throw new SQLException(
              "error.convert.badtypeconst",
              "HY004");
      }

      throw new SQLException(
          "error.convert.badtypes",
          "22005");
    } catch (NumberFormatException nfe) {
      throw new SQLException(
          "error.convert.badnumber", "22000");
    }
  }

  /**
   * Embed the data object as a string literal in the buffer supplied.
   *
   * @param buf        The buffer in which the data will be embedded.
   * @param value      The data object.
   * @param isUnicode  Set to  true    if Unicode strings should be used, else  false   .
   * @param connection The {@link JdbcConnection} object.
   */
  public static void embedData(StringBuilder buf, Object value, boolean isUnicode, JdbcConnection connection)
      throws SQLException
  {
    buf.append(' ');
    if (value == null) {
      buf.append("NULL ");
      return;
    }

    if (value instanceof Blob) {
      Blob blob = (Blob) value;

      value = blob.getBytes(1, (int) blob.length());
    } else if (value instanceof Clob) {
      Clob clob = (Clob) value;

      value = clob.getSubString(1, (int) clob.length());
    }

    if (value instanceof utilDateTime) {
      buf.append('\'');
      buf.append(value);
      buf.append('\'');
    } else if (value instanceof byte[]) {
      byte[] bytes = (byte[]) value;

      int len = bytes.length;

      if (len >= 0) {
        buf.append('0').append('x');
        if (len == 0) {
          // Zero length binary values are not allowed
          buf.append('0').append('0');
        } else {
          for (int i = 0; i < len; i++) {
            int b1 = bytes[i] & 0xFF;

            buf.append(hex[b1 >> 4]);
            buf.append(hex[b1 & 0x0F]);
          }
        }
      }
    } else if (value instanceof String) {
      String tmp = (String) value;
      int len = tmp.length();

      if (isUnicode) {
        buf.append('N');
      }
      buf.append('\'');

      for (int i = 0; i < len; i++) {
        char c = tmp.charAt(i);

        if (c == '\'') {
          buf.append('\'');
        }

        buf.append(c);
      }

      buf.append('\'');
    } else if (value instanceof java.sql.Date) {
      utilDateTime dt = new utilDateTime((java.sql.Date) value);
      buf.append('\'');
      buf.append(dt);
      buf.append('\'');
    } else if (value instanceof java.sql.Time) {
      utilDateTime dt = new utilDateTime((java.sql.Time) value);
      buf.append('\'');
      buf.append(dt);
      buf.append('\'');
    } else if (value instanceof java.sql.Timestamp) {
      utilDateTime dt = new utilDateTime((java.sql.Timestamp) value);
      buf.append('\'');
      buf.append(dt);
      buf.append('\'');
    } else if (value instanceof Boolean) {
      buf.append(((Boolean) value).booleanValue() ? '1' : '0');
    } else if (value instanceof BigDecimal) {
      //
      // Ensure large decimal number does not overflow the
      // maximum precision of the server.
      // Main problem is with small numbers e.g. BigDecimal(1.0).toString() =
      // 0.1000000000000000055511151231....
      //
      String tmp = value.toString();
      int maxlen = connection.getMaxPrecision();
      if (tmp.charAt(0) == '-') {
        maxlen++;
      }
      if (tmp.indexOf('.') >= 0) {
        maxlen++;
      }
      if (tmp.length() > maxlen) {
        buf.append(tmp.substring(0, maxlen));
      } else {
        buf.append(tmp);
      }
    } else {
      buf.append(value.toString());
    }
    buf.append(' ');
  }

  public static Object convertSeTypeToObject(String seStringVal,
                                             DataType seType,
                                             int jdbcType,
                                             Object callerReference) throws SQLException
  {
    if (seStringVal == null) {
      return null;
    }

    switch (seType) {
      case INTERVAL:
        // Need to handle this separately since there is no jdbc type for intervals.
        return parseSeInterval(seStringVal);

      case NULL:
      case BOOLEAN:
      case INTEGER:
      case FLOAT:
      case DECIMAL:
      case VARCHAR:
      case DATE:
      case TIME:
      case TIMESTAMP:
        return convert(callerReference, seStringVal, jdbcType, null);


      case BINARY: // don't know how to handle yet.
      default:
        throw new SQLException("error.typeconversion.unsupportedtype: " + seType.name());
    }

    //throw new SQLException("error.typeconversion.badvalue: " + seStringVal);
  }

  private static Object parseSeInterval(String strVal) throws SQLException
  {
    // According to SQL:
    // <interval literal> ::= INTERVAL [ <sign> ] <interval string> <interval qualifier>

    // We have previously stripped off the "INTERVAL" keyword.
    String str = strVal.trim();


    Pattern pattern = Pattern.compile(
        "\\s*"   +             // Leading whitespace
            "([-+]?)\\s*"   +         // Leading sign
            "'([^']+)'\\s+" +         // Quoted values
            "(\\w+)(?:\\(\\d+\\))?" + // Start qualifier and precision
            "(?:\\s+TO\\s+(\\w+)(?:\\(\\d+(?:,\\d+)?\\))?)?" +   // End qualifier & precision
            "\\s*",
        Pattern.CASE_INSENSITIVE);

    Matcher matcher = pattern.matcher(strVal);

    if (!matcher.matches()) {
      throw new SQLException("Unable to parse interval string - invalid interval format.");
    }

    if (matcher.groupCount() != 4) {
      throw new SQLException("Unable to parse interval string - invalid number of matching groups found.");
    }

    int sign = 1;
    String  quotedVal = null;
    IntervalQualifier startQualifier = null;
    IntervalQualifier endQualifier   = null;

    String group = matcher.group(1);
    if (group != null && !group.isEmpty() && group.equals("-")) {
      sign = -1;
    }

    quotedVal = matcher.group(2);

    int groupIndex = 3;
    try {
      startQualifier = IntervalQualifier.valueOf(matcher.group(groupIndex).toUpperCase());

      ++groupIndex;
      endQualifier = (matcher.group(4) == null ?
                        null :
                        IntervalQualifier.valueOf(matcher.group(groupIndex).toUpperCase()));

    } catch (IllegalArgumentException e) {
      throw new SQLException("Invalid interval qualifier: " + matcher.group(groupIndex));
    }

    switch (startQualifier) {
      case YEAR:
        if (endQualifier != null && endQualifier != IntervalQualifier.MONTH) {
          break; // error
        }
        return parseYearMonthInterval(quotedVal, sign, startQualifier, endQualifier);

      case MONTH:
        if (endQualifier != null) {
          break; // error
        }
        return parseYearMonthInterval(quotedVal, sign, startQualifier, endQualifier);

      case DAY:
        if (endQualifier != null &&
            endQualifier.ordinal() <= startQualifier.ordinal() ) {
          break; // error
        }
        return parseDayTimeInterval(quotedVal, sign, startQualifier, endQualifier);

      case HOUR:
      case MINUTE:
      case SECOND:
        if (endQualifier != null &&
            endQualifier.ordinal() <= startQualifier.ordinal() ) {
          break; // error
        }
        return parseTimeInterval(quotedVal, sign, startQualifier, endQualifier);

      default:
        throw new SQLException("Unsupported interval qualifier: " + startQualifier.name());
    }

    throw new SQLException("Invalid interval qualifiers.");
  }


  /**
   * Parses the quoted year-month interval string (without the quotes).
   * @param value the string to parse.
   * @param sign The value of any sign (+ve or -ve) specified before the value.
   * @param startQualifier The interval's first sub-type qualifier.
   * @param endQualifier The interval's last sub-type qualifier (if applicable).
   * @return a Period object represent a period of time.
   * @throws SQLException
   */
  private static Period parseYearMonthInterval(String value,
                                               int sign,
                                               IntervalQualifier startQualifier,
                                               IntervalQualifier endQualifier)
      throws SQLException
  {
    // <unquoted interval string> ::= [ <sign> ] { <year-month literal> | <day-time literal> }
    // <year-month literal> ::= <years value> [ <minus sign> <months value> ]
    //                        | <months value>
    Pattern ymPattern = Pattern.compile("([+-]?)" +       // Sign
                                        "(\\d+)" +        // year or month value
                                        "(?:-" +          // month non capture group & dash
                                          "(\\d+)" +      // month value
                                        ")?"              // end month non capture group
    );

    Matcher matcher = ymPattern.matcher(value);

    if (!matcher.matches() || matcher.groupCount() != 3) {
      throw new SQLException("Invalid year-month value: \"" + value + "\"");
    }

    String group = matcher.group(1);
    if (group != null && !group.isEmpty() && group.equals("-")) {
      sign *= -1L;
    }

    int val1 = 0;

    group = matcher.group(2);
    try {
      val1 = Integer.valueOf(group) * sign;
    } catch (NumberFormatException e) {
      throw new SQLException("Unable to parse year-month value to an integer: " + group);
    }

    boolean hasVal2 = false;
    int val2 = 0;

    group = matcher.group(3);
    if (group != null) {
      hasVal2 = true;

      try {
        val2 = Integer.valueOf(group) * sign;
      } catch (NumberFormatException e) {
        throw new SQLException("Unable to parse month value to an integer: " + group);
      }

      // The qualifiers must also be set to year-to-month.
      if (startQualifier != IntervalQualifier.YEAR && endQualifier != IntervalQualifier.MONTH) {
        throw new SQLException("Invalid combination of year-month value and interval qualifier specification.");
      }
    }

    Period period = Period.ZERO;

    if (startQualifier == IntervalQualifier.YEAR) {
      period = period.withYears(val1);

      if (endQualifier == IntervalQualifier.MONTH) {
        period = period.withMonths(val2);
      }

    } else {
      // the start qualifier must be months
      period = period.withMonths(val1);
    }

    return period;
  }

  /**
   * Parses the quoted day-time interval string (without the quotes).
   * @param value the string to parse.
   * @param sign The value of any sign (+ve or -ve) specified before the value.
   * @param startQualifier The interval's first sub-type qualifier.
   * @param endQualifier The interval's last sub-type qualifier (if applicable).
   * @return a Duration object represent a period of time.
   * @throws SQLException
   */
  private static Duration parseDayTimeInterval(String value,
                                               int sign,
                                               IntervalQualifier startQualifier,
                                               IntervalQualifier endQualifier)
      throws SQLException
  {
    // <unquoted interval string> ::= [ <sign> ] { <year-month literal> | <day-time literal> }
    // <day-time literal> ::= <day-time interval> | <time interval>
    // <day-time interval> ::= <days value> [ <space> <hours value> [ <colon> <minutes value> [ <colon> <seconds value> ] ] ]
    // <seconds value> ::= <seconds integer value> [ <period> [ <seconds fraction> ] ]

    Pattern dtPattern = Pattern.compile("([+-]?)" +          // Sign
                                        "(\\d+)" +           // Days value
                                        "(?: " +             // Hour/min/sec non capture group + space
                                          "(\\d+)" +         // Hours
                                          "(?::" +           // Min/sec non capture group + colon
                                            "(\\d+)" +       // Minutes
                                            "(?::" +         // Seconds non capture group + colon
                                              "(\\d+)" +     // Seconds
                                              "(?:\\." +     // Fractional seconds non capture group + period
                                                "(\\d+)" +   // Fractional seconds
                                              ")?" +         // End fractional seconds non capture group
                                            ")?" +           // End seconds non capture group
                                          ")?" +             // End min/sec non capture group
                                        ")?"                 // End time non capture group
                                        );

    Matcher matcher = dtPattern.matcher(value);

    if (!matcher.matches() || matcher.groupCount() != 6) {
      throw new SQLException("Invalid day-time value: \"" + value + "\"");
    }

    String group = matcher.group(1);
    if (group != null && !group.isEmpty() && group.equals("-")) {
      sign *= -1L;
    }

    long days  = 0;
    long hours = 0;
    long mins  = 0;
    long secs  = 0;
    long nanos = 0;

    group = matcher.group(2);
    try {
      days = Long.valueOf(group) * sign;
    } catch (NumberFormatException e) {
      throw new SQLException("Unable to parse day value to an integer: " + group);
    }

    // Extract hours, if any.
    group = matcher.group(3);
    if (group != null) {

      try {
        hours = Long.valueOf(group) * sign;
      } catch (NumberFormatException e) {
        throw new SQLException("Unable to parse hours value to an integer: " + group);
      }

      // The qualifiers must also be set to day-to-hour.
      if (endQualifier == null || endQualifier.ordinal()  < IntervalQualifier.HOUR.ordinal()) {
        throw new SQLException("Invalid combination of day-time value '" + value +
                               "' and interval qualifier specification " +
                               endQualifier.name() + ".");
      }


      // Extract minutes, if any.
      group = matcher.group(4);
      if (group != null) {

        try {
          mins = Long.valueOf(group) * sign;
        } catch (NumberFormatException e) {
          throw new SQLException("Unable to parse minutes value to an integer: " + group);
        }

        // The qualifiers must also be set to at least a day-to-minute.
        if (endQualifier == null || endQualifier.ordinal()  < IntervalQualifier.MINUTE.ordinal()) {
          throw new SQLException("Invalid combination of day-time value '" + value +
                                 "' and interval qualifier specification " +
                                 endQualifier.name() + ".");
        }


        // Extract seconds, if any.
        group = matcher.group(5);
        if (group != null) {

          try {
            secs = Long.valueOf(group) * sign;
          } catch (NumberFormatException e) {
            throw new SQLException("Unable to parse seconds value to an integer: " + group);
          }

          // The qualifiers must also be set to at least a day-to-second.
          if (endQualifier == null || endQualifier.ordinal()  < IntervalQualifier.SECOND.ordinal()) {
            throw new SQLException("Invalid combination of day-time value '" + value +
                                   "' and interval qualifier specification " +
                                   endQualifier.name() + ".");
          }


          // Extract nanoseconds, if any.
          group = matcher.group(6);
          if (group != null) {

            if (group.length() > 9) {
              // truncate to 9 digits of nanoseconds.
              group = group.substring(0, 9);
            }

            long factor = (long) Math.pow(10, 9 - group.length());  // convert fractional seconds to nanoseconds.

            try {
              nanos = Long.valueOf(group) * factor * sign;
            } catch (NumberFormatException e) {
              throw new SQLException("Unable to parse nanoseconds value to an integer: " + group);
            }

            // The qualifiers must also be set to at least a day-to-second.
            if (endQualifier == null || endQualifier.ordinal()  < IntervalQualifier.SECOND.ordinal()) {
              throw new SQLException("Invalid combination of day-time value '" + value +
                                     "' and interval qualifier specification " +
                                     endQualifier.name() + ".");
            }
          }
        }
      }
    }


    Duration duration = Duration.ofDays(days);
    duration = duration.plusHours(hours);
    duration = duration.plusMinutes(mins);
    duration = duration.plusSeconds(secs);
    duration = duration.plusNanos(nanos);

    return duration;
  }

  /**
   * Parses the quoted time interval string (without the quotes).
   * @param value the string to parse.
   * @param sign The value of any sign (+ve or -ve) specified before the value.
   * @param startQualifier The interval's first sub-type qualifier.
   * @param endQualifier The interval's last sub-type qualifier (if applicable).
   * @return a Duration object represent a period of time.
   * @throws SQLException
   */
  private static Duration parseTimeInterval(String value,
                                               int sign,
                                               IntervalQualifier startQualifier,
                                               IntervalQualifier endQualifier)
      throws SQLException
  {
    // <unquoted interval string> ::= [ <sign> ] { <year-month literal> | <day-time literal> }
    // <day-time literal> ::= <day-time interval> | <time interval>
    // <time interval> ::= <hours value> [ <colon> <minutes value> [ <colon> <seconds value> ] ]
    //                   | <minutes value> [ <colon> <seconds value> ]
    //                   | <seconds value>
    // <seconds value> ::= <seconds integer value> [ <period> [ <seconds fraction> ] ]

    Pattern hmsPattern = Pattern.compile("([+-]?)" +        // Sign
                                         "(\\d+)" +         // Hours
                                         "(?::" +           // Min/sec non capture group + colon
                                           "(\\d+)" +       // Minutes
                                           "(?::" +         // Seconds non capture group + colon
                                             "(\\d+)" +     // Seconds
                                             "(?:\\." +     // Fractional seconds non capture group + period
                                               "(\\d+)" +   // Fractional seconds
                                             ")?" +         // End fractional seconds non capture group
                                           ")?" +           // End seconds non capture group
                                         ")?"               // End min/sec non capture group
    );

    Pattern msPattern = Pattern.compile("([+-]?)" +         // Sign
                                        "(\\d+)" +          // Minutes
                                        "(?::" +            // Seconds non capture group + colon
                                          "(\\d+)" +        // Seconds
                                          "(?:\\." +        // Fractional seconds non capture group + period
                                            "(\\d+)" +      // Fractional seconds
                                          ")?" +            // End fractional seconds non capture group
                                        ")?"                // End seconds non capture group
    );

    Pattern sPattern = Pattern.compile( "([+-]?)" +         // Sign
                                          "(\\d+)" +        // Seconds
                                          "(?:\\." +        // Fractional seconds non capture group + period
                                            "(\\d+)" +      // Fractional seconds
                                          ")?"              // End fractional seconds non capture group
    );

    Pattern pattern;
    int expectedGroups;

    switch(startQualifier) {
      case HOUR:
        pattern = hmsPattern;
        expectedGroups = 5;
        break;

      case MINUTE:
        pattern = msPattern;
        expectedGroups = 4;
        break;

      case SECOND:
        pattern = sPattern;
        expectedGroups = 3;
        break;

      default:
        throw new SQLException("Invalid start qualifier for a time interval: " + startQualifier.name());
    }

    Matcher matcher = pattern.matcher(value);

    if (!matcher.matches() || matcher.groupCount() != expectedGroups) {
      throw new SQLException("Invalid day-time value: \"" + value + "\"");
    }

    String group = matcher.group(1);
    if (group != null && !group.isEmpty() && group.equals("-")) {
      sign *= -1L;
    }

    long hours = 0;
    long mins  = 0;
    long secs  = 0;
    long nanos = 0;

    int groupIndex = 2;

    switch (startQualifier) {
      case HOUR:
        group = matcher.group(groupIndex++);

        try {
          hours = Long.valueOf(group) * sign;
        } catch (NumberFormatException e) {
          throw new SQLException("Unable to parse hour value to an integer: " + group);
        }

        // Fall through to MINUTE

      case MINUTE:
        group = matcher.group(groupIndex++);

        if (group == null) {
          break;
        }

        if ((endQualifier == null && startQualifier != IntervalQualifier.MINUTE) ||
            (endQualifier != null && endQualifier.ordinal() < IntervalQualifier.MINUTE.ordinal()) ) {
          throw new SQLException("Invalid combination of time value '" + value +
                                 "' and interval qualifier specification " +
                                 (endQualifier == null ? "null" : endQualifier.name()) +
                                 ".");
        }

        try {
          mins = Long.valueOf(group) * sign;
        } catch (NumberFormatException e) {
          throw new SQLException("Unable to parse minute value to an integer: " + group);
        }

        // Fall through to SECOND

      case SECOND:
        group = matcher.group(groupIndex++);

        if (group == null) {
          break;
        }

        if ((endQualifier == null && startQualifier != IntervalQualifier.SECOND) ||
            (endQualifier != null && endQualifier.ordinal() < IntervalQualifier.SECOND.ordinal()) ) {
          throw new SQLException("Invalid combination of time value '" + value +
                                 "' and interval qualifier specification " +
                                 (endQualifier == null ? "null" : endQualifier.name()) +
                                 ".");
        }

        try {
          secs = Long.valueOf(group) * sign;
        } catch (NumberFormatException e) {
          throw new SQLException("Unable to parse seconds value to an integer: " + group);
        }

        // Parse nano seconds, if any
        group = matcher.group(groupIndex++);

        if (group == null) {
          break;
        }

        if (group.length() > 9) {
          // truncate to 9 digits of nanoseconds.
          group = group.substring(0, 9);
        }

        long factor = (long) Math.pow(10, 9 - group.length());  // convert fractional seconds to nanoseconds.

        try {
          nanos = Long.valueOf(group) * factor * sign;
        } catch (NumberFormatException e) {
          throw new SQLException("Unable to parse nanoseconds value to an integer: " + group);
        }

        break;

      default:
        throw new SQLException("Invalid start qualifier for a time interval: " + startQualifier.name());
    }

    Duration duration = Duration.ofHours(hours);
    duration = duration.plusMinutes(mins);
    duration = duration.plusSeconds(secs);
    duration = duration.plusNanos(nanos);

    return duration;
  }

  public static String formatInterval(Object val) throws SQLException
  {
    String intervalType;
    StringBuilder sb = new StringBuilder(1024);

    sb.append("INTERVAL ");

    if (val instanceof Period) {
      Period period = (Period) val;
      intervalType = formatPeriodInterval(sb, period);

    } else if (val instanceof Duration) {
      Duration duration = (Duration) val;
      intervalType = formatDurationInterval(sb, duration);

    } else {
      throw new SQLException("Unrecognised object type: " + val.getClass().getName());
    }
    sb.append("' ");
    sb.append(intervalType);
    return sb.toString();
  }

  /**
   * Formats a Period interval type to a string and writes it to the StringBuilder parameter.
   * @param sb where the interval type is to be rendered to.
   * @param period The Period interval value to render.
   * @return The exact type of SQL interval that was rendered (e.g. YEARS TO MONTHS, MONTHS, ...).
   */
  private static String formatPeriodInterval(StringBuilder sb, Period period)
  {
    if (period.getYears() < 0 || period.getMonths() < 0) {
      sb.append('-');
    }

    sb.append("'");

    String intervalType;

    if (period.getYears() != 0 && period.getMonths() != 0) {
      intervalType = "YEAR TO MONTH";
      sb.append(Math.abs(period.getYears()));
      sb.append('-');
      sb.append(Math.abs(period.getMonths()));

    } else if (period.getMonths() != 0) {
      intervalType = "MONTH";
      sb.append(Math.abs(period.getMonths()));

    } else {
      intervalType = "YEAR";
      sb.append(Math.abs(period.getYears()));
    }

    return intervalType;
  }

  /**
   * Formats a Duration interval type to a string and writes it to the StringBuilder parameter.
   * @param sb where the interval type is to be rendered to.
   * @param duration The Duration interval value to render.
   * @return The exact type of SQL interval that was rendered (e.g. DAYS TO MINUTES, SECONDS, ...).
   */
  private static String formatDurationInterval(StringBuilder sb, Duration duration)
  {
    String intervalType;

    long days = duration.toDays();
    duration = duration.minusDays(days);
    long hours = duration.toHours();
    duration = duration.minusHours(hours);
    long minutes = duration.toMinutes();
    duration = duration.minusMinutes(minutes);
    long seconds = ((duration.getSeconds() * 1000000000) + duration.getNano()) / 1000000000;
    long nanos   = ((duration.getSeconds() * 1000000000) + duration.getNano()) % 1000000000;

    if (days < 0 || hours < 0 || minutes < 0 || seconds < 0 || nanos < 0) {
      sb.append('-');
    }

    sb.append("'");

    if (days != 0) {
      intervalType = "DAY";
      sb.append(String.format("%02d", Math.abs(days)));

      if (hours != 0 || minutes != 0 || seconds != 0 || nanos != 0) {
        intervalType = "DAY TO HOUR";
        sb.append(" ");
        sb.append(String.format("%02d", Math.abs(hours)));

        if (minutes != 0 || seconds != 0 || nanos != 0) {
          intervalType = "DAY TO MINUTE";
          sb.append(":");
          sb.append(String.format("%02d", Math.abs(minutes)));

          if (seconds != 0 || nanos != 0) {
            intervalType = "DAY TO SECOND";
            sb.append(":");
            sb.append(String.format("%02d", Math.abs(seconds)));

            if (nanos != 0) {
              sb.append(".");
              sb.append(String.format("%09d", Math.abs(nanos)));
            }
          }
        }
      }

    } else if (hours != 0) {
      intervalType = "HOUR";
      sb.append(String.format("%02d", Math.abs(hours)));

      if (minutes != 0 || seconds != 0 || nanos != 0) {
        intervalType = "HOUR TO MINUTE";
        sb.append(":");
        sb.append(String.format("%02d", Math.abs(minutes)));

        if (seconds != 0 || nanos != 0) {
          intervalType = "HOUR TO SECOND";
          sb.append(":");
          sb.append(String.format("%02d", Math.abs(seconds)));

          if (nanos != 0) {
            sb.append(".");
            sb.append(String.format("%09d", Math.abs(nanos)));
          }
        }
      }

    } else if (minutes != 0) {
      intervalType = "MINUTE";
      sb.append(String.format("%02d", Math.abs(minutes)));

      if (seconds != 0 || nanos != 0) {
        intervalType = "MINUTE TO SECOND";
        sb.append(":");
        sb.append(String.format("%02d", Math.abs(seconds)));

        if (nanos != 0) {
          sb.append(".");
          sb.append(String.format("%09d", Math.abs(nanos)));
        }
      }

    } else {
      // seconds
      intervalType = "SECOND";
      sb.append(String.format("%02d", Math.abs(seconds)));

      if (nanos != 0) {
        sb.append(".");
        sb.append(String.format("%09d", Math.abs(nanos)));
      }
    }

    return intervalType;
  }


  /**
   * Generates a unique statement key for a given SQL statement.
   *
   * @param sql        the sql statement to generate the key for
   * @param params     the statement parameters
   * @param serverType the type of server to generate the key for
   * @param catalog    the catalog
   * @param autoCommit true if in auto commit mode
   * @param cursor     true if this is a prepared cursor
   * @return the unique statement key
   */
  /*
  public static String getStatementKey(String sql, ParamInfo[] params,
                                int serverType, String catalog,
                                boolean autoCommit, boolean cursor)
  {
    StringBuilder key;

    if (serverType == Driver.RDP10) {
      key = new StringBuilder(1 + catalog.length() + sql.length()
          + 11 * params.length);
      // Need to distinguish otherwise identical SQL for cursor and
      // non cursor prepared statements (sp_prepare/sp_cursorprepare).
      key.append((cursor) ? 'C' : 'X');
      // Need to ensure that the current database is included in the key
      // as procedures and handles are database specific.
      key.append(catalog);
      // Now the actual SQL statement
      key.append(sql);
      //
      // Append parameter data types to key.
      //
      for (int i = 0; i < params.length; i++) {
        key.append(params[i].sqlType);
      }
    } else {
      key = new StringBuilder(sql.length() + 2);
      // A simple key works for Sybase just need to know if
      // proc created in chained mode or not.
      key.append((autoCommit) ? 'T' : 'F');
      // Now the actual SQL statement
      key.append(sql);
    }

    return key.toString();
  }
*/

  /**
   * Constructs a parameter definition string for use with
   * sp_executesql, sp_prepare, sp_prepexec, sp_cursoropen,
   * sp_cursorprepare and sp_cursorprepexec.
   *
   * @param parameters Parameters to construct the definition for
   * @return a parameter definition string
   */
  public static String getParameterDefinitions(ParamInfo[] parameters)
  {
    StringBuilder sql = new StringBuilder(parameters.length * 15);

    // Build parameter descriptor
    for (int i = 0; i < parameters.length; i++) {
      if (parameters[i].name == null) {
        sql.append("@P");
        sql.append(i);
      } else {
        sql.append(parameters[i].name);
      }

      sql.append(' ');
      sql.append(parameters[i].sqlType);

      if (i + 1 < parameters.length) {
        sql.append(',');
      }
    }

    return sql.toString();
  }

  /**
   * Update the SQL string and replace the ? markers with parameter names
   * eg @P0, @P1 etc.
   *
   * @param sql  the SQL containing markers to substitute
   * @param list the parameter list
   * @return the modified SQL as a  String
   */
  public static String substituteParamMarkers(String sql, ParamInfo[] list)
  {
    // A parameter can have at most 8 characters: " @P" plus at most 4
    // digits plus " ". We subtract the "?" placeholder, that's at most
    // 7 extra characters needed for each parameter.
    char[] buf = new char[sql.length() + list.length * 7];
    int bufferPtr = 0; // Output buffer pointer
    int start = 0;     // Input string pointer
    StringBuilder number = new StringBuilder(4);

    for (int i = 0; i < list.length; i++) {
      int pos = list[i].markerPos;

      if (pos > 0) {
        sql.getChars(start, pos, buf, bufferPtr);
        bufferPtr += (pos - start);
        start = pos + 1;

        // Append " @P"
        buf[bufferPtr++] = ' ';
        buf[bufferPtr++] = '@';
        buf[bufferPtr++] = 'P';

        // Append parameter number
        // Rather complicated, but it's the only way in which no
        // unnecessary objects are created
        number.setLength(0);
        number.append(i);
        number.getChars(0, number.length(), buf, bufferPtr);
        bufferPtr += number.length();

        // Append " "
        buf[bufferPtr++] = ' ';
      }
    }

    if (start < sql.length()) {
      sql.getChars(start, sql.length(), buf, bufferPtr);
      bufferPtr += (sql.length() - start);
    }

    return new String(buf, 0, bufferPtr);
  }

  /**
   * Substitute actual data for the parameter markers to simulate
   * parameter substitution in a PreparedStatement.
   *
   * @param sql        The SQL containing parameter markers to substitute.
   * @param list       The parameter descriptors.
   * @param connection The current connection.
   * @return The modified SQL statement.
   */
  public static String substituteParameters(String sql, ParamInfo[] list, JdbcConnection connection)
      throws SQLException
  {
    int len = sql.length();

    for (int i = 0; i < list.length; i++) {
      if (!list[i].isRetVal && !list[i].isSet && !list[i].isOutput) {
        throw new SQLException("error.prepare.paramnotset",
            "07000");
      }

      Object value = list[i].value;

      if (value instanceof java.io.InputStream
          || value instanceof java.io.Reader) {
        try {
          if (list[i].jdbcType == java.sql.Types.LONGVARCHAR ||
              list[i].jdbcType == java.sql.Types.CLOB ||
              list[i].jdbcType == java.sql.Types.VARCHAR) {
            // TODO: Should improve the character set handling here
            value = list[i].getString("US-ASCII");
          } else {
            value = list[i].getBytes("US-ASCII");
          }
          // Replace the stream/reader with the String/byte[]
          list[i].value = value;
        } catch (java.io.IOException e) {
          throw new SQLException("error.generic.ioerror",
              "HY000");
        }
      }

      if (value instanceof String) {
        len += ((String) value).length() + 5;
      } else if (value instanceof byte[]) {
        len += ((byte[]) value).length * 2 + 4;
      } else {
        len += 32; // Default size
      }
    }

    StringBuilder buf = new StringBuilder(len + 16);
    int start = 0;

    for (int i = 0; i < list.length; i++) {
      int pos = list[i].markerPos;

      if (pos > 0) {
        buf.append(sql.substring(start, list[i].markerPos));
        start = pos + 1;
        final boolean isUnicode = list[i].isUnicode;
        TypeConversion.embedData(buf, list[i].value, isUnicode, connection);
      }
    }

    if (start < sql.length()) {
      buf.append(sql.substring(start));
    }

    return buf.toString();
  }

  /**
   * Encode a string into a byte array using the specified character set.
   *
   * @param cs    The Charset name.
   * @param value The value to encode.
   * @return The value of the String as a  byte[]   .
   */
  public static byte[] encodeString(String cs, String value)
  {
    try {
      return value.getBytes(cs);
    } catch (UnsupportedEncodingException e) {
      return value.getBytes();
    }
  }

  /**
   * Link the original cause to an  SQLWarning   .
   * <p>
   * This convenience method calls {@link #linkException(Exception, Throwable)}
   * and casts the result for cleaner code elsewhere.
   *
   * @param sqle  The  SQLWarning    to enhance.
   * @param cause The  Throwable    to link.
   * @return The original  SQLWarning    object.
   */
  public static SQLWarning linkException(SQLWarning sqle, Throwable cause)
  {
    return (SQLWarning) linkException((Exception) sqle, cause);
  }

  /**
   * Link the original cause to an  SQLException   .
   * <p>
   * This convenience method calls {@link #linkException(Exception, Throwable)}
   * and casts the result for cleaner code elsewhere.
   *
   * @param sqle  The  SQLException    to enhance.
   * @param cause The  Throwable    to link.
   * @return The original  SQLException    object.
   */
  public static SQLException linkException(SQLException sqle, Throwable cause)
  {
    return (SQLException) linkException((Exception) sqle, cause);
  }

  /**
   * Link the original cause to an  Exception   .
   * <p>
   * If running under JVM 1.4+ the  Throwable.initCause(Throwable)
   * method will be invoked to chain the exception, else the exception is
   * logged via the {@link Logger} class.
   * Modeled after the code written by Brian Heineman.
   *
   * @param exception The  Exception    to enhance.
   * @param cause     The  Throwable    to link.
   * @return The original  Exception    object.
   */
  public static Throwable linkException(Exception exception, Throwable cause)
  {
    Class exceptionClass = exception.getClass();
    Class[] parameterTypes = new Class[]{Throwable.class};
    Object[] arguments = new Object[]{cause};

    try {
      Method initCauseMethod = exceptionClass.getMethod("initCause", parameterTypes);
      initCauseMethod.invoke(exception, arguments);
    } catch (NoSuchMethodException e) {
      // Best we can do; this method does not exist in older JVMs.
      if (Logger.isActive()) {
        Logger.logException((Exception) cause);
      }
    } catch (Exception e) {
      // Ignore all other exceptions.  Do not prevent the main exception
      // from being returned if reflection fails for any reason.
    }

    return exception;
  }


  /**
   * Convert a timestamp from a different Timezone.
   *
   * @param value  the timestamp value.
   * @param target the Calendar containing the TimeZone.
   * @return The new timestamp value as a  long   .
   */
  public static long timeFromZone(java.util.Date value, Calendar target)
  {
    // TODO: This should be reworked as per timestampToZone because it doesn't
    // TODO: handle nanoseconds, that a Timestamp value may have.
    java.util.Date tmp = target.getTime();
    try {
      GregorianCalendar cal = new GregorianCalendar();
      target.setTime(value);
      cal.set(Calendar.HOUR_OF_DAY, target.get(Calendar.HOUR_OF_DAY));
      cal.set(Calendar.MINUTE, target.get(Calendar.MINUTE));
      cal.set(Calendar.SECOND, target.get(Calendar.SECOND));
      cal.set(Calendar.MILLISECOND, target.get(Calendar.MILLISECOND));
      cal.set(Calendar.YEAR, target.get(Calendar.YEAR));
      cal.set(Calendar.MONTH, target.get(Calendar.MONTH));
      cal.set(Calendar.DAY_OF_MONTH, target.get(Calendar.DAY_OF_MONTH));
      return cal.getTime().getTime();
    } finally {
      target.setTime(tmp);
    }
  }

  /**
   * Interprets a timestamp in a given calendar's timezone and returns
   * the number of milliseconds since the epoch.
   * Note: this epoch milliseconds time seems to be timezoneless, or perhaps
   * considered as GMT. However, printing dates and times tends to be formatted
   * and reinterpreted using the timezone of the current JVM process. Be wary
   * when using Date/Time/Timestamp classes of java < 1.8.
   *
   * @param value  the timestamp value
   * @param target the  Calendar containing the TimeZone that the value
   *               time is to be interpretted in.
   * @return the equivalent time in milliseconds since the epoch, as UTC.
   */
  public static Timestamp timestampToZone(Timestamp value, Calendar target)
  {
    Calendar localCal = Calendar.getInstance();
    long now = localCal.getTime().getTime();
    int currentOffset =  localCal.getTimeZone().getOffset(now);
    int offsetDiff = currentOffset - target.getTimeZone().getOffset(now);

    Timestamp tsp = new Timestamp(value.getTime() + offsetDiff);
    tsp.setNanos(value.getNanos());
    return tsp;

//
//    synchronized(target) {
//      java.util.Date tmp = target.getTime();
//      try {
//
//        int nanos = value.getNanos();
//
//        GregorianCalendar cal = new GregorianCalendar();
//        cal.setTime(value);
//
//        int year = cal.get(Calendar.YEAR);
//        int month = cal.get(Calendar.MONTH);
//        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
//        int hour = cal.get(Calendar.HOUR_OF_DAY);
//        int min = cal.get(Calendar.MINUTE);
//        int sec = cal.get(Calendar.SECOND);
//
//        target.set(Calendar.YEAR,         year);
//        target.set(Calendar.MONTH,        month);
//        target.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//        target.set(Calendar.HOUR_OF_DAY,  hour);
//        target.set(Calendar.MINUTE,       min);
//        target.set(Calendar.SECOND,       sec);
//        target.set(Calendar.MILLISECOND,  0);
//
//        long t = target.getTime().getTime();
//
//        Timestamp tsp = new Timestamp(t);
//        tsp.setNanos(nanos);
//        return tsp;
//
//      } finally {
//        target.setTime(tmp);
//      }
//    }
  }

  /**
   * Interprets a timestamp in a given calendar's timezone and convert it
   * to a Date object, which contains milliseconds since the epoch in UTC.
   * Note: this epoch milliseconds time seems to be timezoneless, or perhaps
   * considered as GMT. However, printing dates and times tends to be formatted
   * and reinterpreted using the timezone of the current JVM process. Be wary
   * when using Date/Time/Timestamp classes of java < 1.8.
   *
   * @param value  the timestamp value
   * @param target the  Calendar containing the TimeZone that the value
   *               time is to be interpretted in.
   * @return the equivalent time in milliseconds since the epoch, as UTC.
   */
  public static Date timestampToDateWithZone(Timestamp value, Calendar target)
  {
    Calendar localCal = Calendar.getInstance();
    long now = localCal.getTime().getTime();
    int currentOffset =  localCal.getTimeZone().getOffset(now);
    int offsetDiff = currentOffset - target.getTimeZone().getOffset(now);

    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(value);
    cal.set(Calendar.HOUR_OF_DAY,  0);
    cal.set(Calendar.MINUTE,       0);
    cal.set(Calendar.SECOND,       0);
    cal.set(Calendar.MILLISECOND,  0);

    long millis = cal.getTimeInMillis() + offsetDiff;
    Date date = new Date(millis);
    return date;

//    synchronized(target) {
//      java.util.Date tmp = target.getTime();
//      try {
//
//        GregorianCalendar cal = new GregorianCalendar();
//        cal.setTime(value);
//        target.set(Calendar.YEAR,         cal.get(Calendar.YEAR));
//        target.set(Calendar.MONTH,        cal.get(Calendar.MONTH));
//        target.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH));
//        target.set(Calendar.HOUR_OF_DAY,  0);
//        target.set(Calendar.MINUTE,       0);
//        target.set(Calendar.SECOND,       0);
//        target.set(Calendar.MILLISECOND,  0);
//
//        Date date = new Date(target.getTimeInMillis());
//        return date;
//
//      } finally {
//        target.setTime(tmp);
//      }
//    }
  }

  /**
   * Interprets a timestamp in a given calendar's timezone and convert it
   * to a Date object, which contains milliseconds since the epoch in UTC.
   * Note: this epoch milliseconds time seems to be timezoneless, or perhaps
   * considered as GMT. However, printing dates and times tends to be formatted
   * and reinterpreted using the timezone of the current JVM process. Be wary
   * when using Date/Time/Timestamp classes of java < 1.8.
   *
   * @param value  the timestamp value
   * @param target the  Calendar containing the TimeZone that the value
   *               time is to be interpretted in.
   * @return the equivalent time in milliseconds since the epoch, as UTC.
   */
  public static Time timestampToTimeWithZone(Timestamp value, Calendar target)
  {
    Calendar localCal = Calendar.getInstance();
    long now = localCal.getTime().getTime();
    int currentOffset =  localCal.getTimeZone().getOffset(now);
    int offsetDiff = currentOffset - target.getTimeZone().getOffset(now);

    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(value);
    cal.set(Calendar.YEAR,         1970);
    cal.set(Calendar.MONTH,        0);
    cal.set(Calendar.DAY_OF_MONTH, 1);
    cal.set(Calendar.MILLISECOND,  0);

    long millis = cal.getTimeInMillis() + offsetDiff;
    Time time = new Time(millis);
    return time;

//    synchronized(target) {
//      java.util.Date tmp = target.getTime();
//      try {
//
//        GregorianCalendar cal = new GregorianCalendar();
//        cal.setTime(value);
//        target.set(Calendar.YEAR,         1970);
//        target.set(Calendar.MONTH,        0);
//        target.set(Calendar.DAY_OF_MONTH, 1);
//        target.set(Calendar.HOUR_OF_DAY,  cal.get(Calendar.HOUR_OF_DAY));
//        target.set(Calendar.MINUTE,       cal.get(Calendar.MINUTE));
//        target.set(Calendar.SECOND,       cal.get(Calendar.SECOND));
//        target.set(Calendar.MILLISECOND,  0);
//
//        Time time = new Time(target.getTimeInMillis());
//        return time;
//
//      } finally {
//        target.setTime(tmp);
//      }
//    }
  }

  /**
   * Converts a LOB to the equivalent Java type, i.e.  Clob    to
   * String    and  Blob    to  byte[]   . If the
   * value passed is not a LOB object, it is left unchanged and no exception
   * is thrown; the idea is to transparently convert only LOBs.
   *
   * @param value an object that may be a LOB
   * @return if the value was a LOB, the equivalent Java object, otherwise
   * the original value
   * @throws SQLException if an error occurs while reading the LOB contents
   */
  public static Object convertLOB(Object value) throws SQLException
  {
    if (value instanceof Clob) {
      Clob c = (Clob) value;
      return c.getSubString(1, (int) c.length());
    }

    if (value instanceof Blob) {
      Blob b = (Blob) value;
      return b.getBytes(1, (int) b.length());
    }

    return value;
  }

  /**
   * Converts a LOB type constant to the equivalent Java type constant, i.e.
   * Types.CLOB    to  Types.LONGVARCHAR    and
   * Types.BLOB    to  Types.LONGVARBINARY   . If the
   * type passed is not that of a LOB, it is left unchanged and no exception
   * is thrown; the idea is to transparently convert only LOB types.
   *
   * @param type a {@link Types} constant defining a JDBC type, possibly a
   *             LOB
   * @return if the type was that of a LOB, the equivalent Java object type,
   * otherwise the original type
   */
  public static int convertLOBType(int type)
  {
    switch (type) {
      case Types.BLOB:
        return Types.LONGVARBINARY;
      case Types.CLOB:
        return Types.LONGVARCHAR;
      default:
        return type;
    }
  }

  /**
   * Checks the  os.name    system property to see if it starts
   * with "windows".
   *
   * @return true    if  os.name    starts with "windows",
   * else  false   .
   */
  public static boolean isWindowsOS()
  {
    return System.getProperty("os.name").toLowerCase().startsWith("windows");
  }

  // ------------- Private methods  ---------

  /**
   * Returns the connection for a given  ResultSet   ,
   * Statement    or  Connection    object.
   *
   * @param callerReference an object reference to the caller of this method;
   *                        must be a  Connection   ,  Statement    or
   *                        ResultSet
   * @return a connection
   */
  private static JdbcConnection getConnection(Object callerReference)
  {
    if (callerReference == null) {
      throw new IllegalArgumentException("callerReference cannot be null.");
    }

    Connection connection;

    try {
      if (callerReference instanceof Connection) {
        connection = (Connection) callerReference;
      } else if (callerReference instanceof Statement) {
        connection = ((Statement) callerReference).getConnection();
      } else if (callerReference instanceof ResultSet) {
        connection = ((ResultSet) callerReference).getStatement().getConnection();
      } else {
        throw new IllegalArgumentException("callerReference is invalid.");
      }
    } catch (SQLException e) {
      throw new IllegalStateException(e.getMessage());
    }

    return (JdbcConnection) connection;
  }

  private TypeConversion()
  {
    // Prevent an instance of this class being created.
  }

  /**
   * Some debug code used for testing interval parsing.
   * @param args not used.
   */
  private static void testIntervalParsing(String[] args)
  {

    Pattern pattern = Pattern.compile(
        "\\s*"   +            // Leading whitespace
        "INTERVAL\\s+"  +           // Interval keyword
        "([-+]?)\\s*"   +           // Leading sign
        "'([^']+)'\\s+" +           // Quoted values
        "(\\w+)(?:\\(\\d+\\))?" +   // Start qualifier and precision
        "(?:\\s+TO\\s+(\\w+)(?:\\(\\d+(?:,\\d+)?\\))?)?" +   // End qualifier
        "\\s*", Pattern.CASE_INSENSITIVE);

    String[] inputs = {
        "INTERVAL '5' HOURS",
        "INTERVAL - '5' HOURS",
        "INTERVAL '-5' HOURS",
        "INTERVAL -'-5' HOURS",
        "INTERVAL -'-5' YEARS TO",
        "INTERVAL '5 3' YEARS TO MONTHS",
        "interval '1 02:03:04.555' days to seconds",
        "interval '1 02:03:04.555' days(3) to seconds(4,2)",
    };

    System.out.println("*** INTERVAL INPUTS ***");

    for (String input : inputs) {
      System.out.println();
      System.out.println("Input = " + input);
      Matcher matcher = pattern.matcher(input);
      System.out.println("Matches regex = " + matcher.matches());

      if (!matcher.matches()) {
        continue;
      }

      System.out.println("Num groups = " + matcher.groupCount());
      for (int i = 1; i <= matcher.groupCount(); i++) {
        String group = matcher.group(i);
        System.out.println("Group " + i + " = " + (group == null ? "<null>" : (group.isEmpty()? "<empty>" : group) ));
      }
    }

    Pattern ymPattern = Pattern.compile("([+-]?)" +       // Sign
                                        "(\\d+)" +        // year or month value
                                        "(?:-" +          // month non capture group & dash
                                          "(\\d+)" +      // month value
                                        ")?"              // end month non capture group
    );


    String[] ymInputs = {
        "5",
        "5-2",
        "-5",
        "-5-2",
        "+5",
        "+5-2",
        "-50-11",
    };

    System.out.println();
    System.out.println();
    System.out.println("*** YEAR-MONTH INPUTS ***");

    for (String ymInput : ymInputs) {
      System.out.println();
      System.out.println("Input = " + ymInput);
      Matcher matcher = ymPattern.matcher(ymInput);
      System.out.println("Matches regex = " + matcher.matches());

      if (!matcher.matches()) {
        continue;
      }

      System.out.println("Num groups = " + matcher.groupCount());
      for (int i = 1; i <= matcher.groupCount(); i++) {
        String group = matcher.group(i);
        System.out.println("Group " + i + " = " + (group == null ? "<null>" : (group.isEmpty()? "<empty>" : group) ));
      }
    }


    Pattern dtPattern = Pattern.compile("([+-]?)(\\d+)" +    // Sign and Days value
                                        "(?: " +             // Hour/min/sec non capture group + space
                                          "(\\d+)" +         // Hours
                                          "(?::" +           // Min/sec non capture group + colon
                                            "(\\d+)" +       // Minutes
                                            "(?::" +         // Seconds non capture group + colon
                                              "(\\d+)" +     // Seconds
                                              "(?:\\." +     // Fractional seconds non capture group + period
                                                "(\\d+)" +   // Fractional seconds
                                              ")?" +         // End fractional seconds non capture group
                                            ")?" +           // End seconds non capture group
                                          ")?" +             // End min/sec non capture group
                                        ")?"                 // End time non capture group
                                        );

    String[] dtInputs = {
        "1",
        "1 2",
        "-1",
        "-1 2",
        "+1",
        "+1 2",
        "1 2:3",
        "1 2:3:4",
        "1 2:3:4.5",
        "1 02:03:04.0005",
        "-1 02:03:04.0005",
    };

    System.out.println();
    System.out.println();
    System.out.println("*** DAY-TIME INPUTS ***");

    for (String dtInput : dtInputs) {
      System.out.println();
      System.out.println("Input = " + dtInput);
      Matcher matcher = dtPattern.matcher(dtInput);
      System.out.println("Matches regex = " + matcher.matches());

      if (!matcher.matches()) {
        continue;
      }

      System.out.println("Num groups = " + matcher.groupCount());
      for (int i = 1; i <= matcher.groupCount(); i++) {
        String group = matcher.group(i);
        System.out.println("Group " + i + " = " + (group == null ? "<null>" : (group.isEmpty()? "<empty>" : group) ));
      }
    }

    Pattern hmsPattern = Pattern.compile("([+-]?)" +        // Sign
                                         "(\\d+)" +         // Hours
                                         "(?::" +           // Min/sec non capture group + colon
                                           "(\\d+)" +       // Minutes
                                           "(?::" +         // Seconds non capture group + colon
                                             "(\\d+)" +     // Seconds
                                             "(?:\\." +     // Fractional seconds non capture group + period
                                               "(\\d+)" +   // Fractional seconds
                                             ")?" +         // End fractional seconds non capture group
                                           ")?" +           // End seconds non capture group
                                         ")?"               // End min/sec non capture group
    );

    Pattern msPattern = Pattern.compile("([+-]?)" +         // Sign
                                        "(\\d+)" +          // Minutes
                                        "(?::" +            // Seconds non capture group + colon
                                          "(\\d+)" +        // Seconds
                                          "(?:\\." +        // Fractional seconds non capture group + period
                                            "(\\d+)" +      // Fractional seconds
                                          ")?" +            // End fractional seconds non capture group
                                        ")?"                // End seconds non capture group
    );

    Pattern sPattern = Pattern.compile( "([+-]?)" +         // Sign
                                          "(\\d+)" +        // Seconds
                                          "(?:\\." +        // Fractional seconds non capture group + period
                                            "(\\d+)" +      // Fractional seconds
                                          ")?"              // End fractional seconds non capture group
    );


    System.out.println();
    System.out.println();
    System.out.println("*** HMS INPUTS ***");

    String[] hmsInputs = {
        "1",
        "+1",
        "-1",
        "1:2",
        "-1:2",
        "+1:2",
        "1:2:3",
        "1:2:3.4",
        "1:2:3.4",
        "01:02:03.004",
        "-01:02:03.004",
    };

    for (String hmsInput : hmsInputs) {
      System.out.println();
      System.out.println("Input = " + hmsInput);
      Matcher matcher = hmsPattern.matcher(hmsInput);
      System.out.println("Matches regex = " + matcher.matches());

      if (!matcher.matches()) {
        continue;
      }

      System.out.println("Num groups = " + matcher.groupCount());
      for (int i = 1; i <= matcher.groupCount(); i++) {
        String group = matcher.group(i);
        System.out.println("Group " + i + " = " + (group == null ? "<null>" : (group.isEmpty()? "<empty>" : group) ));
      }
    }

  }
}
