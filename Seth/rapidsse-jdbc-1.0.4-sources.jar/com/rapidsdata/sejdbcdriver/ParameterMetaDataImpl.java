// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

import com.jcabi.aspects.Loggable;
import com.rapidsdata.sejdbcdriver.sesupport.TypeConversion;
import com.rapidsdata.sejdbcdriver.sesupport.TypeHelper;

import java.sql.*;

/**
 * RDP implementation of ParameterMetaData.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class ParameterMetaDataImpl implements ParameterMetaData
{
  private final ParamInfo[] parameterList;
  private final int maxPrecision;
  private final boolean useLOBs;


  public ParameterMetaDataImpl(ParamInfo[] parameterList, JdbcConnection connection)
  {
    if (parameterList == null) {
      parameterList = new ParamInfo[0];
    }

    this.parameterList = parameterList;
    this.maxPrecision = connection.getMaxPrecision();
    this.useLOBs = connection.getUseLOBs();
  }

  public int getParameterCount() throws SQLException
  {
    return parameterList.length;
  }

  public int isNullable(int param) throws SQLException
  {
    return ParameterMetaData.parameterNullableUnknown;
  }

  public int getParameterType(int param) throws SQLException
  {
    if (useLOBs) {
      return getParameter(param).jdbcType;
    } else {
      return TypeConversion.convertLOBType(getParameter(param).jdbcType);
    }
  }

  public int getScale(int param) throws SQLException
  {
    ParamInfo pi = getParameter(param);

    return (pi.scale >= 0) ? pi.scale : 0;
  }

  public boolean isSigned(int param) throws SQLException
  {
    ParamInfo pi = getParameter(param);

    switch (pi.jdbcType) {
      case java.sql.Types.BIGINT:
      case java.sql.Types.DECIMAL:
      case java.sql.Types.DOUBLE:
      case java.sql.Types.FLOAT:
      case java.sql.Types.INTEGER:
      case java.sql.Types.SMALLINT:
      case java.sql.Types.REAL:
      case java.sql.Types.NUMERIC:
        return true;
      default:
        return false;
    }
  }

  public int getPrecision(int param) throws SQLException
  {
    ParamInfo pi = getParameter(param);

    return (pi.precision >= 0) ? pi.precision : maxPrecision;
  }

  public String getParameterTypeName(int param) throws SQLException
  {
    return getParameter(param).sqlType;
  }

  public String getParameterClassName(int param) throws SQLException
  {
    return TypeHelper.getClassName(getParameterType(param));
  }

  public int getParameterMode(int param) throws SQLException
  {
    ParamInfo pi = getParameter(param);

    if (pi.isOutput) {
      return pi.isSet ? parameterModeInOut : parameterModeOut;
    }

    return pi.isSet ? parameterModeIn : parameterModeUnknown;
  }

  private ParamInfo getParameter(int param) throws SQLException
  {
    if (param < 1 || param > parameterList.length) {
      throw new SQLException(
          "error.prepare.paramindex", "07009");
    }

    return parameterList[param - 1];
  }

  /////// JDBC4 demarcation, do NOT put any JDBC3 code below this line ///////

  /* (non-Javadoc)
   * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
   */
  public boolean isWrapperFor(Class arg0) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

  /* (non-Javadoc)
   * @see java.sql.Wrapper#unwrap(java.lang.Class)
   */
  public Object unwrap(Class arg0) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

}