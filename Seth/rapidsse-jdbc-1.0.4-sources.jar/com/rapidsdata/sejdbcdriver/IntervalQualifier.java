package com.rapidsdata.sejdbcdriver;

public enum IntervalQualifier
{
  YEAR,
  MONTH,
  DAY,
  HOUR,
  MINUTE,
  SECOND
}
