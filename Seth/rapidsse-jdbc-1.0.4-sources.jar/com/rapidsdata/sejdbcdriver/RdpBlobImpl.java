// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

import com.jcabi.aspects.Loggable;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;

import static com.rapidsdata.sejdbcdriver.JdbcResultSet.notImplemented;

/**
 * An in-memory or disk based representation of binary data.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class RdpBlobImpl implements Blob
{
  /**
   * 0 length  byte[]    as initial value for empty
   * Blob   s.
   */
  private static final byte[] EMPTY_BLOB = new byte[0];

  /**
   * The underlying  BlobBuffer   .
   */
  private final BlobBuffer blobBuffer;

  /**
   * Constructs a new empty  Blob    instance.
   *
   * @param connection a reference to the parent connection object
   */
  public RdpBlobImpl(JdbcConnection connection)
  {
    this(connection, EMPTY_BLOB);
  }

  /**
   * Constructs a new  Blob    instance initialized with data.
   *
   * @param connection a reference to the parent connection object
   * @param bytes      the blob object to encapsulate
   */
  public RdpBlobImpl(JdbcConnection connection, byte[] bytes)
  {
    if (bytes == null) {
      throw new IllegalArgumentException("bytes cannot be null");
    }

    blobBuffer = new BlobBuffer(connection.getBufferDir(), bytes.length);
    blobBuffer.setBuffer(bytes, false);
  }

  //
  // ------ java.sql.Blob interface methods from here -------
  //

  public InputStream getBinaryStream() throws SQLException
  {
    return blobBuffer.getBinaryStream(false);
  }

  public byte[] getBytes(long pos, int length) throws SQLException
  {
    return blobBuffer.getBytes(pos, length);
  }

  public long length() throws SQLException
  {
    return blobBuffer.getLength();
  }

  public long position(byte[] pattern, long start) throws SQLException
  {
    return blobBuffer.position(pattern, start);
  }

  public long position(Blob pattern, long start) throws SQLException
  {
    if (pattern == null) {
      throw new SQLException("error.blob.badpattern", "HY009");
    }
    return blobBuffer.position(pattern.getBytes(1, (int) pattern.length()), start);
  }

  public OutputStream setBinaryStream(final long pos) throws SQLException
  {
    return blobBuffer.setBinaryStream(pos, false);
  }

  public int setBytes(long pos, byte[] bytes) throws SQLException
  {
    if (bytes == null) {
      throw new SQLException("error.blob.bytesnull", "HY009");
    }
    return setBytes(pos, bytes, 0, bytes.length);
  }

  public int setBytes(long pos, byte[] bytes, int offset, int len)
      throws SQLException
  {
    if (bytes == null) {
      throw new SQLException("error.blob.bytesnull", "HY009");
    }
    // Force BlobBuffer to take a copy of the byte array
    // In many cases this is wasteful but the user may
    // reuse the byte buffer corrupting the original set
    return blobBuffer.setBytes(pos, bytes, offset, len, true);
  }

  public void truncate(long len) throws SQLException
  {
    blobBuffer.truncate(len);
  }

  /////// JDBC4 demarcation, do NOT put any JDBC3 code below this line ///////

  public void free() throws SQLException
  {
    try {
      blobBuffer.close();
    } catch (IOException e) {
      throw new SQLException(e);
    }
  }

  public InputStream getBinaryStream(long pos, long length)
      throws SQLException
  {
    notImplemented("getBinaryStream(long, long)");
    return null; // never reached.
  }
}