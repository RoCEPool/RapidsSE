// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver.cache;

import com.rapidsdata.sejdbcdriver.JdbcConnection;

/**
 * Cache key for an SQL query, consisting of the query and server type, major
 * and minor version.
 *
 
 */
public class SQLCacheKey {
    private final String sql;
    private final int serverType;
    private final int majorVersion;
    private final int minorVersion;
    private final int hashCode;

    public SQLCacheKey(String sql, JdbcConnection connection) {
        this.sql = sql;
        this.serverType = connection.getServerType();
        this.majorVersion = connection.getDatabaseMajorVersion();
        this.minorVersion = connection.getDatabaseMinorVersion();

        this.hashCode = sql.hashCode()
                ^ (serverType << 24 | majorVersion << 16 | minorVersion);
    }

    public int hashCode() {
        return hashCode;
    }

    public boolean equals(Object object) {
        try {
            SQLCacheKey key = (SQLCacheKey) object;

            return this.hashCode == key.hashCode
                    && this.majorVersion == key.majorVersion
                    && this.minorVersion == key.minorVersion
                    && this.serverType == key.serverType
                    && this.sql.equals(key.sql);
        } catch (ClassCastException e) {
            return false;
        } catch (NullPointerException e) {
            return false;
        }
    }
}
