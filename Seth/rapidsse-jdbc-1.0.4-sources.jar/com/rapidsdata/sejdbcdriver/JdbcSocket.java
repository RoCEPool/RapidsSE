
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * This class handles connection to the RDP Server and
 * serialises its use amongst a number of virtual sockets.
 * This allows one physical connection to service a number of concurrent
 * statements.
 * <p>
 * Callers will not attempt to read from the server without issuing a request first.
 * The end of a server reply can be identified as byte 2 of the header is non zero.
 * <p>
 * Comments:
 * <p>
 * This code will discard unread server data if a new request is issued.
 * <p>
 * This version of the class will start to cache results to disk once a predetermined
 * maximum buffer memory threshold has been passed. Small result sets that will fit
 * within a specified limit (default 8 packets) will continue to be held in memory
 * (even if the memory threshold has been passed) in the interests of efficiency.
 */
class JdbcSocket
{
  /**
   * This inner class contains the state information for the virtual socket.
   */
  static class VirtualSocket
  {
    /**
     * The stream ID of the stream objects owning this state.
     */
    final int id;
    /**
     * Memory resident packet queue.
     */
    final LinkedList pktQueue;
    /**
     * File object for disk packet queue.
     */
    File queueFile;
    /**
     * I/O Stream for disk packet queue.
     */
    RandomAccessFile diskQueue;
    /**
     * Number of packets cached to disk.
     */
    int pktsOnDisk;
    /**
     * Total of input packets in memory or disk.
     */
    int inputPkts;

    /**
     * Construct object to hold state information for each caller.
     *
     * @param streamId the Response/Request stream id.
     */
    private VirtualSocket(int streamId)
    {
      id = streamId;
      pktQueue = new LinkedList();
    }
  }

  /**
   * The shared network socket.
   */
  private Socket socket;

  /**
   * Input  and Output stream for network socket.
   */
  private OutputStream out;
  private InputStream in;
  /**
   * Current maximum input buffer size.
   */
  private int maxBufSize = 0;
  /**
   * last ID assigned to a VirtualSocket instance
   */
  private final AtomicInteger _LastID = new AtomicInteger();
  /**
   * Table of stream objects sharing this socket.
   */
  private final ConcurrentMap<Integer, VirtualSocket> _VirtualSockets = new ConcurrentHashMap<>();
  /**
   * The virtual socket of the object that is expecting a response from the server.
   */
  private VirtualSocket responseOwner;
  /**
   * Buffer for packet header.
   */
  private final byte hdrBuf[] = new byte[RDP_HDR_LEN];
  /**
   * The directory to buffer data to.
   */
  private final File bufferDir;
  /**
   * Total memory usage in all instances of the driver
   * NB. Access to this field should probably be synchronized
   * but in practice lost updates will not matter much and I think
   * all VMs tend to do atomic saves to integer variables.
   */
  private static int globalMemUsage;
  /**
   * Peak memory usage for debug purposes.
   */
  private static int peakMemUsage;
  /**
   * Max memory limit to use for buffers.
   * Only when this limit is exceeded will the driver
   * start caching to disk.
   */
  private static int memoryBudget = 100000; // 100K
  /**
   * Minimum number of packets that will be cached in memory
   * before the driver tries to write to disk even if
   * memoryBudget has been exceeded.
   */
  private static int minMemPkts = 8;
  /**
   * Global flag to indicate that security constraints mean
   * that attempts to create work files will fail.
   */
  private static boolean securityViolation;
  /**
   * RDP protocol version
   */
  private int rdpVersion;
  /**
   * The servertype
   */
  protected final int serverType;
  /**
   * The character set to use for converting strings to/from bytes.
   */
  private CharsetInfo charsetInfo;
  /**
   * Count of packets received.
   */
  private int packetCount;
  /**
   * The server host name.
   */
  private String host;
  /**
   * The server port number.
   */
  private int port;
  /**
   * A cancel packet is pending.
   */
  private boolean cancelPending;
  /**
   * Synchronization monitor for {@link #cancelPending} and
   * {@link #responseOwner}.
   */
  private final Object cancelMonitor = new Object();
  /**
   * Buffer for RDP_DONE packets
   */
  private final byte doneBuffer[] = new byte[RDP_DONE_LEN];
  /**
   * How much of the doneBuffer has been filled with data, <RDP_DONE_LEN IFF partial packet read.
   */
  private int doneBufferFrag = 0;
  /**
   * RDP done token.
   */
  private static final int RDP_DONE_TOKEN = 253;
  /**
   * Length of a RDP_DONE token.
   */
  private static final int RDP_DONE_LEN = 9;
  /**
   * Length of RDP packet header.
   */
  private static final int RDP_HDR_LEN = 4; // BaseProtocolHandler.MSG_HEADER_SIZE

  protected JdbcSocket(File bufferDir, int rdpVersion, int serverType)
  {
    this.bufferDir = bufferDir;
    this.rdpVersion = rdpVersion;
    this.serverType = serverType;
  }

  /**
   * Creates a {@link Socket} connection.
   *
   * @param connection the connection object
   * @return a socket open to the host and port with the given timeout
   * @throws IOException if socket open fails
   */
  /*
  private Socket createSocketForJDBC(JdbcConnection connection) throws IOException
  {
    final String bindAddress = connection.getBindAddress();
    final int loginTimeout = 3;

    HostInfo[] hostArray = connection.getHostInfo();

    boolean bThrow = true;
    int index=0;
    if (hostArray.length > 1) {
      Random rand = new Random();
      index = rand.nextInt(hostArray.length);
      bThrow = false;
    }

    host = hostArray[index].getHost();
    port = hostArray[index].getPort();

      // establish connection
    int iTry = 1;
    socket = doConnect(bindAddress, host, port, loginTimeout, bThrow);

    while (socket != null && !socket.isConnected())
    {
      // Connection failure, let's try other hosts in the list.
      if ((index + 1) < hostArray.length)
        ++index;
      else
        index = 0;
      host = hostArray[index].getHost();
      port = hostArray[index].getPort();
      ++iTry;
      if (iTry == hostArray.length) {
        bThrow = true; // last try, throw exception if failure
      } else if (iTry > hostArray.length) {
        break; // Tried them all, let's get out
      }

      socket = doConnect(bindAddress, host, port, loginTimeout, bThrow);
    }

    return socket;
  }
*/
  Socket doConnect(String bindAddress, String host, int port, int loginTimeout, boolean bThrow) throws IOException
  {
    Socket lSocket = new Socket();
    //LOG.debug(String.format("trying to connect to server:%s:%d", host, port));
    try {
      InetSocketAddress address = new InetSocketAddress(host, port);
      // call Socket.bind(SocketAddress) if bindAddress parameter is set
      if (bindAddress != null && !bindAddress.isEmpty()) {
        socket.bind(new InetSocketAddress(bindAddress, 0));
      }
      lSocket.connect(address, loginTimeout * 1000);
    } catch (IOException e) {
      if (bThrow) {
        throw e;
      }
    }

    return lSocket;
  }

  String getMAC()
  {
    try {
      NetworkInterface nic = NetworkInterface.getByInetAddress(socket.getLocalAddress());
      byte[] address = nic == null ? null : nic.getHardwareAddress();

      if (address != null) {
        String mac = "";

        for (int k = 0; k < address.length; k++) {
          String macValue = String.format("%02X", address[k]);
          mac += macValue;
        }

        return mac;
      }
    } catch (SocketException e) {
      // error getting network interfaces, return null
    }

    return null;
  }

  public String getRemoteSocketAddr()
  {
    return socket.getRemoteSocketAddress().toString();
  }


  /**
   * Set the character set descriptor to be used to translate byte arrays to
   * or from Strings.
   *
   * @param charsetInfo the character set descriptor
   */
  void setCharsetInfo(CharsetInfo charsetInfo)
  {
    this.charsetInfo = charsetInfo;
  }

  /**
   * Retrieve the character set descriptor used to translate byte arrays to
   * or from Strings.
   */
  CharsetInfo getCharsetInfo()
  {
    return charsetInfo;
  }

  /**
   * Retrieve the character set name used to translate byte arrays to
   * or from Strings.
   *
   * @return the character set name as a  String
   */
  String getCharset()
  {
    return charsetInfo.getCharset();
  }

  public InputStream getInStream()
  {
    return in;
  }

  public OutputStream getOutStream()
  {
    return out;
  }

  public boolean isSockClosed()
  {
    return socket.isClosed();
  }


  /**
   * Retrieve the RDP version that is active on the connection
   * supported by this socket.
   *
   * @return the RDP version as an  int
   */
  int getRdpVersion()
  {
    return rdpVersion;
  }

  /**
   * @param rdpVersion the RDP version
   */
  protected void setRdpVersion(int rdpVersion)
  {
    this.rdpVersion = rdpVersion;
  }

  /**
   * Set the global buffer memory limit for all instances of this driver.
   *
   * @param memoryBudget the global memory budget
   */
  static void setMemoryBudget(int memoryBudget)
  {
    JdbcSocket.memoryBudget = memoryBudget;
  }

  /**
   * Get the global buffer memory limit for all instancs of this driver.
   *
   * @return the memory limit as an  int
   */
  static int getMemoryBudget()
  {
    return JdbcSocket.memoryBudget;
  }

  /**
   * Set the minimum number of packets to cache in memory before
   * writing to disk.
   *
   * @param minMemPkts the minimum number of packets to cache
   */
  static void setMinMemPkts(int minMemPkts)
  {
    JdbcSocket.minMemPkts = minMemPkts;
  }

  /**
   * Get the minimum number of memory cached packets.
   *
   * @return minimum memory packets as an  int
   */
  static int getMinMemPkts()
  {
    return JdbcSocket.minMemPkts;
  }

  /**
   * Get the connected status of this socket.
   *
   * @return true    if the underlying socket is connected
   */
  boolean isConnected()
  {
    return socket != null;
  }

  /**
   * Send a RDP cancel packet to the server.
   *
   * @param vsock the {@link VirtualSocket} used by the request to be canceled
   * @return {@code true} if a cancel is actually issued by this method call
   */
  boolean cancel(VirtualSocket vsock)
  {

    return false;
  }

  /**
   * Close the socket and release all resources.
   *
   * @throws IOException if the socket close fails
   */
  void close()
      throws IOException
  {
    if (Logger.isActive()) {
      Logger.println("RdpSocket: Max buffer memory used = " + (peakMemUsage / 1024) + "KB");
    }

    // see if any temporary files need deleting
    for (VirtualSocket vsock : _VirtualSockets.values()) {
      if (vsock != null && vsock.diskQueue != null) {
        try {
          vsock.diskQueue.close();
          vsock.queueFile.delete();
        } catch (IOException ioe) {
          // ignore errors
        }
      }
    }

    _VirtualSockets.clear();

    try {
      if (socket != null) {
        socket.close();

      }
    } finally {
      socket = null;
    }
  }

  /**
   * Force close the socket causing any pending reads/writes to fail.
   * <p>
   * Used by the login timer to abort a login attempt.
   */
  void forceClose()
  {
    if (socket != null) {
      try {
        socket.close();
      } catch (IOException ioe) {
        // Ignore
      } finally {
        socket = null;
      }
    }
  }

  /**
   * Deallocate a stream linked to this socket.
   *
   * @param vsock the {@link VirtualSocket} to close
   */
  void closeStream(VirtualSocket vsock)
  {
    // unregister virtual socket
    _VirtualSockets.remove(vsock.id);

    if (vsock.diskQueue != null) {
      try {
        vsock.diskQueue.close();
        vsock.queueFile.delete();
      } catch (IOException ioe) {
        // ignore errors
      }
    }
  }


  /**
   * Set the socket timeout.
   *
   * @param timeout the timeout value in milliseconds
   */
  protected void setTimeout(int timeout) throws SocketException
  {
    socket.setSoTimeout(timeout);
  }

  /**
   * Set the socket keep alive.
   *
   * @param keepAlive true    to turn on socket keep alive
   */
  protected void setKeepAlive(boolean keepAlive) throws SocketException
  {
    socket.setKeepAlive(keepAlive);
  }

  /**
   * Getter for {@link JdbcSocket#in} field.
   *
   * @return {@link InputStream} used for communication
   */
  protected InputStream getIn()
  {
    return in;
  }

  /**
   * Setter for {@link JdbcSocket#in} field.
   *
   * @param in the {@link InputStream} to be used for communication
   */
  protected void setIn(InputStream in)
  {
    this.in = in;
  }

  /**
   * Getter for {@link JdbcSocket#out} field.
   *
   * @return {@link OutputStream} used for communication
   */
  protected OutputStream getOut()
  {
    return out;
  }

  /**
   * Setter for {@link JdbcSocket#out} field.
   *
   * @param out the {@link OutputStream} to be used for communication
   */
  protected void setOut(OutputStream out)
  {
    this.out = out;
  }

  /**
   * Get the server host name.
   *
   * @return the host name as a  String
   */
  protected String getHost()
  {
    return host;
  }

  /**
   * Get the server port number.
   *
   * @return the host port as an  int
   */
  protected int getPort()
  {
    return port;
  }

  /**
   * Ensure all resources are released.
   */
  protected void finalize()
      throws Throwable
  {
    try {
      close();
    } finally {
      super.finalize();
    }
  }

}