// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;
import java.util.Objects;

public class RdpInterval implements Serializable
{
  public enum IntervalType {
    YEAR_MONTH,
    DAY_TIME
  }

  private IntervalType type;
  private long years;
  private long months;
  private long days;
  private long hours;
  private long minutes;
  private long seconds;
  private long nanos;


  public RdpInterval(long years, long months)
  {
    this.type    = IntervalType.YEAR_MONTH;
    this.years   = years;
    this.months  = months;
    this.days    = 0;
    this.hours   = 0;
    this.minutes = 0;
    this.seconds = 0;
    this.nanos   = 0;
  }

  public RdpInterval(long days, long hours, long minutes, long seconds, long nanos)
  {
    this.type    = IntervalType.DAY_TIME;
    this.years   = 0;
    this.months  = 0;
    this.days    = days;
    this.hours   = hours;
    this.minutes = minutes;
    this.seconds = seconds;
    this.nanos   = nanos;
  }

  // public RdpInterval(String value)

  public long getYears()            { return years;   }
  public long getMonths()           { return months;  }
  public long getDays()             { return days;    }
  public long getHours()            { return hours;   }
  public long getMinutes()          { return minutes; }
  public long getSeconds()          { return seconds; }
  public long getNanos()            { return nanos;   }

  public void setYears(long val)    { years = val;    }
  public void setMonths(long val)   { months = val;   }
  public void setDays(long val)     { days = val;     }
  public void setHours(long val)    { hours = val;    }
  public void setMinutes(long val)  { minutes = val;  }
  public void setSeconds(long val)  { seconds = val;  }
  public void setNanos(long val)    { nanos = val;    }

  @Override
  public boolean equals(Object o)
  {
    if (o == null) {
      return false;
    }

    if (o == this) {
      return true;
    }

    if (!(o instanceof RdpInterval)) {
      return false;
    }

    RdpInterval ival = (RdpInterval) o;

    return (this.years    == ival.years   &&
            this.months   == ival.months  &&
            this.days     == ival.days    &&
            this.hours    == ival.hours   &&
            this.minutes  == ival.minutes &&
            this.seconds  == ival.seconds &&
            this.nanos    == ival.nanos);
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(years, months, days, hours, minutes, seconds, nanos);
  }

  /**
   * Adds this interval to the calendar parameter object and returns the updated instance.
   * @param cal The calendar to add an interval to.
   * @return the calendar instance with the interval added to it.
   */
  public Calendar addIntervalTo(Calendar cal)
  {
    int millis = (int) ((nanos + ((nanos < 0) ? -500000 : 500000)) / 1000000L);  // rounding with loss of precision.
    cal.add(Calendar.MILLISECOND,   millis);
    cal.add(Calendar.SECOND,        (int) this.seconds);
    cal.add(Calendar.MINUTE,        (int) this.minutes);
    cal.add(Calendar.HOUR,          (int) this.hours);
    cal.add(Calendar.DAY_OF_MONTH,  (int) this.days);
    cal.add(Calendar.MONTH,         (int) this.months);
    cal.add(Calendar.YEAR,          (int) this.years);

    return cal;
  }

  /**
   * Adds this interval to the date parameter object and returns the updated instance.
   * @param date The date to add an interval to.
   * @return the date instance with the interval added to it.
   */
  public Date addIntervalTo(Date date)
  {
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    addIntervalTo(cal);
    date.setTime(cal.getTime().getTime());
    return date;
  }

  /**
   * Adds the interval parameter to this interval.
   * @param ival The interval to add to this one.
   */
  public void add(RdpInterval ival)
  {
    this.years    += ival.years;
    this.months   += ival.months;
    this.days     += ival.days;
    this.hours    += ival.hours;
    this.minutes  += ival.minutes;
    this.seconds  += ival.seconds;
    this.nanos    += ival.nanos;
  }

  /**
   * The value of this interval represented as a string.
   * @return
   */
  @Override
  public String toString()
  {
    if (type == IntervalType.YEAR_MONTH) {
      return String.format("%+d-%02d", this.years, this.months);

    } else {
      return String.format("%+d %02d:%02d:%02d.%09d",
                           this.days,
                           this.hours,
                           this.minutes,
                           this.seconds,
                           this.nanos);
    }
  }

  /**
   * This value decorated with the INTERVAL type name and value in single quotes.
   * @return
   */
  public String toDecoratedString()
  {
    return "INTERVAL '" + toString() + "'";
  }
}
