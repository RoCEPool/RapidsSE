// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * DataTime util
 */
public class utilDateTime
{
  /**
   * Indicates date value not used.
   */
  static final int DATE_NOT_USED = Integer.MIN_VALUE;
  /**
   * Indicates time value not used.
   */
  static final int TIME_NOT_USED = Integer.MIN_VALUE;

  /** How many nanoseconds in a millisecond. */
  static final int NANOS_TO_MILLIS = 1000000;

  /**
   * The date component of the server datetime value.
   */
  private int date;
  /**
   * The time component of the server datetime value.
   */
  private int time;
  /**
   * Unpacked year value.
   */
  private short year;
  /**
   * Unpacked month value.
   */
  private short month;
  /**
   * Unpacked day value.
   */
  private short day;
  /**
   * Unpacked hour value.
   */
  private short hour;
  /**
   * Unpacked minute value.
   */
  private short minute;
  /**
   * Unpacked second value.
   */
  private short second;
  /**
   * Unpacked millisecond value.
   */
  private int nanos;
  /**
   * Cached value of the datetime as a  String   .
   */
  private String stringValue;
  /**
   * Cached value of the datetime as a  java.sql.Timestamp   .
   */
  private Timestamp tsValue;
  /**
   * Cached value of the datetime as a  java.sql.Date   .
   */
  private Date dateValue;
  /**
   * Cached value of the datetime as a  java.sql.Time   .
   */
  private Time timeValue;

  /**
   * Constructs a utilDateTime object from the two integer components of a
   * datetime.
   *
   * @param date server date field
   * @param time server time field
   */
  public utilDateTime(int date, int time)
  {
    this.date = date;
    this.time = time;
  }

  /**
   * Constructs a utilDateTime object from the two short components of a
   * smalldatetime.
   *
   * @param date server date field
   * @param time server time field
   */
  public utilDateTime(short date, short time)
  {
    this.date = date & 0xFFFF;
    this.time = time * 60 * 300;
  }

  /**
   * Constructs a utilDateTime object from a  java.sql.Timestamp   .
   *
   * @param ts Timestamp    object representing the datetime
   * @throws SQLException if the date is out of range
   */
  public utilDateTime(Timestamp ts) throws SQLException
  {
    tsValue = ts;
    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(ts);

    if (cal.get(Calendar.ERA) != GregorianCalendar.AD)
      throw new SQLException("error.datetime.range.era", "22007");

    year = (short) cal.get(Calendar.YEAR);
    month = (short) (cal.get(Calendar.MONTH) + 1);
    day = (short) cal.get(Calendar.DAY_OF_MONTH);
    hour = (short) cal.get(Calendar.HOUR_OF_DAY);
    minute = (short) cal.get(Calendar.MINUTE);
    second = (short) cal.get(Calendar.SECOND);
    nanos = ts.getNanos();
  }

  /**
   * Constructs a utilDateTime object from individual values   .
   *
   * @param sYear the year is the correct year
   * @param sMonth 1..12
   * @param sDay 1 to 31
   * @param sHour 0 to 23
   * @param sMinute 0 to 59
   * @param sSec 0 to 59
   * @throws SQLException if the date is out of range
   */
  public utilDateTime(short sYear, short sMonth, short sDay,
               short sHour, short sMinute, short sSec, int iNanos) throws SQLException
  {
    year = sYear;
    month = sMonth; // expected month is correct
    day = sDay;
    hour = sHour;
    minute = sMinute;
    second = sSec;
    nanos = iNanos;
  }

  /**
   * Constructs a utilDateTime object from individual values   .
   *
   * @param sYear the year is correct
   * @param sMonth 1 to 12
   * @param sDay 1 to 31
   * @throws SQLException if the date is out of range
   */
  public utilDateTime(short sYear, short sMonth, short sDay) throws SQLException
  {
    year = sYear;
    month = sMonth;
    day = sDay;
    hour = 0;
    minute = 0;
    second = 0;
    nanos = 0;
    time = TIME_NOT_USED;
  }

  /**
   * Constructs a utilDateTime object from individual values   .
   *
   * @param sHour 0 to 23
   * @param sMinute 0 to 59
   * @param sSec 0 to 59
   * @throws SQLException if the date is out of range
   */
  public utilDateTime(short sHour, short sMinute, short sSec, boolean disambiguation) throws SQLException
  {
    year = 0;
    month = 0;
    day = 0;
    hour = sHour;
    minute = sMinute;
    second = sSec;
    nanos = 0;    // java.sql.Time doesn't have millisecond level accuracy. Setting this
                  // to zero to avoid comparisons to other Time objects that don't have
                  // milliseconds failing.
    date = DATE_NOT_USED;
  }

  /**
   * Constructs a utilDateTime object from a  java.sql.Time   .
   *
   * @param t Time    object representing the datetime
   * @throws SQLException if the time (date) is out of range
   */
  public utilDateTime(Time t) throws SQLException
  {
    timeValue = t;
    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(t);

    if (cal.get(Calendar.ERA) != GregorianCalendar.AD)
      throw new SQLException("error.datetime.range.era", "22007");

    date = DATE_NOT_USED;
    year = 1900;
    month = 1;
    day = 1;
    hour = (short) cal.get(Calendar.HOUR_OF_DAY);
    minute = (short) cal.get(Calendar.MINUTE);
    second = (short) cal.get(Calendar.SECOND);
    nanos = cal.get(Calendar.MILLISECOND) * 1000 * 1000;
    year = 1970;
    month = 1;
    day = 1;
  }

  /**
   * Constructs a utilDateTime object from a  java.sql.Date   .
   *
   * @param d Date    object representing the datetime
   * @throws SQLException if the Date is out of range
   */
  public utilDateTime(Date d) throws SQLException
  {
    dateValue = d;
    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(d);

    if (cal.get(Calendar.ERA) != GregorianCalendar.AD)
      throw new SQLException("error.datetime.range.era", "22007");

    year = (short) cal.get(Calendar.YEAR);
    month = (short) (cal.get(Calendar.MONTH) + 1);
    day = (short) cal.get(Calendar.DAY_OF_MONTH);
    hour = 0;
    minute = 0;
    second = 0;
    nanos = 0;
    time = TIME_NOT_USED;
  }

  /**
   * Retrieves the date component of a datetime value.
   *
   * @return the datetime date component as an  int
   */
  int getDate()
  {
    return (date == DATE_NOT_USED) ? 0 : date;
  }

  /**
   * Retrieves the time component of a datetime value.
   *
   * @return the datetime time component as an  int
   */
  int getTime()
  {
    return (time == TIME_NOT_USED) ? 0 : time;
  }

  /**
   * Retrieves the current datetime value as a Timestamp.
   *
   * @return the current datetime value as a  java.sql.Timestamp
   */
  public Timestamp toTimestamp()
  {
    if (tsValue == null) {
      GregorianCalendar cal = new GregorianCalendar();
      cal.set(Calendar.YEAR, year);
      cal.set(Calendar.MONTH, month - 1);
      cal.set(Calendar.DAY_OF_MONTH, day);
      cal.set(Calendar.HOUR_OF_DAY, hour);
      cal.set(Calendar.MINUTE, minute);
      cal.set(Calendar.SECOND, second);
      tsValue = new Timestamp(cal.getTime().getTime());
      tsValue.setNanos(nanos);
    }
    return tsValue;
  }

  /**
   * Retrieves the current datetime value as a Date.
   *
   * @return the current datetime value as a  java.sql.Date
   */
  public Date toDate()
  {
    if (dateValue == null) {
      GregorianCalendar cal = new GregorianCalendar();
      cal.set(Calendar.YEAR, year);
      cal.set(Calendar.MONTH, month - 1);
      cal.set(Calendar.DAY_OF_MONTH, day);
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 0);
      cal.set(Calendar.MILLISECOND, 0);
      dateValue = new Date(cal.getTime().getTime());
    }
    return dateValue;
  }

  /**
   * Retrieves the current datetime value as a Time.
   *
   * @return the current datetime value as a  java.sql.Time
   */
  public Time toTime()
  {
    if (timeValue == null) {
      GregorianCalendar cal = new GregorianCalendar();
      cal.set(Calendar.YEAR, 1970);
      cal.set(Calendar.MONTH, 0);
      cal.set(Calendar.DAY_OF_MONTH, 1);
      cal.set(Calendar.HOUR_OF_DAY, hour);
      cal.set(Calendar.MINUTE, minute);
      cal.set(Calendar.SECOND, second);
      cal.set(Calendar.MILLISECOND, 0); // Time doesn't have milliseconds.
      timeValue = new Time(cal.getTime().getTime());
    }
    return timeValue;
  }

  /**
   * Retrieves the current datetime value as a Time, Date or Timestamp.
   *
   * @return the current datetime value as an  java.lang.Object
   */
  public Object toObject()
  {
    if (date == DATE_NOT_USED) {
      return toTime();
    }
    if (time == TIME_NOT_USED) {
      return toDate();
    }
    return toTimestamp();
  }

  /**
   * Retrieves the current datetime value as a String.
   *
   * @return the current datetime value as a  String
   */
  @Override
  public String toString()
  {
    if (stringValue == null) {
      //
      // Make local copies to avoid corrupting unpacked
      // components.
      //
      int day = this.day;
      int month = this.month;
      int year = this.year;
      int nanos = this.nanos;
      int second = this.second;
      int minute = this.minute;
      int hour = this.hour;
      char buf[] = new char[29];
      int p = 0;
      if (date != DATE_NOT_USED) {
        p = 10;
        buf[--p] = (char) ('0' + day % 10);
        day /= 10;
        buf[--p] = (char) ('0' + day % 10);
        buf[--p] = '-';
        buf[--p] = (char) ('0' + month % 10);
        month /= 10;
        buf[--p] = (char) ('0' + month % 10);
        buf[--p] = '-';
        buf[--p] = (char) ('0' + year % 10);
        year /= 10;
        buf[--p] = (char) ('0' + year % 10);
        year /= 10;
        buf[--p] = (char) ('0' + year % 10);
        year /= 10;
        buf[--p] = (char) ('0' + year % 10);
        p += 10;
        if (time != TIME_NOT_USED) {
          buf[p++] = ' ';
        }
      }
      if (time != TIME_NOT_USED) {
        p += 18;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        nanos /= 10;
        buf[--p] = (char) ('0' + nanos % 10);
        buf[--p] = '.';
        buf[--p] = (char) ('0' + second % 10);
        second /= 10;
        buf[--p] = (char) ('0' + second % 10);
        buf[--p] = ':';
        buf[--p] = (char) ('0' + minute % 10);
        minute /= 10;
        buf[--p] = (char) ('0' + minute % 10);
        buf[--p] = ':';
        buf[--p] = (char) ('0' + hour % 10);
        hour /= 10;
        buf[--p] = (char) ('0' + hour % 10);
        p += 12;
        if (buf[p - 1] == '0') {
          p--;
        }
        if (buf[p - 1] == '0') {
          p--;
        }
      }
      stringValue = String.valueOf(buf, 0, p);
    }
    return stringValue;
  }
}
