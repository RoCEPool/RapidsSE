
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver;

import com.rapidsdata.sejdbcdriver.exceptions.JdbcDriverRuntimeException;
import com.rapidsdata.sejdbcdriver.sesupport.TypeHelper;
import org.slf4j.*;

import com.jcabi.aspects.Loggable;

import java.io.Closeable;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Implementation of the java.sql.DatabaseMetaData interface.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class JdbcDatabaseMetaData implements java.sql.DatabaseMetaData
{
  private static final String CATALOGS_FOLDER = "~/boray/catalogs";
  private static final String SCHEMAS_FOLDER  = "schemas";
  private static final String TABLES_FOLDER   = "tables";

  private final JdbcConnection connection;

  /**
   * The logger for this class.
   */
  private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(JdbcDatabaseMetaData.class.getName());


  /**
   * Boolean.TRUE    if identifiers are case sensitive (the server
   * was installed that way). Initially null, set the first time
   * any of the methods that check this are called.
   */
  Boolean caseSensitive;

  /**
   * Constructor.
   * @param connection
   */
  public JdbcDatabaseMetaData(JdbcConnection connection)
  {
    this.connection = connection;
  }

  //----------------------------------------------------------------------
  // First, a variety of minor information about the target database.

  /**
   * not supported
   */
  public boolean allProceduresAreCallable() throws SQLException
  {
    return false;
  }

  /**
   */
  public boolean allTablesAreSelectable() throws SQLException
  {
    return true;
  }

  /**
   * not supported
   *
   * @throws SQLException if a database-access error occurs.
   */
  public boolean dataDefinitionCausesTransactionCommit() throws SQLException
  {
    return false;
  }

  /**
   * not supported
   *
   * @throws SQLException if a database-access error occurs.
   */
  public boolean dataDefinitionIgnoredInTransactions() throws SQLException
  {
    return false;
  }

  /**
   * not supported
   *
   * @throws SQLException if a database-access error occurs.
   */
  public boolean doesMaxRowSizeIncludeBlobs() throws SQLException
  {
    return true;
  }

  /**
   * Get a description of a table's optimal set of columns that
   * uniquely identifies a row. They are ordered by SCOPE.
   *
   * @param catalog  a catalog name; "" retrieves those without a catalog;
   *                 null    means drop catalog name from the selection criteria
   * @param schema   a schema name; "" retrieves those without a schema
   * @param table    a table name
   * @param scope    the scope of interest; use same values as SCOPE
   * @param nullable include columns that are nullable?
   * @return ResultSet - each row is a column description
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.ResultSet getBestRowIdentifier(String catalog,
                                                 String schema,
                                                 String table,
                                                 int scope,
                                                 boolean nullable)
      throws SQLException
  {
    /*
    String colNames[] = {"SCOPE", "COLUMN_NAME",
        "DATA_TYPE", "TYPE_NAME",
        "COLUMN_SIZE", "BUFFER_LENGTH",
        "DECIMAL_DIGITS", "PSEUDO_COLUMN"};
    int colTypes[] = {Types.SMALLINT, Types.VARCHAR,
        Types.INTEGER, Types.VARCHAR,
        Types.INTEGER, Types.INTEGER,
        Types.SMALLINT, Types.SMALLINT};

    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
    */
    throw new SQLFeatureNotSupportedException("getBestRowIdentifier()");
  }

  /**
   * Get the catalog names available in this federation. The results are
   * ordered by catalog name.
   *
   * @return ResultSet - each row has a single String column
   * that is a catalog name
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.ResultSet getCatalogs() throws SQLException
  {
    String[] colNames = { "TABLE_CAT"    };
    int[]    colTypes = { Types.VARCHAR  };

    // Create the result set that we will return to the caller.
    CachedResultSet rs = new CachedResultSet((JdbcStatement) connection.createStatement(), colNames, colTypes);
    List<Object[]> rows = new ArrayList<>();

    try (DboIterator iterator = getCatalogIteratorFor(null)) {

      while (iterator.hasNext()) {
        String catalogName = (String) iterator.next()[0];
        String[] row = new String[colNames.length];
        row[0] = catalogName;

        rows.add(row);
      }

    } catch (IOException e) {
      if (e.getCause() != null && e.getCause() instanceof SQLException) {
        throw (SQLException) e.getCause();
      }

      if (rs != null) {
        rs.close();
      }

      throw new JdbcDriverRuntimeException(e);
    }

    // Sort the rows
    rows.sort( (Object[] row1, Object[] row2) -> {
      // Sort by:
      //    TABLE_CAT        (column index 0)
      final int[] compareColumnIndexes = { 0 };

      for (int index : compareColumnIndexes) {

        Object val1 = row1[index];
        Object val2 = row2[index];
        int comparison = compareValues(val1, val2);

        if (comparison != 0) {
          return comparison;
        }
      }

      // They must be equal.
      return 0;
    });

    // Add them to the resultset
    for (Object[] row : rows) {
      rs.addRow(row);
    }

    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /**
   * What's the separator between catalog and table name?
   *
   * @throws SQLException if a database-access error occurs.
   */
  public String getCatalogSeparator() throws SQLException
  {
    return ".";
  }

  /**
   * What's the database vendor's preferred term for "catalog"?
   *
   * @throws SQLException if a database-access error occurs.
   */
  public String getCatalogTerm() throws SQLException
  {
    return "CATALOG";
  }

  /**
   * Get a description of the access rights for a table's columns.
   * <p>
   * Only privileges matching the column name criteria are returned. They are
   * ordered by COLUMN_NAME and PRIVILEGE.
   *
   * @param catalog           a catalog name; "" retrieves those without a catalog;
   *                          null    means drop catalog name from the selection criteria
   * @param schema            a schema name; "" retrieves those without a schema
   *                          schema
   * @param table             a table name
   * @param columnNamePattern a column name pattern
   * @return ResultSet - each row is a column privilege description
   * @throws SQLException if a database-access error occurs.
   * @see #getSearchStringEscape
   */
  public java.sql.ResultSet getColumnPrivileges(String catalog,
                                                String schema,
                                                String table,
                                                String columnNamePattern)
      throws SQLException
  {
    //
    // Return an empty result set
    //
    /*
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
    */
    throw new SQLFeatureNotSupportedException();
  }


  /**
   * Get a description of the foreign key columns in the foreign key table
   * that reference the primary key columns of the primary key table
   * (describe how one table imports another's key). This should normally
   * return a single foreign key/primary key pair (most tables only import a
   * foreign key from a table once.) They are ordered by FKTABLE_CAT,
   * FKTABLE_SCHEM, FKTABLE_NAME, and KEY_SEQ.
   *
   * @param primaryCatalog a catalog name; "" retrieves those without a
   *                       null    means drop catalog name from the selection criteria
   * @param primarySchema  a schema name pattern; "" retrieves those without a schema
   * @param primaryTable   the table name that exports the key
   * @param foreignCatalog a catalog name; "" retrieves those without a
   *                       null    means drop catalog name from the selection criteria
   * @param foreignSchema  a schema name pattern; "" retrieves those without a schema
   * @param foreignTable   the table name that imports the key
   * @return ResultSet - each row is a foreign key column description
   * @throws SQLException if a database-access error occurs.
   * @see #getImportedKeys
   */
  public java.sql.ResultSet getCrossReference(String primaryCatalog,
                                              String primarySchema,
                                              String primaryTable,
                                              String foreignCatalog,
                                              String foreignSchema,
                                              String foreignTable)
      throws SQLException
  {
    /*
    String colNames[] = {"PKTABLE_CAT", "PKTABLE_SCHEM",
        "PKTABLE_NAME", "PKCOLUMN_NAME",
        "FKTABLE_CAT", "FKTABLE_SCHEM",
        "FKTABLE_NAME", "FKCOLUMN_NAME",
        "KEY_SEQ", "UPDATE_RULE",
        "DELETE_RULE", "FK_NAME",
        "PK_NAME", "DEFERRABILITY"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR,
        Types.SMALLINT, Types.SMALLINT,
        Types.SMALLINT, Types.VARCHAR,
        Types.VARCHAR, Types.SMALLINT};

    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);

    return rs;
    */
    throw new SQLFeatureNotSupportedException();
  }

  /**
   * Returns the name of this database product.
   *
   * @return database product name
   * @throws SQLException if a database-access error occurs.
   */
  public String getDatabaseProductName() throws SQLException
  {
    return "RapidsSE"; //connection.getDatabaseProductName();
  }

  /**
   * Returns the version of this database product.
   *
   * @return database version
   * @throws SQLException if a database-access error occurs.
   */
  public String getDatabaseProductVersion() throws SQLException
  {
    return connection.getDatabaseProductVersion();
  }

  //----------------------------------------------------------------------

  /**
   * Returns the database's default transaction isolation level. The values
   * are defined in java.sql.Connection.
   *
   * @return the default isolation level
   * @throws SQLException if a database-access error occurs.
   * @see Connection
   */
  public int getDefaultTransactionIsolation() throws SQLException
  {
    return Connection.TRANSACTION_NONE; //TRANSACTION_READ_COMMITTED;
  }

  /**
   * Returns this JDBC driver's major version number.
   *
   * @return JDBC driver major version
   */
  public int getDriverMajorVersion()
  {
    return Driver.MAJOR_VERSION;
  }

  /**
   * Returns this JDBC driver's minor version number.
   *
   * @return JDBC driver minor version number
   */
  public int getDriverMinorVersion()
  {
    return Driver.MINOR_VERSION;
  }

  /**
   * Returns the name of this JDBC driver.
   *
   * @return JDBC driver name
   * @throws SQLException if a database-access error occurs.
   */
  public String getDriverName() throws SQLException
  {
    return "RapidsSE JDBC";
  }

  /**
   * Returns the version of this JDBC driver.
   *
   * @return JDBC driver version
   * @throws SQLException if a database-access error occurs.
   */
  public String getDriverVersion() throws SQLException
  {
    return Driver.getVersion();
  }

  /**
   * Get a description of the foreign key columns that reference a table's
   * primary key columns (the foreign keys exported by a table). They are
   * ordered by FKTABLE_CAT, FKTABLE_SCHEM, FKTABLE_NAME, and KEY_SEQ.
   *
   * @param catalog a catalog name; "" retrieves those without a
   *                null    means drop catalog name from the selection criteria
   * @param schema  a schema name; "" retrieves those without a schema
   * @param table   a table name
   * @return ResultSet - each row is a foreign key column description
   * @throws SQLException if a database-access error occurs.
   * @see #getImportedKeys
   */
  public java.sql.ResultSet getExportedKeys(String catalog,
                                            String schema,
                                            String table)
      throws SQLException
  {
    //
    // Return an empty result set
    //
    /*
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
    */
    throw new SQLFeatureNotSupportedException();
  }

  /**
   * Get all the "extra" characters that can be used in unquoted identifier
   * names (those beyond a-z, A-Z, 0-9 and _).
   *
   * @return the string containing the extra characters
   * @throws SQLException if a database-access error occurs.
   */
  public String getExtraNameCharacters() throws SQLException
  {
    return "";
  }

  /**
   * Returns the string used to quote SQL identifiers. This returns a space "
   * " if identifier quoting isn't supported. A JDBC-Compliant driver always
   * uses a double quote character.
   *
   * @return the quoting string
   * @throws SQLException if a database-access error occurs.
   */
  public String getIdentifierQuoteString() throws SQLException
  {
    return "\"";
  }

  /**
   * Get a description of the primary key columns that are referenced by a
   * table's foreign key columns (the primary keys imported by a table). They
   * are ordered by PKTABLE_CAT, PKTABLE_SCHEM, PKTABLE_NAME, and KEY_SEQ.
   *
   * @param catalog a catalog name; "" retrieves those without a
   *                null    means drop catalog name from the selection criteria
   * @param schema  a schema name; "" retrieves those without a schema
   * @param table   a table name
   * @return ResultSet - each row is a primary key column description
   * @throws SQLException if a database-access error occurs.
   * @see #getExportedKeys
   */
  public java.sql.ResultSet getImportedKeys(String catalog,
                                            String schema,
                                            String table)
      throws SQLException
  {
    //return getCrossReference(null, null, null, catalog, schema, table);
    throw new SQLFeatureNotSupportedException();
  }

  /**
   * Get a description of a table's indices and statistics. They are ordered
   * by NON_UNIQUE, TYPE, INDEX_NAME, and ORDINAL_POSITION.
   *
   * @param catalog     a catalog name; "" retrieves those without a
   *                    null    means drop catalog name from the selection criteria
   * @param schema      a schema name; "" retrieves those without a schema
   * @param table       a table name
   * @param uniqueOnly      when  true   , return only indices for unique
   *                    values; when  false   , return indices regardless of
   *                    whether unique or not
   * @param approximate when  true   , result is allowed to reflect
   *                    approximate or out of data values; when  false   , results
   *                    are requested to be accurate
   * @return ResultSet - each row is an index column description
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.ResultSet getIndexInfo(String catalog,
                                         String schema,
                                         String table,
                                         boolean uniqueOnly,
                                         boolean approximate)
      throws SQLException
  {
    String[] columnNames = {
        /*01*/ "TABLE_CAT",
        /*02*/ "TABLE_SCHEM",
        /*03*/ "TABLE_NAME",
        /*04*/ "NON_UNIQUE",
        /*05*/ "INDEX_QUALIFIER",
        /*06*/ "INDEX_NAME",
        /*07*/ "TYPE",
        /*08*/ "ORDINAL_POSITION",
        /*09*/ "COLUMN_NAME",
        /*10*/ "ASC_OR_DESC",
        /*11*/ "CARDINALITY",
        /*12*/ "PAGES",
        /*13*/ "FILTER_CONDITION"
    };

    int[] columnTypes = {
        /*01 "TABLE_CAT",       */ Types.VARCHAR,
        /*02 "TABLE_SCHEM",     */ Types.VARCHAR,
        /*03 "TABLE_NAME",      */ Types.VARCHAR,
        /*04 "NON_UNIQUE",      */ Types.BOOLEAN,
        /*05 "INDEX_QUALIFIER", */ Types.VARCHAR,
        /*06 "INDEX_NAME",      */ Types.VARCHAR,
        /*07 "TYPE",            */ Types.SMALLINT,
        /*08 "ORDINAL_POSITION",*/ Types.SMALLINT,
        /*09 "COLUMN_NAME",     */ Types.VARCHAR,
        /*10 "ASC_OR_DESC",     */ Types.VARCHAR,
        /*11 "CARDINALITY",     */ Types.INTEGER,
        /*12 "PAGES",           */ Types.INTEGER,
        /*13 "FILTER_CONDITION" */ Types.VARCHAR
    };

    CachedResultSet rs = null;
    List<Object[]> rows = new ArrayList<>();

    try {

      try (DboIterator catalogIterator = getCatalogIteratorFor(catalog)) {

        // Create the result set that we will return to the caller.
        rs = new CachedResultSet((JdbcStatement) connection.createStatement(), columnNames, columnTypes);

        while (catalogIterator.hasNext()) {
          String catalogName = (String) catalogIterator.next()[0];

          // Create and auto-close the schemaIterator.
          try (DboIterator schemaIterator = getSchemaIteratorFor(catalogName, schema)) {

            while (schemaIterator.hasNext()) {
              String schemaName = (String) schemaIterator.next()[0];

              // Create and auto-close the schemaIterator.
              try (DboIterator tableIterator = getTableIteratorFor(schemaName, table)) {

                while (tableIterator.hasNext()) {
                  String tableName = (String) tableIterator.next()[0];

                  // Create and auto-close the indexIterator.
                  try (DboIterator indexIterator = getIndexIteratorFor(tableName)) {

                    while (indexIterator.hasNext()) {
                      String indexName = (String) indexIterator.next()[0];
                      boolean isUnique       = (boolean) indexIterator.next()[1];
                      //boolean isPrimaryKey   = (boolean) indexIterator.next()[2];

                      if (uniqueOnly && !isUnique) {
                        continue;
                      }

                      // Create and auto-close the indexIterator.
                      try (DboIterator indexColumnIterator = getIndexColumnIteratorFor(tableName, indexName)) {

                        int indexColumnOrdinal = 0;

                        while (indexColumnIterator.hasNext()) {
                          String indexColumnName = (String)  indexColumnIterator.next()[0];

                          ++indexColumnOrdinal;

                          Object[] row = new Object[columnNames.length];
                          int i = 0;
                          /*01 "TABLE_CAT",       */ row[i++] = catalogName;
                          /*02 "TABLE_SCHEM",     */ row[i++] = schemaName;
                          /*03 "TABLE_NAME",      */ row[i++] = tableName;
                          /*04 "NON_UNIQUE",      */ row[i++] = isUnique;
                          /*05 "INDEX_QUALIFIER", */ row[i++] = null;
                          /*06 "INDEX_NAME",      */ row[i++] = indexName;
                          /*07 "TYPE",            */ row[i++] = DatabaseMetaData.tableIndexOther;
                          /*08 "ORDINAL_POSITION",*/ row[i++] = indexColumnOrdinal;
                          /*09 "COLUMN_NAME",     */ row[i++] = indexColumnName;
                          /*10 "ASC_OR_DESC",     */ row[i++] = null;
                          /*11 "CARDINALITY",     */ row[i++] = 0;
                          /*12 "PAGES",           */ row[i++] = 0;
                          /*13 "FILTER_CONDITION" */ row[i++] = null;

                          rows.add(row);

                        } // while (indexIterator.hasNext())
                      } // try (indexColumnIterator)
                    } // while (indexIterator.hasNext())
                  } // try (indexIterator)
                } // while (tableIterator.hasNext())
              } // try (tableIterator)
            } // while (schemaIterator.hasNext())
          } // try (schemaIterator)
        } // while(catalogIterator.hasNext())
      } // try (catalogIterator)

    } catch (IOException e) {
      if (e.getCause() != null && e.getCause() instanceof SQLException) {
        throw (SQLException) e.getCause();
      }

      if (rs != null) {
        rs.close();
      }

      throw new JdbcDriverRuntimeException(e);
    }

    // Sort the rows
    rows.sort( (Object[] row1, Object[] row2) -> {
      // Sort by:
      //    NON_UNIQUE        (column index 3) then
      //    TYPE              (column index 6)       then
      //    INDEX_NAME        (column index 5) then
      //    ORDINAL_POSITION  (column index 7)
      final int[] compareColumnIndexes = { 3, 6, 5, 7 };

      for (int index : compareColumnIndexes) {

        Object val1 = row1[index];
        Object val2 = row2[index];
        int comparison = compareValues(val1, val2);

        if (comparison != 0) {
          return comparison;
        }
      }

      // They must be equal.
      return 0;
    });

    // Add them to the resultset
    for (Object[] row : rows) {
      rs.addRow(row);
    }

    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  //----------------------------------------------------------------------
  // The following group of methods exposes various limitations
  // based on the target database with the current driver.
  // Unless otherwise specified, a result of zero means there is no
  // limit, or the limit is not known.

  /**
   * How many hex characters can you have in an inline binary literal?
   *
   * @return max literal length
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxBinaryLiteralLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length of a catalog name?
   *
   * @return max name length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxCatalogNameLength() throws SQLException
  {
    return 0; //sysnameLength;
  }

  /**
   * What's the max length for a character literal?
   *
   * @return max literal length
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxCharLiteralLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the limit on column name length?
   *
   * @return max literal length
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxColumnNameLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum number of columns in a "GROUP BY" clause?
   *
   * @return max number of columns
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxColumnsInGroupBy() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum number of columns allowed in an index?
   *
   * @return max columns
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxColumnsInIndex() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum number of columns in an "ORDER BY" clause?
   *
   * @return max columns
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxColumnsInOrderBy() throws SQLException
  {
    //return 16;
    return 0;
  }

  /**
   * What's the maximum number of columns in a "SELECT" list?
   *
   * @return max columns
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxColumnsInSelect() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum number of columns in a table?
   *
   * @return max columns
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxColumnsInTable() throws SQLException
  {
    return 0;
  }

  /**
   * How many active connections can we have at a time to this database?
   *
   * @return max connections
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxConnections() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum cursor name length?
   *
   * @return max cursor name length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxCursorNameLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length of an index (in bytes)?
   *
   * @return max index length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxIndexLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length of a procedure name?
   *
   * @return max name length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxProcedureNameLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length of a single row?
   *
   * @return max row size in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxRowSize() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length allowed for a schema name?
   *
   * @return max name length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxSchemaNameLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length of a SQL statement?
   *
   * @return max length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxStatementLength() throws SQLException
  {
    return 0; // no limits
  }

  /**
   * How many active statements can we have open at one time to this
   * database?
   *
   * @return the maximum
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxStatements() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length of a table name?
   *
   * @return max name length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxTableNameLength() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum number of tables in a SELECT?
   *
   * @return the maximum
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxTablesInSelect() throws SQLException
  {
    return 0;
  }

  /**
   * What's the maximum length of a user name?
   *
   * @return max name length in bytes
   * @throws SQLException if a database-access error occurs.
   */
  public int getMaxUserNameLength() throws SQLException
  {
    return 0;
  }

  /**
   * Get a comma separated list of math functions.
   *
   * @return the list
   * @throws SQLException if a database-access error occurs.
   */
  public String getNumericFunctions() throws SQLException
  {
    return "";
    //return "abs,acos,asin,atan,atan2,ceiling,cos,cot,degrees,exp,floor,log,"
    //    + "log10,mod,pi,power,radians,rand,round,sign,sin,sqrt,tan";
  }

  /**
   * Get a description of a table's primary key columns. They are ordered by
   * COLUMN_NAME.
   *
   * @param catalog a catalog name; "" retrieves those without a
   *                null    means drop catalog name from the selection criteria
   * @param schema  a schema name; "" retrieves those without a schema
   * @param table   a table name
   * @return ResultSet - each row is a primary key column description
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.ResultSet getPrimaryKeys(String catalog,
                                           String schema,
                                           String table)
      throws SQLException
  {
    String[] columnNames = {
        /*01*/ "TABLE_CAT",
        /*02*/ "TABLE_SCHEM",
        /*03*/ "TABLE_NAME",
        /*04*/ "COLUMN_NAME",
        /*05*/ "KEY_SEQ",
        /*06*/ "PK_NAME"
    };

    int[] columnTypes = {
        /*01 "TABLE_CAT",   */ Types.VARCHAR,
        /*02 "TABLE_SCHEM"  */ Types.VARCHAR,
        /*03 "TABLE_NAME",  */ Types.VARCHAR,
        /*04 "COLUMN_NAME"  */ Types.VARCHAR,
        /*05 "KEY_SEQ",     */ Types.SMALLINT,
        /*06 "PK_NAME"      */ Types.VARCHAR
    };

    CachedResultSet rs = null;
    List<Object[]> rows = new ArrayList<>();

    try {

      try (DboIterator catalogIterator = getCatalogIteratorFor(catalog)) {

        // Create the result set that we will return to the caller.
        rs = new CachedResultSet((JdbcStatement) connection.createStatement(), columnNames, columnTypes);

        while (catalogIterator.hasNext()) {
          String catalogName = (String) catalogIterator.next()[0];

          // Create and auto-close the schemaIterator.
          try (DboIterator schemaIterator = getSchemaIteratorFor(catalogName, schema)) {

            while (schemaIterator.hasNext()) {
              String schemaName = (String) schemaIterator.next()[0];

              // Create and auto-close the schemaIterator.
              try (DboIterator tableIterator = getTableIteratorFor(schemaName, table)) {

                while (tableIterator.hasNext()) {
                  String tableName = (String) tableIterator.next()[0];

                  // Create and auto-close the indexIterator.
                  try (DboIterator indexIterator = getIndexIteratorFor(tableName)) {

                    while (indexIterator.hasNext()) {
                      String indexName = (String) indexIterator.next()[0];
                      //boolean isUnique       = (boolean) indexIterator.next()[1];
                      boolean isPrimaryKey   = (boolean) indexIterator.next()[2];

                      if (!isPrimaryKey) {
                        continue;
                      }

                      // Create and auto-close the indexIterator.
                      try (DboIterator indexColumnIterator = getIndexColumnIteratorFor(tableName, indexName)) {

                        int indexColumnOrdinal = 0;

                        while (indexColumnIterator.hasNext()) {
                          String indexColumnName = (String)  indexColumnIterator.next()[0];

                          ++indexColumnOrdinal;

                          Object[] row = new Object[columnNames.length];
                          int i = 0;
                          /*01 "TABLE_CAT",   */ row[i++] = catalogName;
                          /*02 "TABLE_SCHEM"  */ row[i++] = schemaName;
                          /*03 "TABLE_NAME",  */ row[i++] = tableName;
                          /*04 "COLUMN_NAME"  */ row[i++] = indexColumnName;
                          /*05 "KEY_SEQ",     */ row[i++] = indexColumnOrdinal;
                          /*06 "PK_NAME"      */ row[i++] = null;

                          rows.add(row);

                        } // while (indexIterator.hasNext())
                      } // try (indexColumnIterator)
                    } // while (indexIterator.hasNext())
                  } // try (indexIterator)
                } // while (tableIterator.hasNext())
              } // try (tableIterator)
            } // while (schemaIterator.hasNext())
          } // try (schemaIterator)
        } // while(catalogIterator.hasNext())
      } // try (catalogIterator)

    } catch (IOException e) {
      if (e.getCause() != null && e.getCause() instanceof SQLException) {
        throw (SQLException) e.getCause();
      }

      if (rs != null) {
        rs.close();
      }

      throw new JdbcDriverRuntimeException(e);
    }

    // Sort the rows
    rows.sort( (Object[] row1, Object[] row2) -> {
      // Sort by:
      //    COLUMN_NAME       (column index 3)
      final int[] compareColumnIndexes = { 3 };

      for (int index : compareColumnIndexes) {

        Object val1 = row1[index];
        Object val2 = row2[index];
        int comparison = compareValues(val1, val2);

        if (comparison != 0) {
          return comparison;
        }
      }

      // They must be equal.
      return 0;
    });

    // Add them to the resultset
    for (Object[] row : rows) {
      rs.addRow(row);
    }

    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /**
   * Get a description of a catalog's stored procedure parameters and result
   * columns.
   * <p>
   * Only descriptions matching the schema, procedure and parameter name
   * criteria are returned. They are ordered by PROCEDURE_SCHEM and
   * PROCEDURE_NAME. Within this, the return value, if any, is first. Next
   * are the parameter descriptions in call order. The column descriptions
   * follow in column number order.
   * <p>
   * <p>
   * Note:    Some databases may not return the column descriptions for a
   * procedure. Additional columns beyond REMARKS can be defined by the
   * database.
   *
   * @param catalog              a catalog name; "" retrieves those without a
   *                             null    means drop catalog name from the selection criteria
   * @param schemaPattern        a schema name pattern; "" retrieves those
   *                             without a schema
   * @param procedureNamePattern a procedure name pattern
   * @param columnNamePattern    a column name pattern
   * @return ResultSet - each row is a stored procedure parameter or column description
   * @throws SQLException if a database-access error occurs.
   * @see #getSearchStringEscape
   */
  public java.sql.ResultSet getProcedureColumns(String catalog,
                                                String schemaPattern,
                                                String procedureNamePattern,
                                                String columnNamePattern)
      throws SQLException
  {
    /*
    String colNames[] = {"PROCEDURE_CAT", "PROCEDURE_SCHEM",
        "PROCEDURE_NAME", "COLUMN_NAME",
        "COLUMN_TYPE", "DATA_TYPE",
        "TYPE_NAME", "PRECISION",
        "LENGTH", "SCALE",
        "RADIX", "NULLABLE",
        "REMARKS"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR,
        Types.SMALLINT, Types.INTEGER,
        Types.VARCHAR, Types.INTEGER,
        Types.INTEGER, Types.SMALLINT,
        Types.SMALLINT, Types.SMALLINT,
        Types.VARCHAR};

    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
    */
    throw new SQLFeatureNotSupportedException();
  }

  /**
   * Get a description of stored procedures available in a catalog.
   * <p>
   * Only procedure descriptions matching the schema and procedure name
   * criteria are returned. They are ordered by PROCEDURE_SCHEM, and
   * PROCEDURE_NAME.
   *
   * @param catalog              a catalog name; "" retrieves those without a
   *                             null    means drop catalog name from the selection criteria
   * @param schemaPattern        a schema name pattern; "" retrieves those
   *                             without a schema
   * @param procedureNamePattern a procedure name pattern
   * @return ResultSet - each row is a procedure description
   * @throws SQLException if a database-access error occurs.
   * @see #getSearchStringEscape
   */
  public java.sql.ResultSet getProcedures(String catalog,
                                          String schemaPattern,
                                          String procedureNamePattern)
      throws SQLException
  {
    /*
    String colNames[] = {"PROCEDURE_CAT", "PROCEDURE_SCHEM",
        "PROCEDURE_NAME", "RESERVED_1",
        "RESERVED_2", "RESERVED_3",
        "REMARKS", "PROCEDURE_TYPE"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.INTEGER,
        Types.INTEGER, Types.INTEGER,
        Types.VARCHAR, Types.SMALLINT};

    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
    */
    throw new SQLFeatureNotSupportedException();
  }

  /**
   * What's the database vendor's preferred term for "procedure"?
   *
   * @return the vendor term
   * @throws SQLException if a database-access error occurs.
   */
  public String getProcedureTerm() throws SQLException
  {
    //
    return "PROCEDURE";
  }


  /**
   * What's the database vendor's preferred term for "schema"?
   *
   * @return the vendor term
   * @throws SQLException if a database-access error occurs.
   */
  public String getSchemaTerm() throws SQLException
  {
    return "SCHEMA";
  }

  /**
   * This is the string that can be used to escape '_' or '%' in the string
   * pattern style catalog search parameters.
   * <p>
   * The '_' character represents any single character.
   * <p>
   * The '%' character represents any sequence of zero or more characters.
   *
   * @return the string used to escape wildcard characters
   * @throws SQLException if a database-access error occurs.
   */
  public String getSearchStringEscape() throws SQLException
  {
    // per "Programming ODBC for SQLServer" Appendix A
    return "\\";
  }

  /**
   * Get a comma separated list of all a database's SQL keywords that are NOT
   * also SQL92 keywords.
   *
   * @return the list
   * @throws SQLException if a database-access error occurs.
   */
  public String getSQLKeywords() throws SQLException
  {
    //
    // This is a superset of the SQL keywords , doesn't mean RDP supports
    // but since RDP sts on top of many DBS...
    //
    /*
    return "ARITH_OVERFLOW,BREAK,BROWSE,BULK,CHAR_CONVERT,CHECKPOINT,"
        + "CLUSTERED,COMPUTE,CONFIRM,CONTROLROW,DATA_PGS,DATABASE,DBCC,"
        + "DISK,DUMMY,DUMP,ENDTRAN,ERRLVL,ERRORDATA,ERROREXIT,EXIT,"
        + "FILLFACTOR,HOLDLOCK,IDENTITY_INSERT,IF,INDEX,KILL,LINENO,"
        + "LOAD,MAX_ROWS_PER_PAGE,MIRROR,MIRROREXIT,NOHOLDLOCK,NONCLUSTERED,"
        + "NUMERIC_TRUNCATION,OFF,OFFSETS,ONCE,ONLINE,OVER,PARTITION,PERM,"
        + "PERMANENT,PLAN,PRINT,PROC,PROCESSEXIT,RAISERROR,READ,READTEXT,"
        + "RECONFIGURE,REPLACE,RESERVED_PGS,RETURN,ROLE,ROWCNT,ROWCOUNT,"
        + "RULE,SAVE,SETUSER,SHARED,SHUTDOWN,SOME,STATISTICS,STRIPE,"
        + "SYB_IDENTITY,SYB_RESTREE,SYB_TERMINATE,TEMP,TEXTSIZE,TRAN,"
        + "TRIGGER,TRUNCATE,TSEQUAL,UNPARTITION,USE,USED_PGS,USER_OPTION,"
        + "WAITFOR,WHILE,WRITETEXT";
        */
    throw new SQLFeatureNotSupportedException();
  }

  /**
   * Get a comma separated list of string functions.
   *
   * @return the list
   * @throws SQLException if a database-access error occurs.
   */
  public String getStringFunctions() throws SQLException
  {

    //return "ascii,char,concat,difference,insert,lcase,left,length,locate,"
    //    + "ltrim,repeat,replace,right,rtrim,soundex,space,substring,ucase";
    return "";
  }

  /**
   * Get a comma separated list of system functions.
   *
   * @return the list
   * @throws SQLException if a database-access error occurs.
   */
  public String getSystemFunctions() throws SQLException
  {
    //return "database,ifnull,user,convert";
    return "";
  }

  /**
   * Get a description of the access rights for each table available in a
   * catalog. Note that a table privilege applies to one or more columns in
   * the table. It would be wrong to assume that this priviledge applies to
   * all columns (this may be true for some systems but is not true for all.)
   * <p>
   * <p>
   * Only privileges matching the schema and table name criteria are
   * returned. They are ordered by TABLE_SCHEM, TABLE_NAME, and PRIVILEGE.
   *
   * @param catalog          a catalog name; "" retrieves those without a
   *                         null    means drop catalog name from the selection criteria
   * @param schemaPattern    a schema name pattern; "" retrieves those
   *                         without a schema
   * @param tableNamePattern a table name pattern
   * @return ResultSet - each row is a table privilege description
   * @throws SQLException if a database-access error occurs.
   * @see #getSearchStringEscape
   */
  public java.sql.ResultSet getTablePrivileges(String catalog,
                                               String schemaPattern,
                                               String tableNamePattern)
      throws SQLException
  {


    String colNames[] = {"TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME",
                         "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                      Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};

    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;

  }

  /**
   * Get the schema names available in this database. The results are ordered
   * by schema name.
   *
   * @return a  ResultSet    object in which each row is a schema description
   * @throws SQLException if a database access error occurs
   */
  public java.sql.ResultSet getSchemas() throws SQLException
  {
    return getSchemas(null, null);
  }


  /**
   * Get a description of tables available in a catalog.
   * <p>
   * Only table descriptions matching the catalog, schema, table name and
   * type criteria are returned. They are ordered by TABLE_TYPE, TABLE_SCHEM
   * and TABLE_NAME.
   * <p>
   * <p>
   * Note:    Some databases may not return information for all tables.
   *
   * @param catalog          a catalog name; "" retrieves those without a
   *                         null    means drop catalog name from the selection criteria
   * @param schemaPattern    a schema name pattern; "" retrieves those
   *                         without a schema
   * @param tableNamePattern a table name pattern
   * @param types            a list of table types to include; null returns all types
   * @return ResultSet - each row is a table description
   * @throws SQLException if a database-access error occurs.
   * @see #getSearchStringEscape
   */
  public java.sql.ResultSet getTables(String catalog,
                                      String schemaPattern,
                                      String tableNamePattern,
                                      String types[])
      throws SQLException
  {
    String colNames[] = { "TABLE_CAT",
                          "TABLE_SCHEM",
                          "TABLE_NAME",
                          "TABLE_TYPE",
                          "REMARKS",
                          "TYPE_CAT",
                          "TYPE_SCHEM",
                          "TYPE_NAME",
                          "SELF_REFERENCING_COL_NAME",
                          "REF_GENERATION"};

    int colTypes[] =    { Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR,
                          Types.VARCHAR};


    CachedResultSet rs = null;
    List<Object[]> rows = new ArrayList<>();

    // If no "TABLE" table-type...
    if (types != null && Arrays.stream(types).noneMatch(p -> p.equals("TABLE"))) {
      // return an empty resultset.
      rs = new CachedResultSet((JdbcStatement) connection.createStatement(), colNames, colTypes);
      return rs;
    }

    try {

      try (DboIterator catalogIterator = getCatalogIteratorFor(catalog)) {

        // Create the result set that we will return to the caller.
        rs = new CachedResultSet((JdbcStatement) connection.createStatement(), colNames, colTypes);

        while (catalogIterator.hasNext()) {
          String catalogName = (String) catalogIterator.next()[0];

          // Create and auto-close the schemaIterator.
          try (DboIterator schemaIterator = getSchemaIteratorFor(catalogName, schemaPattern)) {

            while (schemaIterator.hasNext()) {
              String schemaName = (String) schemaIterator.next()[0];

              // Create and auto-close the schemaIterator.
              try (DboIterator tableIterator = getTableIteratorFor(schemaName, tableNamePattern)) {

                while (tableIterator.hasNext()) {
                  String tableName = (String) tableIterator.next()[0];

                  String[] row = new String[colNames.length];
                  int i = 0;
                  /*01 TABLE_CAT     */ row[i++] = catalogName;
                  /*02 TABLE_SCHEM   */ row[i++] = schemaName;
                  /*03 TABLE_NAME    */ row[i++] = tableName;
                  /*04 TABLE_TYPE    */ row[i++] = "TABLE";
                  /*05 REMARKS       */ row[i++] = "";
                  /*06 TYPE_CAT      */ row[i++] = null;
                  /*07 TYPE_SCHEM    */ row[i++] = null;
                  /*08 TYPE_NAME     */ row[i++] = null;
                  /*09 SELF_REF...   */ row[i++] = null;
                  /*10 REF_GENERATION*/ row[i++] = null;

                  rows.add(row);
                } // while (tableIterator.hasNext())
              } // try (tableIterator)
            } // while (schemaIterator.hasNext())
          } // try (schemaIterator)
        } // while(catalogIterator.hasNext())
      } // try (catalogIterator)

    } catch (IOException e) {
      if (e.getCause() != null && e.getCause() instanceof SQLException) {
        throw (SQLException) e.getCause();
      }

      if (rs != null) {
        rs.close();
      }

      throw new JdbcDriverRuntimeException(e);
    }

    // Sort the rows
    rows.sort( (Object[] row1, Object[] row2) -> {
      // Sort by:
      //    TABLE_TYPE        (column index 3) then
      //    TABLE_SCHEM       (column index 1)       then
      //    TABLE_NAME        (column index 2)
      final int[] compareColumnIndexes = { 3, 1, 2 };

      for (int index : compareColumnIndexes) {

        Object val1 = row1[index];
        Object val2 = row2[index];
        int comparison = compareValues(val1, val2);

        if (comparison != 0) {
          return comparison;
        }
      }

      // They must be equal.
      return 0;
    });

    // Add them to the resultset
    for (Object[] row : rows) {
      rs.addRow(row);
    }

    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  String doEscape(String src)
  {

    String escStr = "";

    if (src.contains("\\")) {
      escStr = String.format(" ESCAPE '%s'", "\\");
    }
    return escStr;
  }

  /**
   * Get a description of table columns available in a catalog.
   * <p>
   * Only column descriptions matching the catalog, schema, table and column
   * name criteria are returned. They are ordered by TABLE_SCHEM, TABLE_NAME
   * and ORDINAL_POSITION.
   *
   * @param catalog           a catalog name; "" retrieves those without a catalog;
   *                          null    means drop catalog name from the selection criteria
   * @param schemaPattern     a schema name pattern; "" retrieves those without a schema
   * @param tableNamePattern  a table name pattern
   * @param columnNamePattern a column name pattern
   * @return ResultSet - each row is a column description
   * @throws SQLException if a database-access error occurs.
   * @see #getSearchStringEscape
   */
  public java.sql.ResultSet getColumns(String catalog,
                                       String schemaPattern,
                                       String tableNamePattern,
                                       String columnNamePattern)
      throws SQLException
  {

    String columnNames[] = {"TABLE_CAT",         "TABLE_SCHEM",       "TABLE_NAME",
                            "COLUMN_NAME",       "DATA_TYPE",         "TYPE_NAME",
                            "COLUMN_SIZE",       "BUFFER_LENGTH",     "DECIMAL_DIGITS",
                            "NUM_PREC_RADIX",    "NULLABLE",          "REMARKS",
                            "COLUMN_DEF",        "SQL_DATA_TYPE",     "SQL_DATETIME_SUB",
                            "CHAR_OCTET_LENGTH", "ORDINAL_POSITION",  "IS_NULLABLE",
                            "SCOPE_CATALOG",     "SCOPE_SCHEMA",      "SCOPE_TABLE",
                            "SOURCE_DATA_TYPE",  "IS_AUTOINCREMENT",  "IS_GENERATEDCOLUMN"};

    int columnTypes[] = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                         Types.VARCHAR, Types.INTEGER, Types.VARCHAR,
                         Types.INTEGER, Types.INTEGER, Types.INTEGER,
                         Types.INTEGER, Types.INTEGER, Types.VARCHAR,
                         Types.VARCHAR, Types.INTEGER, Types.INTEGER,
                         Types.INTEGER, Types.INTEGER, Types.VARCHAR,
                         Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                         Types.SMALLINT, Types.VARCHAR, Types.VARCHAR};
    

    CachedResultSet rs = null;
    List<Object[]> rows = new ArrayList<>();

    try {

      try (DboIterator catalogIterator = getCatalogIteratorFor(catalog)) {

        // Create the result set that we will return to the caller.
        rs = new CachedResultSet((JdbcStatement) connection.createStatement(), columnNames, columnTypes);

        while (catalogIterator.hasNext()) {
          String catalogName = (String) catalogIterator.next()[0];

          // Create and auto-close the schemaIterator.
          try (DboIterator schemaIterator = getSchemaIteratorFor(catalogName, schemaPattern)) {

            while (schemaIterator.hasNext()) {
              String schemaName = (String) schemaIterator.next()[0];

              // Create and auto-close the schemaIterator.
              try (DboIterator tableIterator = getTableIteratorFor(schemaName, tableNamePattern)) {

                while (tableIterator.hasNext()) {
                  String tableName = (String) tableIterator.next()[0];

                  // Create and auto-close the columnIterator.
                  try (DboIterator columnIterator = getColumnIteratorFor(tableName, columnNamePattern)) {

                    while (columnIterator.hasNext()) {
                      int i = 0;

                      String  columnName    = (String)  columnIterator.next()[i++];
                      String  seColTypeName = (String)  columnIterator.next()[i++];
                      long    ordinal       = (long)    columnIterator.next()[i++];
                      Long    precision     = (Long)    columnIterator.next()[i++];
                      Long    scale         = (Long)    columnIterator.next()[i++];
                      boolean nullable      = (boolean) columnIterator.next()[i++];
                      boolean isAutoInc     = (boolean) columnIterator.next()[i++];

                      int jdbcColumnType = TypeHelper.convertSeTypeStringToJdbcType(seColTypeName);

                      Object[] row = new Object[columnNames.length];
                      i = 0;

                      /*01 TABLE_CAT          */ row[i++] = catalogName;
                      /*02 TABLE_SCHEM        */ row[i++] = schemaName;
                      /*03 TABLE_NAME         */ row[i++] = tableName;
                      /*04 COLUMN_NAME        */ row[i++] = columnName;
                      /*05 DATA_TYPE          */ row[i++] = jdbcColumnType;
                      /*06 TYPE_NAME          */ row[i++] = seColTypeName;
                      /*07 COLUMN_SIZE        */ row[i++] = precision;
                      /*08 BUFFER_LENGTH      */ row[i++] = null;
                      /*09 DECIMAL_DIGITS     */ row[i++] = scale;
                      /*10 NUM_PREC_RADIX     */ row[i++] = 10;
                      /*11 NULLABLE           */ row[i++] = nullable;
                      /*12 REMARKS            */ row[i++] = null;
                      /*13 COLUMN_DEF         */ row[i++] = null;
                      /*14 SQL_DATA_TYPE      */ row[i++] = 0;
                      /*15 SQL_DATETIME_SUB   */ row[i++] = 0;
                      /*16 CHAR_OCTET_LENGTH  */ row[i++] = 0;
                      /*17 ORDINAL_POSITION   */ row[i++] = ordinal;
                      /*18 IS_NULLABLE        */ row[i++] = (nullable ? "YES" : "NO");
                      /*19 SCOPE_CATALOG      */ row[i++] = null;
                      /*20 SCOPE_SCHEMA       */ row[i++] = null;
                      /*21 SCOPE_TABLE        */ row[i++] = null;
                      /*22 SOURCE_DATA_TYPE   */ row[i++] = null;
                      /*23 IS_AUTOINCREMENT   */ row[i++] = (isAutoInc ? "YES" : "NO");
                      /*24 IS_GENERATEDCOLUMN */ row[i++] = "";

                      rows.add(row);

                    } // while (columnIterator.hasNext())
                  } // try (columnIterator)
                } // while (tableIterator.hasNext())
              } // try (tableIterator)
            } // while (schemaIterator.hasNext())
          } // try (schemaIterator)
        } // while(catalogIterator.hasNext())
      } // try (catalogIterator)

    } catch (IOException e) {
      if (e.getCause() != null && e.getCause() instanceof SQLException) {
        throw (SQLException) e.getCause();
      }

      if (rs != null) {
        rs.close();
      }

      throw new JdbcDriverRuntimeException(e);
    }

    // Sort the rows
    rows.sort( (Object[] row1, Object[] row2) -> {
      // Sort by:
      //    TABLE_SCHEM       (column index 1) then
      //    TABLE_NAME        (column index 2) then
      //    ORDINAL_POSITION  (column index 16)
      final int[] compareColumnIndexes = { 1, 2, 16 };

      for (int index : compareColumnIndexes) {

        Object val1 = row1[index];
        Object val2 = row2[index];
        int comparison = compareValues(val1, val2);

        if (comparison != 0) {
          return comparison;
        }
      }

      // They must be equal.
      return 0;
    });

    // Add them to the resultset
    for (Object[] row : rows) {
      rs.addRow(row);
    }

    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /**
   * Get the table types available in this database. The results are ordered
   * by table type.
   *
   * @return ResultSet - each row has a single String column that is a table type
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.ResultSet getTableTypes() throws SQLException
  {
    String columnNames[] = {"TABLE_TYPE"};
    int    columnTypes[] = {Types.VARCHAR};

    CachedResultSet rs = new CachedResultSet((JdbcStatement) connection.createStatement(), columnNames, columnTypes);
    rs.addRow(new String[] {"TABLE"});
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /**
   * Get a comma separated list of time and date functions.
   *
   * @return the list
   * @throws SQLException if a database-access error occurs.
   */
  public String getTimeDateFunctions() throws SQLException
  {
    return "";
    /*
    return "curdate,curtime,dayname,dayofmonth,dayofweek,dayofyear,hour,"
        + "minute,month,monthname,now,quarter,timestampadd,timestampdiff,"
        + "second,week,year";
        */
  }

  /**
   * Get a description of all the standard SQL types supported by this
   * database. They are ordered by DATA_TYPE and then by how closely the data
   * type maps to the corresponding JDBC SQL type.
   *
   * Each type description has the following columns:
   * <OL>
   *   <LI> <B>TYPE_NAME</B> String =>Type name
   *   <LI> <B>DATA_TYPE</B> short =>SQL data type from java.sql.Types
   *   <LI> <B>PRECISION</B> int =>maximum precision
   *   <LI> <B>LITERAL_PREFIX</B> String =>prefix used to quote a literal
   *   (may be null)
   *   <LI> <B>LITERAL_SUFFIX</B> String =>suffix used to quote a literal
   *   (may be null)
   *   <LI> <B>CREATE_PARAMS</B> String =>parameters used in creating the
   *   type (may be null)
   *   <LI> <B>NULLABLE</B> short =>can you use NULL for this type?
   *   <UL>
   *     <LI> typeNoNulls - does not allow NULL values
   *     <LI> typeNullable - allows NULL values
   *     <LI> typeNullableUnknown - nullability unknown
   *   </UL>
   *
   *   <LI> <B>CASE_SENSITIVE</B> boolean=>is it case sensitive?
   *   <LI> <B>SEARCHABLE</B> short =>can you use "WHERE" based on this type:
   *
   *   <UL>
   *     <LI> typePredNone - No support
   *     <LI> typePredChar - Only supported with WHERE .. LIKE
   *     <LI> typePredBasic - Supported except for WHERE .. LIKE
   *     <LI> typeSearchable - Supported for all WHERE ..
   *   </UL>
   *
   *   <LI> <B>UNSIGNED_ATTRIBUTE</B> boolean =>is it unsigned?
   *   <LI> <B>FIXED_PREC_SCALE</B> boolean =>can it be a money value?
   *   <LI> <B>AUTO_INCREMENT</B> boolean =>can it be used for an
   *   auto-increment value?
   *   <LI> <B>LOCAL_TYPE_NAME</B> String =>localized version of type name
   *   (may be null)
   *   <LI> <B>MINIMUM_SCALE</B> short =>minimum scale supported
   *   <LI> <B>MAXIMUM_SCALE</B> short =>maximum scale supported
   *   <LI> <B>SQL_DATA_TYPE</B> int =>unused
   *   <LI> <B>SQL_DATETIME_SUB</B> int =>unused
   *   <LI> <B>NUM_PREC_RADIX</B> int =>usually 2 or 10
   * </OL>
   *
   * @return ResultSet - each row is a SQL type description
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.ResultSet getTypeInfo() throws SQLException
  {
    String colNames[] = {"TYPE_NAME", "DATA_TYPE", "PRECISION", "LITERAL_PREFIX", "LITERAL_SUFFIX", "CREATE_PARAMS",
        "NULLABLE","CASE_SENSITIVE","SEARCHABLE","UNSIGNED_ATTRIBUTE","FIXED_PREC_SCALE","AUTO_INCREMENT",
        "LOCAL_TYPE_NAME","MINIMUM_SCALE","MAXIMUM_SCALE","SQL_DATA_TYPE","SQL_DATETIME_SUB","NUM_PREC_RADIX"};

    int colTypes[] = {Types.VARCHAR, Types.INTEGER,
        Types.INTEGER, Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
        Types.SMALLINT, Types.BIT, Types.SMALLINT,
        Types.BIT,Types.BIT,Types.BIT,Types.VARCHAR,
        Types.SMALLINT,Types.SMALLINT,Types.INTEGER,Types.INTEGER,Types.INTEGER};
    //
    // Return an empty result set
    //

    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rsTmp = new CachedResultSet(dummyStmt, colNames, colTypes);

    int colCnt = 18;
    rsTmp.moveToInsertRow();

    //rsTmp.getObject(1);

    Object value;
    // Following MySQL to hard-code the values, long manual typing!!!

    final int columnCount = 18;
    Object[] row = new Object[columnCount];
    int colIndex = 0;
    
    /*01*/ row[colIndex++] = (Object)"BIT";
    /*02*/ row[colIndex++] = (Object)Integer.toString(java.sql.Types.BIT); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"1"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"false"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"BIT"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"BOOL";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.BOOLEAN); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"1"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"false"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"BOOL"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);


    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"SMALLINT";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.SMALLINT); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"16"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"[(M)] [UNSIGNED] [ZEROFILL]";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"true"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"true"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"SMALLINT"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"INTEGER";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.INTEGER); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"19"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"[(M)] [UNSIGNED] [ZEROFILL]";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"true"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"true"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"INTEGER"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"BIGINT";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.BIGINT); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"19"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"[(M)] [UNSIGNED] [ZEROFILL]";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"true"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"true"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"BIGINT"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"DOUBLE";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.DOUBLE); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"22"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"[(M,D)] [ZEROFILL]";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"true"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"DOUBLE"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"-38"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"38"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"FLOAT";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.FLOAT); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"22"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"[(M,D)] [ZEROFILL]";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullablellable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchablerchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"true"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"FLOAT"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"-38"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"38"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"DECIMAL";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.DECIMAL); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"22"; // Precision
    /*04*/ row[colIndex++] = (Object)"";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"[(M[,D])] [ZEROFILL]";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"true"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"DECIMAL"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"-38"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"38"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"VARCHAR";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.VARCHAR); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"65535"; // Precision
    /*04*/ row[colIndex++] = (Object)"'";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"'";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"(M)";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"false"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"VARCHAR"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"CHAR";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.CHAR); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"255"; // Precision
    /*04*/ row[colIndex++] = (Object)"'";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"'";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"(M)";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"false"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"CHAR"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"DATE";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.DATE); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"0"; // Precision
    /*04*/ row[colIndex++] = (Object)"'";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"'";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"false"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"DATE"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"TIME";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.TIME); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"0"; // Precision
    /*04*/ row[colIndex++] = (Object)"'";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"'";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"false"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"TIME"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    row = new Object[columnCount];
    colIndex = 0;
    /*01*/ row[colIndex++] = (Object)"TIMESTAMP";
    /*02*/ row[colIndex++] = (Object)Integer.toString(Types.TIMESTAMP); // JDBC Data type
    /*03*/ row[colIndex++] = (Object)"0"; // Precision
    /*04*/ row[colIndex++] = (Object)"'";  // Literal Prefix
    /*05*/ row[colIndex++] = (Object)"'";  // Literal Suffix
    /*06*/ row[colIndex++] = (Object)"";  // Create Params
    /*07*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeNullable);    // Nullable
    /*08*/ row[colIndex++] = (Object)"false"; // Case Sensitive
    /*09*/ row[colIndex++] = (Object)Integer.toString(java.sql.DatabaseMetaData.typeSearchable); // Searchable
    /*10*/ row[colIndex++] = (Object)"false"; // Unsignable
    /*11*/ row[colIndex++] = (Object)"false"; // Fixed Prec Scale
    /*12*/ row[colIndex++] = (Object)"false"; // Auto Increment
    /*13*/ row[colIndex++] = (Object)"TIMESTAMP"; // Locale Type Name
    /*14*/ row[colIndex++] = (Object)"0"; // Minimum Scale
    /*15*/ row[colIndex++] = (Object)"0"; // Maximum Scale
    /*16*/ row[colIndex++] = (Object)"0"; // SQL Data Type (not used)
    /*17*/ row[colIndex++] = (Object)"0"; // SQL DATETIME SUB (not used)
    /*18*/ row[colIndex++] = (Object)"10"; // NUM_PREC_RADIX (2 or 10)
    rsTmp.addRow(row);

    rsTmp.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rsTmp;
  }

  /**
   * Note:    If the driver does not support UDTs, an empty result set is
   * returned.
   *
   * @param catalog         a catalog name; "" retrieves those without a
   *                        null    means drop catalog name from the selection criteria
   * @param schemaPattern   a schema name pattern; "" retrieves those
   *                        without a schema
   * @param typeNamePattern a type name pattern; may be a fully-qualified
   *                        name
   * @param types           a list of user-named types to include
   *                        (JAVA_OBJECT, STRUCT, or DISTINCT); null returns all types
   * @return ResultSet - each row is a type description
   * @throws SQLException if a database access error occurs
   */
  public java.sql.ResultSet getUDTs(String catalog,
                                    String schemaPattern,
                                    String typeNamePattern,
                                    int[] types)
      throws SQLException
  {
    String colNames[] = {"TYPE_CAT",  "TYPE_SCHEM",
                         "TYPE_NAME", "CLASS_NAME",
                         "DATA_TYPE", "REMARKS",
                         "BASE_TYPE"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR,
                      Types.VARCHAR, Types.VARCHAR,
                      Types.INTEGER, Types.VARCHAR,
                      Types.SMALLINT};
    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /**
   * What's the URL for this database?
   *
   * @return the URL or null if it can't be generated
   * @throws SQLException if a database-access error occurs
   */
  public String getURL() throws SQLException
  {
    return connection.getURL();
  }

  /**
   * What's our user name as known to the database?
   *
   * @return our database user name
   * @throws SQLException if a database-access error occurs.
   */
  public String getUserName() throws SQLException
  {
    String result = null;

    return result;
  }

  /**
   * Get a description of a table's columns that are automatically updated
   * when any value in a row is updated. They are unordered.
   *
   * @param catalog a catalog name; "" retrieves those without a
   *                null    means drop catalog name from the selection criteria
   * @param schema  a schema name; "" retrieves those without a schema
   * @param table   a table name
   * @return ResultSet - each row is a column description
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.ResultSet getVersionColumns(String catalog,
                                              String schema,
                                              String table)
      throws SQLException
  {
    String colNames[] = {"SCOPE", "COLUMN_NAME", "DATA_TYPE",
        "TYPE_NAME", "COLUMN_SIZE",
        "BUFFER_LENGTH", "DECIMAL_DIGITS",
        "PSEUDO_COLUMN"};
    int colTypes[] = {Types.SMALLINT, Types.VARCHAR,
        Types.INTEGER, Types.VARCHAR,
        Types.INTEGER, Types.INTEGER,
        Types.SMALLINT, Types.SMALLINT};

    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /**
   * Retrieves whether a catalog appears at the start of a fully qualified
   * table name.  If not, the catalog appears at the end.
   *
   * @return true if it appears at the start
   * @throws SQLException if a database-access error occurs.
   */
  public boolean isCatalogAtStart() throws SQLException
  {
    return true;
  }

  /**
   * Is the database in read-only mode?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean isReadOnly() throws SQLException
  {
    return false;
  }

  /**
   * JDBC 2.0 Retrieves the connection that produced this metadata object.
   *
   * @return the connection that produced this metadata object
   * @throws SQLException if a database-access error occurs.
   */
  public java.sql.Connection getConnection() throws SQLException
  {
    return connection;
  }

  /**
   * Retrieves whether this database supports concatenations between
   * NULL and non- NULL values being NULL.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean nullPlusNonNullIsNull() throws SQLException
  {

    return true;
  }

  /**
   * Are NULL values sorted at the end regardless of sort order?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean nullsAreSortedAtEnd() throws SQLException
  {
    return false;
  }

  /**
   * Are NULL values sorted at the start regardless of sort order?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean nullsAreSortedAtStart() throws SQLException
  {
    return false;
  }

  /**
   * Are NULL values sorted high?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean nullsAreSortedHigh() throws SQLException
  {
    return true;
  }

  /**
   * Are NULL values sorted low?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean nullsAreSortedLow() throws SQLException
  {
    return true;
  }

  /**
   * Does the database treat mixed case unquoted SQL identifiers as case
   * insensitive and store them in lower case?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean storesLowerCaseIdentifiers() throws SQLException
  {
    return false;
  }

  /**
   * Does the database treat mixed case quoted SQL identifiers as case
   * insensitive and store them in lower case?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean storesLowerCaseQuotedIdentifiers() throws SQLException
  {
    return false;
  }

  /**
   * Does the database treat mixed case unquoted SQL identifiers as case
   * insensitive and store them in mixed case?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean storesMixedCaseIdentifiers() throws SQLException
  {
    //setCaseSensitiveFlag();

    return true; //!caseSensitive.booleanValue();
  }

  /**
   * Does the database treat mixed case quoted SQL identifiers as case
   * insensitive and store them in mixed case?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean storesMixedCaseQuotedIdentifiers() throws SQLException
  {
    //setCaseSensitiveFlag();

    //return !caseSensitive.booleanValue();
    return true;
  }

  /**
   * Does the database treat mixed case unquoted SQL identifiers as case
   * insensitive and store them in upper case?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean storesUpperCaseIdentifiers() throws SQLException
  {
    return false;
  }

  /**
   * Does the database treat mixed case quoted SQL identifiers as case
   * insensitive and store them in upper case?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean storesUpperCaseQuotedIdentifiers() throws SQLException
  {
    return false;
  }

  //--------------------------------------------------------------------
  // Functions describing which features are supported.

  /**
   * Is "ALTER TABLE" with add column supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsAlterTableWithAddColumn() throws SQLException
  {
    return false;
  }

  /**
   * Is "ALTER TABLE" with drop column supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsAlterTableWithDropColumn() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports the ANSI92 entry level SQL
   * grammar.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsANSI92EntryLevelSQL() throws SQLException
  {
    return false;
  }

  /**
   * Is the ANSI92 full SQL grammar supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsANSI92FullSQL() throws SQLException
  {
    return false;
  }

  /**
   * Is the ANSI92 intermediate SQL grammar supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsANSI92IntermediateSQL() throws SQLException
  {
    return false;
  }

  /**
   * Can a catalog name be used in a data manipulation statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsCatalogsInDataManipulation() throws SQLException
  {
    return false;
  }

  /**
   * Can a catalog name be used in an index definition statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsCatalogsInIndexDefinitions() throws SQLException
  {
    return false;
  }

  /**
   * Can a catalog name be used in a privilege definition statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLException
  {
    return false;
  }

  /**
   * Can a catalog name be used in a procedure call statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsCatalogsInProcedureCalls() throws SQLException
  {
    return false;
  }

  /**
   * Can a catalog name be used in a table definition statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsCatalogsInTableDefinitions() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports column aliasing.
   * <p>
   * If so, the SQL AS clause can be used to provide names for computed
   * columns or to provide alias names for columns as required. A
   * JDBC-Compliant driver always returns true.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsColumnAliasing() throws SQLException
  {
    return false;
  }

  /**
   * Is the CONVERT function between SQL types supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsConvert() throws SQLException
  {
    return false;
  }

  /**
   * Is CONVERT between the given SQL types supported?
   *
   * @param fromType the type to convert from
   * @param toType   the type to convert to
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsConvert(int fromType, int toType)
      throws SQLException
  {
    return false;
    /*
    if (fromType == toType) {
      return true;
    }

    switch (fromType) {
      // SAfe Most types will convert to anything but IMAGE and
      //      TEXT/NTEXT (and UNIQUEIDENTIFIER, but that's not a standard
      //      type).
      case Types.BIT:
      case Types.TINYINT:
      case Types.SMALLINT:
      case Types.INTEGER:
      case Types.BIGINT:
      case Types.FLOAT:
      case Types.REAL:
      case Types.DOUBLE:
      case Types.NUMERIC:
      case Types.DECIMAL:
      case Types.DATE:
      case Types.TIME:
      case Types.TIMESTAMP:
        return toType != Types.LONGVARCHAR && toType != Types.LONGVARBINARY
            && toType != Types.BLOB && toType != Types.CLOB;

      case Types.BINARY:
      case Types.VARBINARY:
        return toType != Types.FLOAT && toType != Types.REAL
            && toType != Types.DOUBLE;

      // IMAGE
      case Types.BLOB:
      case Types.LONGVARBINARY:
        return toType == Types.BINARY || toType == Types.VARBINARY
            || toType == Types.BLOB || toType == Types.LONGVARBINARY;

      // TEXT and NTEXT
      case Types.CLOB:
      case Types.LONGVARCHAR:
        return toType == Types.CHAR || toType == Types.VARCHAR
            || toType == Types.CLOB || toType == Types.LONGVARCHAR;

      // These types can be converted to anything
      case Types.NULL:
      case Types.CHAR:
      case Types.VARCHAR:
        return true;

      // We can't tell for sure what will happen with other types, so...
      case Types.OTHER:
      default:
        return false;
    }*/
  }

  /**
   * Is the ODBC Core SQL grammar supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsCoreSQLGrammar() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports correlated subqueries.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsCorrelatedSubqueries() throws SQLException
  {
    return false;
  }

  /**
   * Are both data definition and data manipulation statements within a
   * transaction supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsDataDefinitionAndDataManipulationTransactions()
      throws SQLException
  {

    return false;
  }

  /**
   * Are only data manipulation statements within a transaction supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsDataManipulationTransactionsOnly()
      throws SQLException
  {
    return false;
  }

  /**
   * If table correlation names are supported, are they restricted to be
   * different from the names of the tables?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsDifferentTableCorrelationNames() throws SQLException
  {
    return false;
  }

  /**
   * Are expressions in "ORDER BY" lists supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsExpressionsInOrderBy() throws SQLException
  {
    return false;
  }

  /**
   * Is the ODBC Extended SQL grammar supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsExtendedSQLGrammar() throws SQLException
  {
    return false;
  }

  /**
   * Are full nested outer joins supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsFullOuterJoins() throws SQLException
  {
    return false;
  }

  /**
   * Is some form of "GROUP BY" clause supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsGroupBy() throws SQLException
  {
    return false;
  }

  /**
   * Can a "GROUP BY" clause add columns not in the SELECT provided it
   * specifies all the columns in the SELECT?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsGroupByBeyondSelect() throws SQLException
  {
    // per "Programming ODBC for SQLServer" Appendix A
    return false;
  }

  /**
   * Can a "GROUP BY" clause use columns not in the SELECT?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsGroupByUnrelated() throws SQLException
  {
    return false;
  }

  /**
   * Is the SQL Integrity Enhancement Facility supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsIntegrityEnhancementFacility() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports specifying a  LIKE
   * escape clause.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsLikeEscapeClause() throws SQLException
  {
    // per "Programming ODBC for SQLServer" Appendix A
    return false;
  }

  /**
   * Retrieves whether this database provides limited support for outer
   * joins.  (This will be  true    if the method
   * supportsFullOuterJoins    returns  true   ).
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsLimitedOuterJoins() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports the ODBC Minimum SQL grammar.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsMinimumSQLGrammar() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database treats mixed case unquoted SQL identifiers as
   * case sensitive and as a result stores them in mixed case.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsMixedCaseIdentifiers() throws SQLException
  {
    //setCaseSensitiveFlag();

    return false; //caseSensitive.booleanValue();
  }

  /**
   * Retrieves whether this database treats mixed case quoted SQL identifiers as
   * case sensitive and as a result stores them in mixed case.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsMixedCaseQuotedIdentifiers() throws SQLException
  {
    //setCaseSensitiveFlag();

    return false; // caseSensitive.booleanValue();
  }

  /**
   * Are multiple ResultSets from a single execute supported?
   * Since this is not supported at this version 1.0.x we should return false.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsMultipleResultSets() throws SQLException
  {
    return false;
  }

  /**
   * Can we have multiple transactions open at once (on different
   * connections)?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsMultipleTransactions() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether columns in this database may be defined as non-nullable.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsNonNullableColumns() throws SQLException
  {
    return true;
  }

  /**
   * Can cursors remain open across commits?
   *
   * @return true    if cursors always remain open;
   * false    if they might not remain open
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsOpenCursorsAcrossCommit() throws SQLException
  {
    return false;
  }

  /**
   * Can cursors remain open across rollbacks?
   *
   * @return true    if cursors always remain open;
   * false    if they might not remain open
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsOpenCursorsAcrossRollback() throws SQLException
  {
    return false;
  }

  /**
   * Can statements remain open across commits?
   *
   * @return true    if statements always remain open;
   * false    if they might not remain open
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsOpenStatementsAcrossCommit() throws SQLException
  {
    return true;
  }

  /**
   * Can statements remain open across rollbacks?
   *
   * @return true    if statements always remain open;
   * false    if they might not remain open
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsOpenStatementsAcrossRollback() throws SQLException
  {
    return true;
  }

  /**
   * Can an "ORDER BY" clause use columns not in the SELECT?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsOrderByUnrelated() throws SQLException
  {
    return false;
  }

  /**
   * Is some form of outer join supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsOuterJoins() throws SQLException
  {
    return false;
  }

  /**
   * Is positioned DELETE supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsPositionedDelete() throws SQLException
  {
    return false;
  }

  /**
   * Is positioned UPDATE supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsPositionedUpdate() throws SQLException
  {
    return false;
  }

  /**
   * Can a schema name be used in a data manipulation statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSchemasInDataManipulation() throws SQLException
  {
    return false;
  }

  /**
   * Can a schema name be used in an index definition statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSchemasInIndexDefinitions() throws SQLException
  {
    return false;
  }

  /**
   * Can a schema name be used in a privilege definition statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSchemasInPrivilegeDefinitions() throws SQLException
  {
    return false;
  }

  /**
   * Can a schema name be used in a procedure call statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSchemasInProcedureCalls() throws SQLException
  {
    return false;
  }

  /**
   * Can a schema name be used in a table definition statement?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSchemasInTableDefinitions() throws SQLException
  {
    return false;
  }

  /**
   * Is SELECT for UPDATE supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSelectForUpdate() throws SQLException
  {
    // XXX Server supports it driver doesn't currently
    // As far as I know the SQL Server FOR UPDATE is not the same as the
    // standard SQL FOR UPDATE
    return false;
  }

  /**
   * Are stored procedure calls using the stored procedure escape syntax
   * supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsStoredProcedures() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports subqueries in comparison
   * expressions.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSubqueriesInComparisons() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports subqueries in
   * EXISTS    expressions.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSubqueriesInExists() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports subqueries in
   * IN    statements.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSubqueriesInIns() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports subqueries in quantified
   * expressions.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsSubqueriesInQuantifieds() throws SQLException
  {
    return false;
  }

  /**
   * Retrieves whether this database supports table correlation names.
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsTableCorrelationNames() throws SQLException
  {
    return false;
  }

  /**
   * Does the database support the given transaction isolation level?
   *
   * @param level the values are defined in java.sql.Connection
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   * @see Connection
   */
  public boolean supportsTransactionIsolationLevel(int level)
      throws SQLException
  {
    switch (level) {
      case Connection.TRANSACTION_READ_UNCOMMITTED:
      case Connection.TRANSACTION_READ_COMMITTED:
      case Connection.TRANSACTION_REPEATABLE_READ:
      case Connection.TRANSACTION_SERIALIZABLE:
        return false;

      // TRANSACTION_NONE not supported. It means there is no support for
      // transactions
      case Connection.TRANSACTION_NONE:
        return true;
      default:
        throw new SQLException("Bad value for supportsTransactionIsolationLevel(level)");
    }
  }

  /**
   * Retrieves whether this database supports transactions. If not, invoking the
   * method  commit    is a noop, and the isolation level is
   * TRANSACTION_NONE   .
   *
   * @return true    if transactions are supported
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsTransactions() throws SQLException
  {
    return false;
  }

  /**
   * Is SQL UNION supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsUnion() throws SQLException
  {
    return false;
  }

  /**
   * Is SQL UNION ALL supported?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean supportsUnionAll() throws SQLException
  {
    return false;
  }

  /**
   * Does the database use a file for each table?
   *
   * @return true    if the database uses a local file for each
   * table
   * @throws SQLException if a database-access error occurs.
   */
  public boolean usesLocalFilePerTable() throws SQLException
  {
    return false;
  }

  /**
   * Does the database store tables in a local file?
   *
   * @return true    if so
   * @throws SQLException if a database-access error occurs.
   */
  public boolean usesLocalFiles() throws SQLException
  {
    return false;
  }

  //--------------------------JDBC 2.0-----------------------------

  /**
   * Does the database support the given result set type?
   *
   * @param type defined in  java.sql.ResultSet
   * @return true    if so;  false    otherwise
   * @throws SQLException if a database access error occurs
   * @see Connection
   * @see #supportsResultSetConcurrency
   */
  public boolean supportsResultSetType(int type) throws SQLException
  {
    // RDP supports all standard ResultSet types plus
    // TYPE_SCROLL_SENSITIVE + 1
    //return type >= ResultSet.TYPE_FORWARD_ONLY
    //    && type <= ResultSet.TYPE_SCROLL_SENSITIVE + 1;

    return type == ResultSet.TYPE_SCROLL_INSENSITIVE;
  }

  /**
   * Does the database support the concurrency type in combination with the
   * given result set type?
   *
   * @param type        defined in  java.sql.ResultSet
   * @param concurrency type defined in  java.sql.ResultSet
   * @return true    if so;  false    otherwise
   * @throws SQLException if a database access error occurs
   * @see Connection
   * @see #supportsResultSetType
   */
  public boolean supportsResultSetConcurrency(int type, int concurrency)
      throws SQLException
  {
    if (type == ResultSet.TYPE_SCROLL_INSENSITIVE && concurrency == ResultSet.CONCUR_READ_ONLY) {
      return true;

    } else if ((type < ResultSet.TYPE_FORWARD_ONLY || type > ResultSet.TYPE_SCROLL_SENSITIVE)
        || (concurrency < ResultSet.CONCUR_READ_ONLY || concurrency > ResultSet.CONCUR_UPDATABLE)) {
      throw new SQLException("Invalid Type or Concurrency");

    } else {
      return false;
    }

  }

  /**
   * JDBC 2.0 Indicates whether a result set's own updates are visible.
   *
   * @param type ResultSet    type
   * @return true    if updates are visible for the
   * result set type;  false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean ownUpdatesAreVisible(int type) throws SQLException
  {
    if (type == ResultSet.TYPE_FORWARD_ONLY
        || type == ResultSet.TYPE_SCROLL_INSENSITIVE
        || type == ResultSet.TYPE_SCROLL_SENSITIVE) {
      return false;
    } else {
      if (type < ResultSet.TYPE_FORWARD_ONLY || type > ResultSet.CONCUR_UPDATABLE) {
        throw new SQLException("Bad value for ownUpdatesAreVisible(type)");
      }
    }
    return true;
  }

  /**
   * JDBC 2.0 Indicates whether a result set's own deletes are visible.
   *
   * @param type ResultSet    type
   * @return true    if deletes are visible for the
   * result set type;  false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean ownDeletesAreVisible(int type) throws SQLException
  {
    if (type == ResultSet.TYPE_FORWARD_ONLY
        || type == ResultSet.TYPE_SCROLL_INSENSITIVE
        || type == ResultSet.TYPE_SCROLL_SENSITIVE) {
      return false;
    } else {
      if (type < ResultSet.TYPE_FORWARD_ONLY || type > ResultSet.CONCUR_UPDATABLE) {
        throw new SQLException("Bad value for ownDeletesAreVisible(type)");
      }
    }
    return true;
  }

  /**
   * JDBC 2.0 Indicates whether a result set's own inserts are visible.
   *
   * @param type ResultSet    type
   * @return true    if inserts are visible for the
   * result set type;  false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean ownInsertsAreVisible(int type) throws SQLException
  {
    if (type == ResultSet.TYPE_FORWARD_ONLY
        || type == ResultSet.TYPE_SCROLL_INSENSITIVE
        || type == ResultSet.TYPE_SCROLL_SENSITIVE) {
      return false;
    } else {
      if (type < ResultSet.TYPE_FORWARD_ONLY || type > ResultSet.CONCUR_UPDATABLE) {
        throw new SQLException("Bad value for ownInsertsAreVisible(type)");
      }
    }
    return true;
  }

  /**
   * JDBC 2.0 Indicates whether updates made by others are visible.
   *
   * @param type ResultSet    type
   * @return true    if updates made by others are
   * visible for the result set type;  false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean othersUpdatesAreVisible(int type) throws SQLException
  {
    // Updates are visibile in scroll sensitive ResultSets
    //return type >= ResultSet.TYPE_SCROLL_SENSITIVE;
    if (type == ResultSet.TYPE_FORWARD_ONLY
        || type == ResultSet.TYPE_SCROLL_INSENSITIVE
        || type == ResultSet.TYPE_SCROLL_SENSITIVE) {
      return false;
    } else {
      if (type < ResultSet.TYPE_FORWARD_ONLY || type > ResultSet.CONCUR_UPDATABLE) {
        throw new SQLException("Bad value for othersUpdatesAreVisible(type)");
      }
    }
    return true;
  }

  /**
   * JDBC 2.0 Indicates whether deletes made by others are visible.
   *
   * @param type ResultSet    type
   * @return true    if deletes made by others are
   * visible for the result set type;  false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean othersDeletesAreVisible(int type) throws SQLException
  {
    // Deletes are visibile in scroll sensitive ResultSets
    if (type == ResultSet.TYPE_FORWARD_ONLY
        || type == ResultSet.TYPE_SCROLL_INSENSITIVE
        || type == ResultSet.TYPE_SCROLL_SENSITIVE) {
      return false;
    } else {
      if (type < ResultSet.TYPE_FORWARD_ONLY || type > ResultSet.CONCUR_UPDATABLE) {
        throw new SQLException("Bad value for othersDeletesAreVisible(type)");
      }
    }
    return true;
  }

  /**
   * JDBC 2.0 Indicates whether inserts made by others are visible.
   *
   * @param type ResultSet    type
   * @return true    if inserts made by others are visible
   * for the result set type;  false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean othersInsertsAreVisible(int type) throws SQLException
  {
    if (type == ResultSet.TYPE_FORWARD_ONLY
        || type == ResultSet.TYPE_SCROLL_INSENSITIVE
        || type == ResultSet.TYPE_SCROLL_SENSITIVE) {
      return false;
    }
    // Inserts are only visibile with dynamic cursors
    if (type != ResultSet.TYPE_FORWARD_ONLY
        && type != ResultSet.TYPE_SCROLL_INSENSITIVE
        && type != ResultSet.TYPE_SCROLL_SENSITIVE) {
      throw new SQLException("Bad result type");
    }
    return false;
  }

  /**
   * JDBC 2.0 Indicates whether or not a visible row update can be detected
   * by calling the method  ResultSet.rowUpdated    .
   *
   * @param type ResultSet    type
   * @return true    if changes are detected by the
   * result set type;  false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean updatesAreDetected(int type) throws SQLException
  {
    if (type != ResultSet.TYPE_FORWARD_ONLY
        && type != ResultSet.TYPE_SCROLL_SENSITIVE
        && type != ResultSet.TYPE_SCROLL_INSENSITIVE) {
      throw new SQLException("Bad result type");
    }
    return false;
  }

  /**
   * JDBC 2.0 Indicates whether or not a visible row delete can be detected
   * by calling ResultSet.rowDeleted(). If deletesAreDetected() returns
   * false, then deleted rows are removed from the result set.
   *
   * @param type ResultSet    type
   * @return true    if changes are detected by the result set type
   * @throws SQLException if a database access error occurs
   */
  public boolean deletesAreDetected(int type) throws SQLException
  {
    if (type == ResultSet.TYPE_FORWARD_ONLY
        || type == ResultSet.TYPE_SCROLL_INSENSITIVE
        || type == ResultSet.TYPE_SCROLL_SENSITIVE) {
      return false;
    } else {
      if (type < ResultSet.TYPE_FORWARD_ONLY || type > ResultSet.CONCUR_UPDATABLE) {
        throw new SQLException("Bad value for deletesAreDetected(type)");
      }
    }
    return true;
  }

  /**
   * JDBC 2.0 Indicates whether or not a visible row insert can be detected
   * by calling ResultSet.rowInserted().
   *
   * @param type ResultSet    type
   * @return true    if changes are detected by the result set type
   * @throws SQLException if a database access error occurs
   */
  public boolean insertsAreDetected(int type) throws SQLException
  {
    // Seems like there's no support for this
    return false;
  }

  /**
   * JDBC 2.0 Indicates whether the driver supports batch updates.
   *
   * @return true    if the driver supports batch updates;
   * false    otherwise
   * @throws SQLException if a database access error occurs
   */
  public boolean supportsBatchUpdates() throws SQLException
  {
    return false;
  }

  private void setCaseSensitiveFlag() throws SQLException
  {
    if (caseSensitive == null) {
      Statement s = connection.createStatement();
      ResultSet rs = s.executeQuery("REFRESH;"); // what would be the command ?

      rs.next();

      caseSensitive = "MIXED".equalsIgnoreCase(rs.getString(3)) ?
          Boolean.FALSE : Boolean.TRUE;
      s.close();
    }
  }

  public java.sql.ResultSet getAttributes(String catalog,
                                          String schemaPattern,
                                          String typeNamePattern,
                                          String attributeNamePattern)
      throws SQLException
  {
    String colNames[] = {"TYPE_CAT", "TYPE_SCHEM",
        "TYPE_NAME", "ATTR_NAME",
        "DATA_TYPE", "ATTR_TYPE_NAME",
        "ATTR_SIZE", "DECIMAL_DIGITS",
        "NUM_PREC_RADIX", "NULLABLE",
        "REMARKS", "ATTR_DEF",
        "SQL_DATA_TYPE", "SQL_DATETIME_SUB",
        "CHAR_OCTET_LENGTH", "ORDINAL_POSITION",
        "IS_NULLABLE", "SCOPE_CATALOG",
        "SCOPE_SCHEMA", "SCOPE_TABLE",
        "SOURCE_DATA_TYPE"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR,
        Types.INTEGER, Types.VARCHAR,
        Types.INTEGER, Types.INTEGER,
        Types.INTEGER, Types.INTEGER,
        Types.VARCHAR, Types.VARCHAR,
        Types.INTEGER, Types.INTEGER,
        Types.INTEGER, Types.INTEGER,
        Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR,
        Types.SMALLINT};
    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);

    return rs;
  }

  /**
   * Returns the database major version.
   */
  public int getDatabaseMajorVersion() throws SQLException
  {
    return connection.getDatabaseMajorVersion();
  }

  /**
   * Returns the database minor version.
   */
  public int getDatabaseMinorVersion() throws SQLException
  {
    return connection.getDatabaseMinorVersion();
  }

  /**
   * Returns the JDBC major version.
   */
  public int getJDBCMajorVersion() throws SQLException
  {
    return 4;
  }

  /**
   * Returns the JDBC minor version.
   */
  public int getJDBCMinorVersion() throws SQLException
  {
    return 2;
  }

  public int getResultSetHoldability() throws SQLException
  {
    return com.rapidsdata.sejdbcdriver.JdbcResultSet.HOLD_CURSORS_OVER_COMMIT;
  }

  public int getSQLStateType() throws SQLException
  {
    return DatabaseMetaData.sqlStateSQL;
  }

  public java.sql.ResultSet getSuperTables(String catalog,
                                           String schemaPattern,
                                           String tableNamePattern)
      throws SQLException
  {
    String colNames[] = {"TABLE_CAT", "TABLE_SCHEM",
        "TABLE_NAME", "SUPERTABLE_NAME"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR};
    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  public java.sql.ResultSet getSuperTypes(String catalog,
                                          String schemaPattern,
                                          String typeNamePattern)
      throws SQLException
  {
    String colNames[] = {"TYPE_CAT", "TYPE_SCHEM",
        "TYPE_NAME", "SUPERTYPE_CAT",
        "SUPERTYPE_SCHEM", "SUPERTYPE_NAME"};
    int colTypes[] = {Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR,
        Types.VARCHAR, Types.VARCHAR};
    //
    // Return an empty result set
    //
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /**
   * Returns  true    if updates are made to a copy of the LOB; returns
   * false    if LOB updates are made directly to the database.
   */
  public boolean locatorsUpdateCopy() throws SQLException
  {
    return true;
  }

  /**
   * Returns  true    if getting auto-generated keys is supported after a
   * statment is executed; returns  false    otherwise
   */
  public boolean supportsGetGeneratedKeys() throws SQLException
  {
    return false;
  }

  /**
   * Returns  true    if Callable statements can return multiple result sets;
   * returns  false    if they can only return one result set.
   */
  public boolean supportsMultipleOpenResults() throws SQLException
  {
    // Not yet supported. So return false here.
    return false;
  }

  /**
   * Returns  true    if the database supports named parameters;
   * returns  false    if the database does not support named parameters.
   */
  public boolean supportsNamedParameters() throws SQLException
  {
    return false;
  }

  public boolean supportsResultSetHoldability(int param) throws SQLException
  {
    // Not really sure about this one!
    if (param == ResultSet.HOLD_CURSORS_OVER_COMMIT)
      return true;
    else
      return false;
  }

  /**
   * Returns  true    if savepoints are supported; returns
   * false    otherwise
   */
  public boolean supportsSavepoints() throws SQLException
  {
    return false;
  }

  /**
   * Returns  true    if the database supports statement pooling;
   * returns  false    otherwise.
   */
  public boolean supportsStatementPooling() throws SQLException
  {
    return false;
  }

  /**
   * Format the supplied search pattern to transform the escape \x into [x].
   *
   * @param pattern the pattern to tranform
   * @return the transformed pattern as a  String
   */
  private static String processEscapes(String pattern)
  {
    final char escChar = '\\';

    if (pattern == null || pattern.indexOf(escChar) == -1) {
      return pattern;
    }

    int len = pattern.length();
    StringBuilder buf = new StringBuilder(len + 10);

    for (int i = 0; i < len; i++) {
      if (pattern.charAt(i) != escChar) {
        buf.append(pattern.charAt(i));
      } else if (i < len - 1) {
        buf.append('[');
        buf.append(pattern.charAt(++i));
        buf.append(']');
      } else {
        // Ignore final \
      }

    }

    return buf.toString();
  }

  /**
   * Uppercase all column names.
   * <p>
   * Sybase returns column names in lowecase while the JDBC standard suggests
   * they should be uppercase.
   *
   * @param results the result set to modify
   * @throws SQLException
   */
  private static void upperCaseColumnNames(JdbcResultSet results)
      throws SQLException
  {
    ResultSetMetaData rsmd = results.getMetaData();
    int cnt = rsmd.getColumnCount();

    for (int i = 1; i <= cnt; i++) {
      String name = rsmd.getColumnLabel(i);
      if (name != null && name.length() > 0) {
        results.setColLabel(i, name.toUpperCase());
      }
    }
  }

  private static CachedResultSet createTypeInfoResultSet(JdbcResultSet rs, boolean useLOBs) throws SQLException
  {
    CachedResultSet result = new CachedResultSet(rs, false);
    if (result.getMetaData().getColumnCount() > TypeInfo.NUM_COLS) {
      result.setVisibleColumnCount(TypeInfo.NUM_COLS);
    }
    result.setColLabel(3, "PRECISION");
    result.setColLabel(11, "FIXED_PREC_SCALE");
    upperCaseColumnNames(result);
    result.setConcurrency(ResultSet.CONCUR_UPDATABLE);
    result.moveToInsertRow();

    for (Iterator iter = getSortedTypes(rs, useLOBs).iterator(); iter.hasNext(); ) {
      TypeInfo ti = (TypeInfo) iter.next();
      ti.update(result);
      result.insertRow();
    }

    result.moveToCurrentRow();
    result.setConcurrency(ResultSet.CONCUR_READ_ONLY);

    return result;
  }

  private static Collection getSortedTypes(ResultSet rs, boolean useLOBs) throws SQLException
  {
    List types = new ArrayList(40);  // 40 should be enough capacity to hold all types

    while (rs.next()) {
      types.add(new TypeInfo(rs, useLOBs));
    }

    Collections.sort(types);

    return types;
  }

  /////// JDBC4 demarcation, do NOT put any JDBC3 code below this line ///////

  /* (non-Javadoc)
   * @see java.sql.DatabaseMetaData#autoCommitFailureClosesAllResultSets()
   */
  public boolean autoCommitFailureClosesAllResultSets() throws SQLException
  {
    return false;
  }

  /* (non-Javadoc)
   * @see java.sql.DatabaseMetaData#getClientInfoProperties()
   */
  public ResultSet getClientInfoProperties() throws SQLException
  {

    String colNames[] = {"NAME", "MAX_LEN",
        "DEFAULT_VALUE", "DESCRIPTION"};
    int colTypes[] = {Types.VARCHAR, Types.INTEGER,
        Types.INTEGER, Types.VARCHAR};
    JdbcStatement dummyStmt = (JdbcStatement) connection.createStatement();
    CachedResultSet rs = new CachedResultSet(dummyStmt, colNames, colTypes);
    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /* (non-Javadoc)
   * @see java.sql.DatabaseMetaData#getFunctionColumns(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
   */
  public ResultSet getFunctionColumns(String catalog, String schemaPattern,
                                      String functionNamePattern, String columnNamePattern)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException();
  }

  /* (non-Javadoc)
   * @see java.sql.DatabaseMetaData#getFunctions(java.lang.String, java.lang.String, java.lang.String)
   */
  public ResultSet getFunctions(String catalog, String schemaPattern,
                                String functionNamePattern) throws SQLException
  {

    throw new SQLFeatureNotSupportedException();
  }

  /* (non-Javadoc)
   * @see java.sql.DatabaseMetaData#getRowIdLifetime()
   */
  public RowIdLifetime getRowIdLifetime() throws SQLException
  {
    return RowIdLifetime.ROWID_UNSUPPORTED;
    //throw new SQLFeatureNotSupportedException();
  }

  /* (non-Javadoc)
   * @see java.sql.DatabaseMetaData#getSchemas(java.lang.String, java.lang.String)
   */
  public ResultSet getSchemas(String catalog, String schemaPattern)
      throws SQLException
  {
    final String[] colNames = { "TABLE_SCHEM", "TABLE_CATALOG" };
    final int[]    colTypes = { Types.VARCHAR, Types.VARCHAR   };

    CachedResultSet rs = null;
    List<Object[]> rows = new ArrayList<>();

    try (DboIterator catalogIterator = getCatalogIteratorFor(catalog)) {

      // Create the result set that we will return to the caller.
      rs = new CachedResultSet((JdbcStatement) connection.createStatement(), colNames, colTypes);

      while (catalogIterator.hasNext()) {

        String catalogName = (String) catalogIterator.next()[0];

        // Create and auto-close the schemaIterator.
        try (DboIterator schemaIterator = getSchemaIteratorFor(catalogName, schemaPattern)) {

          while (schemaIterator.hasNext()) {
            String schemaName = (String) schemaIterator.next()[0];
            String[] row = new String[colNames.length];
            row[0] = schemaName;
            row[1] = catalogName;

            rows.add(row);
          }
        } catch (IOException e) {
          if (e.getCause() != null && e.getCause() instanceof SQLException) {
            throw (SQLException) e.getCause();
          }

          throw new JdbcDriverRuntimeException(e);
        }
      }

    } catch (IOException e) {
      if (e.getCause() != null && e.getCause() instanceof SQLException) {
        throw (SQLException) e.getCause();
      }

      if (rs != null) {
        rs.close();
      }

      throw new JdbcDriverRuntimeException(e);
    }

    // Sort the rows
    rows.sort( (Object[] row1, Object[] row2) -> {
      // Sort by:
      //    TABLE_CATALOG     (column index 1) then
      //    TABLE_SCHEM       (column index 0)
      final int[] compareColumnIndexes = { 1, 0 };

      for (int index : compareColumnIndexes) {

        Object val1 = row1[index];
        Object val2 = row2[index];
        int comparison = compareValues(val1, val2);

        if (comparison != 0) {
          return comparison;
        }
      }

      // They must be equal.
      return 0;
    });

    // Add them to the resultset
    for (Object[] row : rows) {
      rs.addRow(row);
    }

    rs.setConcurrency(ResultSet.CONCUR_READ_ONLY);
    return rs;
  }

  /* (non-Javadoc)
   * @see java.sql.DatabaseMetaData#supportsStoredFunctionsUsingCallSyntax()
   */
  public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException
  {
    return false; //throw new AbstractMethodError();
  }

  /* (non-Javadoc)
   * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
   */
  public boolean isWrapperFor(Class arg0) throws SQLException
  {
    throw new AbstractMethodError();
  }

  /* (non-Javadoc)
   * @see java.sql.Wrapper#unwrap(java.lang.Class)
   */
  public Object unwrap(Class arg0) throws SQLException
  {
    throw new AbstractMethodError();
  }

  //// JDBC4.1 demarcation, do NOT put any JDBC3/4.0 code below this line ////

  @Override
  public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("getPsuedoColumns()");
  }

  @Override
  public boolean generatedKeyAlwaysReturned() throws SQLException
  {
    return false;
  }


  ////////////////////////////////////////////////////////////////////

  private String getCurrentWorkingFolder() throws SQLException
  {
    final String command = "pwf;";
    Statement statement = connection.createStatement();
    ResultSet rs = null;

    try {
      rs = statement.executeQuery(command);
      if (!rs.next()) {
        throw new SQLException("Command \"" + command + "\" didnt return any rows.");
      }

      String pwf = rs.getString("path");
      return pwf;

    } finally {
      if (rs != null) {
        rs.close();
      }

      statement.close();
    }
  }


  private void changeDirectoryTo(String path) throws SQLException
  {
    final String tenantsPrefix = "/tenants";

    if (path.startsWith(tenantsPrefix)) {
      path = "~" + path.substring(tenantsPrefix.length());
    }

    String[] folders = path.split("/");

    Statement statement = connection.createStatement();

    try {
      for (String folder : folders) {
        if (folder.isEmpty()) {
          continue;
        }

        String command = "cf " + folder + ";";
        statement.executeUpdate(command);
      }

    } finally {
      statement.close();
    }
  }

  private DboIterator getCatalogIteratorFor(String filter) throws SQLException
  {
    final String cwf = getCurrentWorkingFolder();

    final String command = "lscat;";
    final String columnName = "name";

    changeDirectoryTo(CATALOGS_FOLDER);

    JdbcStatement statement = (JdbcStatement) connection.createStatement();
    ResultSet rs = statement.executeQuery(command);

    String[] columnNames = { columnName };

    DboIterator iterator = new DboIterator(statement, rs, columnNames, filter, columnName, cwf);
    return iterator;
  }


  private DboIterator getSchemaIteratorFor(String catalog, String filter) throws SQLException
  {
    final String cwf = getCurrentWorkingFolder();

    final String command = "lssch;";
    final String columnName = "name";

    changeDirectoryTo(catalog + "/" + SCHEMAS_FOLDER);

    JdbcStatement statement = (JdbcStatement) connection.createStatement();
    ResultSet rs = statement.executeQuery(command);

    String[] columnNames = { columnName };

    DboIterator iterator = new DboIterator(statement, rs, columnNames, filter, columnName, cwf);
    return iterator;
  }


  private DboIterator getTableIteratorFor(String schema, String filter) throws SQLException
  {
    final String cwf = getCurrentWorkingFolder();

    final String command = "lstbl;";
    final String columnName = "name";

    if (!cwf.endsWith("/schemas/")) {
      throw new SQLException("not in the schemas folder.");
    }

    changeDirectoryTo(schema + "/" + TABLES_FOLDER);

    JdbcStatement statement = (JdbcStatement) connection.createStatement();
    ResultSet rs = statement.executeQuery(command);

    String[] columnNames = { columnName };

    DboIterator iterator = new DboIterator(statement, rs, columnNames, filter, columnName, cwf);
    return iterator;
  }


  private DboIterator getIndexIteratorFor(String table) throws SQLException
  {
    final String cwf = getCurrentWorkingFolder();

    final String command = "lsidx " + table + ";";
    final String columnNames[] = { "name", "isUnique", "isPrimaryKey" };

    if (!cwf.endsWith("/tables/")) {
      throw new SQLException("not in the tables folder.");
    }

    JdbcStatement statement = (JdbcStatement) connection.createStatement();
    ResultSet rs = statement.executeQuery(command);

    DboIterator iterator = new DboIterator(statement, rs, columnNames, null, null, cwf);
    return iterator;
  }


  private DboIterator getIndexColumnIteratorFor(String table, String index) throws SQLException
  {
    final String cwf = getCurrentWorkingFolder();

    final String command = "lsidxcol " + table + " " + index + ";";
    String[] columnNames = { "columnName", "columnType" };

    if (!cwf.endsWith("/tables/")) {
      throw new SQLException("not in the tables folder.");
    }

    JdbcStatement statement = (JdbcStatement) connection.createStatement();
    ResultSet rs = statement.executeQuery(command);

    DboIterator iterator = new DboIterator(statement, rs, columnNames, null, null, cwf);
    return iterator;
  }


  private DboIterator getColumnIteratorFor(String table, String columnPattern) throws SQLException
  {
    final String cwf = getCurrentWorkingFolder();

    final String command = "lscol " + table + ";";
    final String[] columnNames = { "columnName", "columnType", "ordinal", "precision", "scale", "nullable", "isAutoIncrement" };
    final String filterColumnName = "columnName";

    if (!cwf.endsWith("/tables/")) {
      throw new SQLException("not in the tables folder.");
    }

    JdbcStatement statement = (JdbcStatement) connection.createStatement();
    ResultSet rs = statement.executeQuery(command);

    DboIterator iterator = new DboIterator(statement, rs, columnNames, columnPattern, filterColumnName, cwf);
    return iterator;
  }


  /** A class for iterating catalogs, schemas, tables, etc. */
  private class DboIterator implements Iterator<Object[]>, Closeable
  {
    protected JdbcStatement statement;
    protected final ResultSet rs;
    protected final String[] columnNames;
    protected final Pattern regexFilter;
    protected final String filterColumnName; // the name of the column we are filtering
    protected final String originalCwf;

    public DboIterator(JdbcStatement statement, ResultSet rs, String[] columnNames,
                       String filter, String filterColumnName, String cwf)
    {
      this.statement = statement;
      this.rs = rs;
      this.columnNames = columnNames;

      if (filter != null && !filter.isEmpty()) {
        this.regexFilter = Pattern.compile(sqlSearchStringToRegex(filter));

      } else {
        this.regexFilter = null;
      }

      this.filterColumnName = filterColumnName;
      this.originalCwf = cwf;
    }

    /**
     * Converts a SQL search string (containing special characters like
     * '_' and '%' to a regex string.
     * @param filter
     * @return
     */
    private String sqlSearchStringToRegex(String filter)
    {
      StringBuilder sb = new StringBuilder(128);
      sb.append("^");

      boolean insideQuote = false;

      for (int i = 0; i < filter.length(); i++) {
        char c = filter.charAt(i);

        switch (c) {
          case '_':
            if (sb.length() > 0 && sb.charAt(sb.length() - 1) == '\\') {
              // The previous character is an escape character
              // so just treat this like any other regular character
              // but remove the escape character.
              sb.deleteCharAt(sb.length() - 1);
              sb.append(c);
              break;
            }

            if (insideQuote) {
              sb.append("\\E");
              insideQuote = false;
            }

            sb.append(".");
            break;

          case '%':
            if (sb.length() > 0 && sb.charAt(sb.length() - 1) == '\\') {
              // The previous character is an escape character
              // so just treat this like any other regular character
              // but remove the escape character.
              sb.deleteCharAt(sb.length() - 1);
              sb.append(c);
              break;
            }

            if (insideQuote) {
              sb.append("\\E");
              insideQuote = false;
            }

            sb.append(".*");
            break;

          default:
            if (!insideQuote) {
              sb.append("\\Q");
              insideQuote = true;
            }

            sb.append(c);
            break;
        }
      }

      if (insideQuote) {
        sb.append("\\E");
        insideQuote = false;
      }

      sb.append("$");
      return sb.toString();
    }

    /**
     * Returns {@code true} if the iteration has more elements.
     * (In other words, returns {@code true} if {@link #next} would
     * return an element rather than throwing an exception.)
     *
     * @return {@code true} if the iteration has more elements
     */
    @Override
    public boolean hasNext()
    {
      try {

        while (true) {
          boolean result = rs.next();

          if (!result) {
            return false;
          }

          // check if this next item matches the filter.
          if ( regexFilter == null ||
               regexFilter.matcher(rs.getString(filterColumnName)).matches() ) {
            break;
          }

          // otherwise keep looking at the next item.
        }

        return true;

      } catch (SQLException e) {
        throw new JdbcDriverRuntimeException(e);
      }
    }

    /**
     * Returns the next element in the iteration.
     *
     * @return the next element in the iteration
     * @throws NoSuchElementException if the iteration has no more elements
     */
    @Override
    public Object[] next()
    {
      try {
        if (rs.isAfterLast()) {
          throw new NoSuchElementException("No more objects to iterate.");
        }

        Object[] objects = new Object[columnNames.length];

        for (int i = 0; i < columnNames.length; i++) {
          objects[i] = rs.getObject(columnNames[i]);
        }

        return objects;

      } catch (SQLException e) {
        throw new JdbcDriverRuntimeException(e);
      }
    }

    /**
     * Closes this stream and releases any system resources associated
     * with it. If the stream is already closed then invoking this
     * method has no effect.
     * <p>
     * <p> As noted in {@link AutoCloseable#close()}, cases where the
     * close may fail require careful attention. It is strongly advised
     * to relinquish the underlying resources and to internally
     * <em>mark</em> the {@code Closeable} as closed, prior to throwing
     * the {@code IOException}.
     *
     * @throws IOException if an I/O error occurs
     */
    @Override
    public void close() throws IOException {
      try {
        if (rs != null) {
          rs.close();
        }
      } catch (SQLException e) { /*ignore*/ }

      try {
        if (statement != null) {
          statement.close();
        }
      } catch (SQLException e) { /*ignore*/ }

      try {
        changeDirectoryTo(originalCwf);

      } catch (SQLException e) {
        throw new IOException(e);
      }
    }
  }

  private int compareValues(Object val1, Object val2)
  {
    if (val1 == null) {
      return (val2 == null ? 0 : 1);
    }

    if (val2 == null) {
      // val1 cannot be null
      return -1;
    }

    if (!val1.getClass().equals(val2.getClass())) {
      final String msg = "Cannot compare two different data types.";
      throw new JdbcDriverRuntimeException(msg);
    }

    if (!(val1 instanceof Comparable)) {
      final String msg = "Uncomparable value type: " + val1.getClass().getName();
      throw new JdbcDriverRuntimeException(msg);
    }

    Comparable comparable1 = (Comparable) val1;
    Comparable comparable2 = (Comparable) val2;

    return comparable1.compareTo(comparable2);
  }
}
