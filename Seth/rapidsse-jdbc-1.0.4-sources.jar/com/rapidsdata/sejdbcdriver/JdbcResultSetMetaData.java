// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

import com.jcabi.aspects.Loggable;
import com.rapidsdata.sejdbcdriver.sesupport.TypeConversion;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 * SE implementation of the java.sql.ResultSetMetaData interface.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class JdbcResultSetMetaData implements ResultSetMetaData
{
  private final ColInfo[] columns;
  private final int columnCount;
  private final boolean useLOBs;

  /**
   * Construct ResultSetMetaData object over the current ColInfo array.
   *
   * @param columns     The current ColInfo row descriptor array.
   * @param columnCount The number of visible columns.
   */
  JdbcResultSetMetaData(ColInfo[] columns, int columnCount, boolean useLOBs)
  {
    this.columns = columns;
    this.columnCount = columnCount;
    this.useLOBs = useLOBs;
  }

  /**
   * Return the column descriptor given a column index.
   *
   * @param column The column index (from 1 .. n).
   * @return The column descriptor as a  ColInfo .
   * @throws SQLException
   */
  ColInfo getColumn(int column) throws SQLException
  {
    if (column < 1 || column > columnCount) {
      throw new SQLException(
          "error.resultset.colindex",
          "07009");
    }

    return columns[column - 1];
  }

// ------  java.sql.ResultSetMetaData methods follow -------

  public int getColumnCount() throws SQLException
  {
    return this.columnCount;
  }

  public int getColumnDisplaySize(int column) throws SQLException
  {
    return getColumn(column).displaySize;
  }

  public int getColumnType(int column) throws SQLException
  {
    if (useLOBs) {
      return getColumn(column).jdbcType;
    } else {
      return TypeConversion.convertLOBType(getColumn(column).jdbcType);
    }
  }

  public int getPrecision(int column) throws SQLException
  {
    return getColumn(column).precision;
  }

  public int getScale(int column) throws SQLException
  {
    return getColumn(column).scale;
  }

  public int isNullable(int column) throws SQLException
  {
    return getColumn(column).nullable;
  }

  public boolean isAutoIncrement(int column) throws SQLException
  {
    return getColumn(column).isIdentity;
  }

  public boolean isCaseSensitive(int column) throws SQLException
  {
    return getColumn(column).isCaseSensitive;
  }

  public boolean isCurrency(int column) throws SQLException
  {
    return false;
  }

  public boolean isDefinitelyWritable(int column) throws SQLException
  {
    getColumn(column);

    return false;
  }

  public boolean isReadOnly(int column) throws SQLException
  {
    return !getColumn(column).isWriteable;
  }

  public boolean isSearchable(int column) throws SQLException
  {
    return true;
  }

  public boolean isSigned(int column) throws SQLException
  {
    switch (getColumn(column).seType) {
      case INTEGER:   // falls through
      case DECIMAL:   // falls through
      case FLOAT:     // falls through
      case INTERVAL:
        return true;

      default:
        return false;
    }
  }

  public boolean isWritable(int column) throws SQLException
  {
    return getColumn(column).isWriteable;
  }

  public String getCatalogName(int column) throws SQLException
  {
    ColInfo col = getColumn(column);

    return (col.catalog == null) ? "" : col.catalog;
  }

  public String getColumnClassName(int column) throws SQLException
  {
    String c = getColumn(column).getClassName();

    if (!useLOBs) {
      if ("java.sql.Clob".equals(c)) {
        return "java.lang.String";
      }

      if ("java.sql.Blob".equals(c)) {
        return "[B";
      }
    }

    return c;
  }

  public String getColumnLabel(int column) throws SQLException
  {
    return getColumn(column).name;
  }

  public String getColumnName(int column) throws SQLException
  {
    return getColumn(column).name;
  }

  public String getColumnTypeName(int column) throws SQLException
  {
    return getColumn(column).sqlType;
  }

  public String getSchemaName(int column) throws SQLException
  {
    ColInfo col = getColumn(column);

    return (col.schema == null) ? "" : col.schema;
  }

  public String getTableName(int column) throws SQLException
  {
    ColInfo col = getColumn(column);

    return (col.tableName == null) ? "" : col.tableName;
  }


  /////// JDBC4 demarcation, do NOT put any JDBC3 code below this line ///////

  /* (non-Javadoc)
   * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
   */
  public boolean isWrapperFor(Class arg0) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

  /* (non-Javadoc)
   * @see java.sql.Wrapper#unwrap(java.lang.Class)
   */
  public Object unwrap(Class arg0) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

}