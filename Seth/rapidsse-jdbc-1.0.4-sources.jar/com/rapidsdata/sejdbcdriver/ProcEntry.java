// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

/**
 * Stores information about a cached stored procedure or statement handle.
 */
public class ProcEntry
{
  /**
   * The entry references a stored procedure.
   */
  public static final int PROCEDURE = 1;
  /**
   * The entry references a prepared statement handle.
   */
  public static final int PREPARE = 2;
  /**
   * The entry references a prepared cursor handle.
   */
  public static final int CURSOR = 3;
  /**
   * The entry references a failed prepare.
   */
  public static final int PREP_FAILED = 4;

  /**
   * Stored procedure name or statement handle.
   */
  private String name;
  /**
   * Column meta data (Sybase only).
   */
  private ColInfo[] colMetaData;
  /**
   * Parameter meta data (Sybase only).
   */
  private ParamInfo[] paramMetaData;
  /**
   * Type of statement referenced by this entry.
   */
  private int type;
  /**
   * Usage count for this statement.
   */
  private int refCount;

  /**
   * Retrieves the procedure or handle name.
   *
   * @return the statement or handle name as a  String
   */
  public final String toString()
  {
    return name;
  }

  /**
   * Sets the procedure name.
   *
   * @param name the procedure name
   */
  public void setName(String name)
  {
    this.name = name;
  }

  /**
   * Sets the prepared statement handle.
   *
   * @param handle the  sp_prepare    handle value
   */
  public void setHandle(int handle)
  {
    name = Integer.toString(handle);
  }

  /**
   * Retrieves the column meta data array.
   *
   * @return the column meta data as  ColInfo[]
   */
  public ColInfo[] getColMetaData()
  {
    return colMetaData;
  }

  /**
   * Sets the column meta data.
   *
   * @param colMetaData the column meta data
   */
  public void setColMetaData(ColInfo[] colMetaData)
  {
    this.colMetaData = colMetaData;
  }

  /**
   * Retrieves the parameter meta data array.
   *
   * @return the parameter meta data as a  ParamInfo[]
   */
  public ParamInfo[] getParamMetaData()
  {
    return paramMetaData;
  }

  /**
   * Sets the parameter meta data.
   *
   * @param paramMetaData the parameter meta data array
   */
  public void setParamMetaData(ParamInfo[] paramMetaData)
  {
    this.paramMetaData = paramMetaData;
  }

  /**
   * Sets the statement implementation type.
   *
   * @param type the type code (one of PROCEDURE,PREPARE,CURSOR)
   */
  public void setType(int type)
  {
    this.type = type;
  }

  /**
   * Retrieves the statement implementation type.
   *
   * @return the statement type as an  int
   */
  public int getType()
  {
    return type;
  }

  /**
   * Retrieves the SQL to drop this statement.
   */
  public void appendDropSQL(StringBuilder sql)
  {
    switch (type) {
      case PROCEDURE:
        sql.append("DROP PROC ").append(name).append('\n');
        break;
      case PREPARE:
        sql.append("EXEC sp_unprepare ").append(name).append('\n');
        break;
      case CURSOR:
        sql.append("EXEC sp_cursorunprepare ").append(name).append('\n');
        break;
      case PREP_FAILED:
        break;
      default:
        throw new IllegalStateException("Invalid cached statement type " + type);
    }
  }

  /**
   * Increments the usage count.
   */
  public void addRef()
  {
    refCount++;
  }

  /**
   * Decrements the usage count.
   */
  public void release()
  {
    if (refCount > 0) {
      refCount--;
    }
  }

  /**
   * Retreives the usage count.
   *
   * @return the usage count as an  int
   */
  public int getRefCount()
  {
    return refCount;
  }
}
