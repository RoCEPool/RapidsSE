
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

//
package com.rapidsdata.sejdbcdriver;

import com.jcabi.aspects.Loggable;

import java.sql.Savepoint;
import java.sql.SQLException;

/**
 * Savepoint implementation class.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
class SavepointImpl implements Savepoint
{
  private final int id;
  private final String name;

  /**
   * Constructs a savepoint with a specific identifier.
   *
   * @param id a savepoint identifier
   */
  SavepointImpl(int id)
  {
    this(id, null);
  }

  /**
   * Constructs a savepoint with a specific identifier and name.
   *
   * @param id   a savepoint identifier
   * @param name the savepoint name
   */
  SavepointImpl(int id, String name)
  {
    this.id = id;
    this.name = name;
  }

  public int getSavepointId() throws SQLException
  {
    if (name != null) {
      throw new SQLException("error.savepoint.named", "HY024");
    }

    return id;
  }

  public String getSavepointName() throws SQLException
  {
    if (name == null) {
      throw new SQLException("error.savepoint.unnamed", "HY024");
    }

    return name;
  }

  /**
   * Returns the savepoint id.  This will not throw an exception for
   * named savepoints as would {@link #getSavepointId}.
   *
   * @return the savepoint id
   */
  int getId()
  {
    return id;
  }
}

