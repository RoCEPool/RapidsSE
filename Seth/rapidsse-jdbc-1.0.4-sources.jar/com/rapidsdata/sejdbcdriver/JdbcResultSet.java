
// Copyright (c) 2016 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.sejdbcdriver;

import com.jcabi.aspects.Loggable;
import com.rapidsdata.sejdbcdriver.exceptions.JdbcDriverRuntimeException;
import com.rapidsdata.sejdbcdriver.exceptions.ResourceClosedException;
import com.rapidsdata.sejdbcdriver.sesupport.TypeConversion;
import com.rapidsdata.sejdbcdriver.sesupport.TypeHelper;
import com.rapidsdata.seshellapi.ColumnInfo;
import com.rapidsdata.seshellapi.DataType;
import com.rapidsdata.seshellapi.SEResult;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.sql.Date;
import java.text.NumberFormat;
import java.util.*;

/**
 * Implementation of the java.sql.ResultSet interface.
 * Originally this only supporting forward only result sets, however since
 * the SE Shell API returns complete results we can iterate forwards and backwards.
 * This makes it more or less indistinguishable from the CachedResultSet, however
 * They are kept separate because at a future point RapidsSE may have a different
 * interface that streams results and then this class would revert back to
 * being a forward, read-only result set that may need to request further rows
 * as they are being iterated.
 */
@Loggable(value = Loggable.TRACE, prepend = true) // Log usage of all public members.
public class JdbcResultSet implements ResultSet
{
  /*
   * Constants for backwards compatibility with JDK 1.3
   */
  static final int HOLD_CURSORS_OVER_COMMIT = 1;
  static final int CLOSE_CURSORS_AT_COMMIT = 2;

  protected static final int POS_BEFORE_FIRST = 0;
  protected static final int POS_AFTER_LAST = -1;

  /** Initial size for row array. */
  protected static final int INITIAL_ROW_COUNT = 1000;

  /** The current row number (1-based). */
  protected int pos = POS_BEFORE_FIRST;

  /** The number of rows in the result. */
  protected int rowsInResult;

  /** The result set type. One of FORWARD_ONLY, SCROLL_INSENSITIVE, SCROLL_SENSITIVE. */
  protected int resultSetType;

  /** The result set concurrency. One of CONCUR_READ_ONLY, CONCUR_UPDATE. */
  protected int concurrency;

  /** The array of column descriptors. */
  protected ColInfo[] columns;

  /** Number of *visible* columns in row. */
  protected int visibleColumnCount;

  /** The current result set row. */
  protected Object[] currentRow;

  /** Cached row data for forward only result set. */
  protected List<Object[]> rowData;

  /** Index of the current row in rowData (0-based). This is separate from pos
   * because it is possible that rowData is only a subset of the overall result
   * set yet to be retrieved from the server. */
  protected int rowPtr;

  /** True if last column retrieved was null. */
  protected boolean wasNull;

  /** The parent statement. */
  protected JdbcStatement statement;

  /** True if this result set is closed. */
  protected boolean closed;

  /** True if the query has been cancelled by another thread. */
  protected boolean cancelled;

  /** The fetch direction. */
  protected int fetchDirection = FETCH_FORWARD;

  /** The fetch size (only applies to cursor  ResultSet  code>s). */
  protected int fetchSize;

  /** The cursor name to be used for positioned updates. */
  protected String cursorName;

  /** Cache to speed up column name to column index lookups. */
  private Map<String,Integer> columnMap;

  /** Used to format numeric values when scale is specified. */
  private static NumberFormat f = NumberFormat.getInstance();

  /**
   * Construct a simple result set from a statement, metadata or generated keys.
   *
   * @param statement     The parent statement object or null.
   * @param resultSetType One of FORWARD_ONLY, SCROLL_INSENSITIVE, SCROLL_SENSITIVE.
   * @param concurrency   One of CONCUR_READ_ONLY, CONCUR_UPDATE.
   * @param seResult      The result object from RapidsSE.
   * @throws SQLException
   */
  public JdbcResultSet(JdbcStatement statement,
                       int resultSetType,
                       int concurrency,
                       SEResult seResult)
      throws SQLException
  {
    if (statement == null) {
      throw new IllegalArgumentException("Statement parameter must not be null");
    }

    if (seResult != null && seResult.getStatus() != SEResult.Status.HAS_RESULT_SET) {
      throw new IllegalArgumentException("seResult parameter must have a result set");
    }

    if (seResult != null && seResult.getRowMetadata() == null) {
      throw new IllegalArgumentException("seResult metadata cannot be null");
    }

    //this.pos            = POS_BEFORE_FIRST;
    this.rowsInResult   = (seResult == null ? 0 : seResult.getRows().size());
    this.resultSetType  = resultSetType;
    this.concurrency    = concurrency;
    this.columns        = (seResult == null ? null : convertSeColumnMetadata(seResult.getRowMetadata()));
    this.visibleColumnCount = getColumnCount(columns);
    this.currentRow     = null;
    this.rowData        = convertSeRowData(seResult);
    this.rowPtr         = -1;
    this.wasNull        = false;
    this.statement      = statement;
    this.closed         = false;
    this.cancelled      = false;
    this.fetchDirection = statement.fetchDirection;
    this.fetchSize      = statement.fetchSize;
    this.cursorName     = statement.cursorName;
    this.columnMap      = makeColumnMap();
  }

  /**
   * Converts the list of SE columns to an array of JDBC ColInfo objects.
   * @param seColumns the list of SE column objects
   * @return an array of ColInfo instances.
   */
  protected ColInfo[] convertSeColumnMetadata(List<ColumnInfo> seColumns)
  {
    if (seColumns == null) {
      return null;
    }

    ColInfo[] jdbcColumns = new ColInfo[seColumns.size()];

    int i = 0;

    for (ColumnInfo seCol : seColumns) {
      ColInfo jdbcCol = new ColInfo(seCol);

      jdbcColumns[i++] = jdbcCol;
    }

    return jdbcColumns;
  }

  /**
   * Converts the list of string arrays to a list of object arrays
   * where each object corresponds to the jdbcType of the metadata.
   * @param result
   * @return
   * @throws SQLException
   */
  protected List<Object[]> convertSeRowData(SEResult result) throws SQLException
  {
    if (result == null) {
      return null;
    }

    List<String[]> seRows = result.getRows();
    List<Object[]> rows = new ArrayList<>(seRows.size());

    for (String[] seRow : seRows) {
      Object[] row = new Object[seRow.length];
      rows.add(row);

      int colIndex = -1;
      ColInfo colInfo;

      assert(columns.length == seRow.length);

      for (String seVal : seRow) {
        ++colIndex;

        colInfo = columns[colIndex];
        DataType seType = result.getRowMetadata().get(colIndex).type;

        row[colIndex] = TypeConversion.convertSeTypeToObject(seVal, seType, colInfo.jdbcType, this);
      }
    }

    return rows;
  }

  /**
   * Returns a map so the column index (1-based) can be easily retrieved from the column name.
   * @return a map so the column index (1-based) can be easily retrieved from the column name.
   */
  private Map<String, Integer> makeColumnMap()
  {
    Map<String,Integer> map = new HashMap<>();

    if ( columns != null) {

      for (int i = 0; i < visibleColumnCount; i++) {
        map.put(columns[i].name.toUpperCase(), new Integer(i + 1));
      }
    }

    return map;
  }

  /**
   * Retrieve the column count excluding hidden columns
   *
   * @param columns The columns array
   * @return The new column count as an  int  .
   */
  protected static int getColumnCount(ColInfo[] columns)
  {
    if (columns == null) {
      return 0;
    }

    int i;
    for (i = columns.length - 1; i >= 0 && columns[i].isHidden; i--) ;
    return i + 1;
  }

  /**
   * Retrieve the column descriptor array.
   *
   * @return The column descriptors as a  ColInfo[]  .
   */
  protected ColInfo[] getColumns()
  {
    return columns;
  }

  /**
   * Set the specified column's name.
   *
   * @param colIndex The index of the column in the row.
   * @param name     The new name.
   */
  protected void setColName(int colIndex, String name)
  {
    if (colIndex < 1 || colIndex > columns.length) {
      throw new IllegalArgumentException("columnIndex "
          + colIndex + " invalid");
    }

    columns[colIndex - 1].realName = name;
  }

  /**
   * Set the specified column's label.
   *
   * @param colIndex The index of the column in the row.
   * @param name     The new label.
   */
  protected void setColLabel(int colIndex, String name)
  {
    if (colIndex < 1 || colIndex > columns.length) {
      throw new IllegalArgumentException("columnIndex "
          + colIndex + " invalid");
    }

    columns[colIndex - 1].name = name;
  }

  /**
   * Set the specified column's JDBC type.
   *
   * @param colIndex The index of the column in the row.
   * @param jdbcType The new type value.
   */
  protected void setColType(int colIndex, int jdbcType)
  {
    if (colIndex < 1 || colIndex > columns.length) {
      throw new IllegalArgumentException("columnIndex "
          + colIndex + " invalid");
    }

    columns[colIndex - 1].jdbcType = jdbcType;
  }

  /**
   * Set the specified column's data value.
   *
   * @param colIndex index of the column
   * @param value    new column value
   * @param length   the length of a stream parameter
   * @return the value, possibly converted to an internal type
   */
  protected Object setColValue(int colIndex, int jdbcType, Object value, int length)
      throws SQLException
  {
    checkOpen();
    notImplemented("setColValue(int colIndex, int jdbcType, Object value, int length)");
    checkUpdateable();
    if (colIndex < 1 || colIndex > visibleColumnCount) {
      throw new SQLException("col index error",
          "07009");
    }
    //
    // Convert java date/time objects to internal utilDateTime objects
    //
    if (value instanceof java.sql.Timestamp) {
      value = new utilDateTime((java.sql.Timestamp) value);

    } else if (value instanceof java.sql.Date) {
      value = new utilDateTime((java.sql.Date) value);

    } else if (value instanceof java.sql.Time) {
      value = new utilDateTime((java.sql.Time) value);
    }

    return value;
  }

  /**
   * Set the current row's column count.
   *
   * @param visibleColumnCount The number of visible columns in the row.
   */
  protected void setVisibleColumnCount(int visibleColumnCount)
  {
    if (visibleColumnCount < 1 || visibleColumnCount > columns.length) {
      throw new IllegalArgumentException("visibleColumnCount "
          + visibleColumnCount + " is invalid");
    }

    this.visibleColumnCount = visibleColumnCount;
  }

  /**
   * Get the specified column's data item.
   *
   * @param index the column index in the row
   * @return the column value as an  Object
   * @throws SQLException if the connection is closed;
   *                      if  index   is less than  1  ;
   *                      if  index   is greater that the number of columns;
   *                      if there is no current row
   */
  protected Object getColumn(int index) throws SQLException
  {
    checkOpen();

    if (index < 1 || index > visibleColumnCount) {
      throw new SQLException("col index error",
          "07009");
    }

    if (currentRow == null) {
      throw new SQLException("ResultSet cursor is not on a row.", "24000");
    }

    Object data = currentRow[index - 1];

    wasNull = data == null;

    return data;
  }

  /**
   * Check that this connection is still open.
   *
   * @throws SQLException if connection closed.
   */
  protected void checkOpen() throws SQLException
  {
    if (closed) {
      throw new ResourceClosedException("ResultSet object is closed.", "HY010");
    }

    if (cancelled) {
      throw new ResourceClosedException("cancelled", "HY010");
    }
  }

  /**
   * Check that this resultset is scrollable.
   *
   * @throws SQLException if connection closed.
   */
  protected void checkScrollable() throws SQLException
  {
    if (resultSetType == ResultSet.TYPE_FORWARD_ONLY) {
      throw new SQLException("error.resultset.fwdonly", "24000");
    }
  }

  /**
   * Check that this resultset is updateable.
   *
   * @throws SQLException if connection closed.
   */
  protected void checkUpdateable() throws SQLException
  {
    if (concurrency == ResultSet.CONCUR_READ_ONLY) {
      throw new SQLException("error.resultset.readonly", "24000");
    }
  }

  /**
   * Report that user tried to call a method which has not been implemented.
   *
   * @param method The method name to report in the error message.
   * @throws SQLException
   */
  protected static void notImplemented(String method) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("error.generic.notimp", "HYC00");
  }

  /**
   * Create a new row containing empty data items.
   *
   * @return the new row as an  Object   array
   */
  protected Object[] newRow()
  {
    Object row[] = new Object[columns.length];

    return row;
  }

  /**
   * Copy an existing result set row.
   *
   * @param row the result set row to copy
   * @return the new row as an  Object   array
   */
  protected Object[] copyRow(Object[] row)
  {
    Object copy[] = new Object[columns.length];

    System.arraycopy(row, 0, copy, 0, row.length);

    return copy;
  }

  /**
   * Copy an existing result set column descriptor array.
   *
   * @param info The result set column descriptors to copy.
   * @return The new descriptors as a  ColInfo[]  .
   */
  protected ColInfo[] copyInfo(ColInfo[] info)
  {
    ColInfo copy[] = new ColInfo[info.length];

    System.arraycopy(info, 0, copy, 0, info.length);

    return copy;
  }

  /**
   * Retrieve the current row data.
   *
   * @return The current row data as an  Object[]  .
   */
  protected Object[] getCurrentRow()
  {
    return currentRow;
  }

  /**
   * Cache the remaining results to free up connection.
   *
   * @throws SQLException
   */
  protected void cacheResultSetRows() throws SQLException
  {
    // The row data from SE is already materialised, so no need to cache anything.

    /*
    if (rowData == null) {
      rowData = new ArrayList(INITIAL_ROW_COUNT);
    }
    if (currentRow != null) {
      // Need to create local copy of currentRow
      // as this is currently a reference to the
      // row defined in RdpCore
      currentRow = copyRow(currentRow);
    }

    // Now load the remaining result set rows into memory
    while (statement.getRdp().getNextRow()) {
      rowData.add(copyRow(statement.getRdp().getRowData()));
    }
    */
  }

  /**
   * Returns the {@link JdbcConnection} object referenced by the
   * {@link #statement} instance variable.
   *
   * @return {@link JdbcConnection} object.
   * @throws SQLException on error.
   */
  private JdbcConnection getConnection() throws SQLException
  {
    return (JdbcConnection) statement.getConnection();
  }


  //
// -------------------- java.sql.ResultSet methods -------------------
//
  public int getConcurrency() throws SQLException
  {
    checkOpen();

    return concurrency;
  }

  public int getFetchDirection() throws SQLException
  {
    checkOpen();

    return fetchDirection;
  }

  public int getFetchSize() throws SQLException
  {
    checkOpen();

    return fetchSize;
  }

  public int getRow() throws SQLException
  {
    checkOpen();

    return pos > 0 ? pos : 0;
  }

  // returns:     ResultSet.TYPE_FORWARD_ONLY, ResultSet.TYPE_SCROLL_INSENSITIVE, or ResultSet.TYPE_SCROLL_SENSITIVE
  public int getType() throws SQLException
  {
    checkOpen();

    return resultSetType;
  }

  public void afterLast() throws SQLException
  {
    checkOpen();
    checkScrollable();

    rowPtr = rowData.size();
    pos = POS_AFTER_LAST;
  }

  public void beforeFirst() throws SQLException
  {
    checkOpen();
    checkScrollable();

    rowPtr = -1;
    pos = POS_BEFORE_FIRST;
  }

  public void cancelRowUpdates() throws SQLException
  {
    checkOpen();
    //checkUpdateable();
    throw new SQLFeatureNotSupportedException("cancelRowUpdates");
  }

  public void clearWarnings() throws SQLException
  {
    checkOpen();

    statement.clearWarnings();
  }

  /**
   * Retrieves whether this  ResultSet   object has been closed. A
   * ResultSet   is closed if the method close has been called on
   * it, or if it is automatically closed.
   *
   * @return true if this  ResultSet   object is closed; false if it is
   * still open
   */
  public boolean isClosed()
  {
    return closed;
  }

  public void close() throws SQLException
  {
    if (!closed) {
      try {
        if (!getConnection().isClosed()) {
          // Skip to end of result set and read all data from server,
          // otherwise, the TCP buffer still has data in it.
          while (next());
        }
      } finally {
        closed = true;

        if (statement != null &&
            statement.isCloseOnCompletion() &&
              (statement.openResultSets == null ||
                (statement.openResultSets != null &&
                 statement.openResultSets.size() <= 1)
              )
            ) {
          statement.close();
        }

        statement = null;
      }
    }
  }

  public void deleteRow() throws SQLException
  {
    checkOpen();
    checkUpdateable();
  }

  public void insertRow() throws SQLException
  {
    checkOpen();
    //checkUpdateable();
    throw new SQLFeatureNotSupportedException("insertRow()");
  }

  public void moveToCurrentRow() throws SQLException
  {
    checkOpen();
    //checkUpdateable();
    throw new SQLFeatureNotSupportedException("moveToCurrentRow");
  }


  public void moveToInsertRow() throws SQLException
  {
    checkOpen();
    //checkUpdateable();
    throw new SQLFeatureNotSupportedException("moveToInsertRow");
  }

  public void refreshRow() throws SQLException
  {
    checkOpen();
    checkUpdateable();
    throw new SQLFeatureNotSupportedException("refreshRow");
  }

  public void updateRow() throws SQLException
  {
    checkOpen();
    //checkUpdateable();
    throw new SQLFeatureNotSupportedException("updateRow()");
  }

  public boolean first() throws SQLException
  {
    checkOpen();
    checkScrollable();

    if (rowsInResult > 0) {
      rowPtr = 0;
      pos = 1;
      currentRow = rowData.get(rowPtr);
      return true;
    }

    currentRow = null;
    return false;
  }

  public boolean isAfterLast() throws SQLException
  {
    checkOpen();

    return (pos == POS_AFTER_LAST) && (rowsInResult != 0);
  }

  public boolean isBeforeFirst() throws SQLException
  {
    checkOpen();

    return (pos == POS_BEFORE_FIRST) && (rowsInResult != 0);
  }

  public boolean isFirst() throws SQLException
  {
    checkOpen();

    return pos == 1;
  }

  public boolean isLast() throws SQLException
  {
    checkOpen();

    return (pos == rowsInResult) && (rowsInResult != 0);
  }

  public boolean last() throws SQLException
  {
    checkOpen();
    checkScrollable();

    if (rowsInResult > 0) {
      rowPtr = rowsInResult - 1;
      pos = rowsInResult;
      currentRow = rowData.get(rowPtr);
      return true;
    }

    currentRow = null;
    return false;
  }

  public boolean next() throws SQLException
  {
    checkOpen();

    if (pos == POS_AFTER_LAST) {
      // Make sure nothing will happen after the end has been reached
      return false;
    }

    try {
      if (rowData != null) {

        // The rest of the result rows have been cached so
        // return the next row from the buffer.
        if (++rowPtr < rowData.size()) {

          currentRow = rowData.get(rowPtr);
          ++pos;

        } else {
          pos = POS_AFTER_LAST;
          currentRow = null;
        }
      } else {

        // Should never happen. Row data from SE is always materialised.
        throw new JdbcDriverRuntimeException("rowData is null.");

        /*
        // Need to read from server response
        if (!statement.getRdp().getNextRow()) {
          //System.out.println("ResultSet next() cacheResults");
          statement.cacheResults();
          pos = POS_AFTER_LAST;
          currentRow = null;
        } else {
          //System.out.println("ResultSet next() getRowData");
          currentRow = statement.getRdp().getRowData();
          pos++;
          rowsInResult = pos;
        }
        */
      }

      // Check for server side errors
      statement.getMessages().checkErrors();

    } catch (NullPointerException npe) {
      // ResultSet has been closed concurrently
      throw new SQLException("error.generic.closed",
          "HY010");
    }

    return currentRow != null;
  }

  public boolean previous() throws SQLException
  {
    checkOpen();
    checkScrollable();

    if (pos == POS_BEFORE_FIRST) {
      return false;
    }

    try {
      if (rowData != null) {

        // The rest of the result rows have been cached so
        // return the previous row from the buffer.
        if (--rowPtr >= 0) {

          currentRow = rowData.get(rowPtr);

          --pos;

        } else {
          pos = POS_BEFORE_FIRST;
          currentRow = null;
        }
      } else {

        // Should never happen. Row data from SE is always materialised.
        throw new JdbcDriverRuntimeException("rowData is null.");

        /*
        // Need to read from server response
        if (!statement.getRdp().getNextRow()) {
          //System.out.println("ResultSet next() cacheResults");
          statement.cacheResults();
          pos = POS_AFTER_LAST;
          currentRow = null;
        } else {
          //System.out.println("ResultSet next() getRowData");
          currentRow = statement.getRdp().getRowData();
          pos++;
          rowsInResult = pos;
        }
        */
      }

      // Check for server side errors
      statement.getMessages().checkErrors();

    } catch (NullPointerException npe) {
      // ResultSet has been closed concurrently
      throw new SQLException("error.generic.closed",
          "HY010");
    }

    return currentRow != null;
  }

  public boolean rowDeleted() throws SQLException
  {
    checkOpen();
    //checkUpdateable();

    //return false;
    throw new SQLFeatureNotSupportedException("rowDeleted() Not supported as version 1.0");
  }

  public boolean rowInserted() throws SQLException
  {
    checkOpen();
    //checkUpdateable();

    //return false;
    throw new SQLFeatureNotSupportedException("rowInserted() Not supported as version 1.0");
  }

  public boolean rowUpdated() throws SQLException
  {
    checkOpen();
    checkUpdateable();

    return false;
    //throw new SQLFeatureNotSupportedException("rowUpdated() Not supported as version 1.0");
  }

  public boolean wasNull() throws SQLException
  {
    checkOpen();

    return wasNull;
  }

  public byte getByte(int columnIndex) throws SQLException
  {
    return ((Integer) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.TINYINT, null)).byteValue();
  }

  public short getShort(int columnIndex) throws SQLException
  {
    return ((Integer) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.SMALLINT, null)).shortValue();
  }

  public int getInt(int columnIndex) throws SQLException
  {
    return ((Integer) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.INTEGER, null)).intValue();
  }

  public long getLong(int columnIndex) throws SQLException
  {
    return ((Long) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.BIGINT, null)).longValue();
  }

  public float getFloat(int columnIndex) throws SQLException
  {
    return ((Float) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.REAL, null)).floatValue();
  }

  public double getDouble(int columnIndex) throws SQLException
  {
    return ((Double) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.DOUBLE, null)).doubleValue();
  }

  public void setFetchDirection(int direction) throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("setFetchDirection()");

//    switch (direction) {
//      case FETCH_UNKNOWN:
//      case FETCH_REVERSE:
//        if (resultSetType == ResultSet.TYPE_FORWARD_ONLY) {
//          throw new SQLException("error.resultset.fwdonly", "24000");
//        }
//        // Fall through
//
//      case FETCH_FORWARD:
//        fetchDirection = direction;
//        break;
//
//      default:
//        throw new SQLException(
//            "error.generic.badoption",
//            "24000");
//    }
  }

  public void setFetchSize(int rows) throws SQLException
  {
    checkOpen();

    if (rows < 0 || (statement.getMaxRows() > 0 && rows > statement.getMaxRows())) {
      throw new SQLException(
          "error.generic.badparam",
          "HY092");
    }
    if (rows == 0) {
      rows = statement.getDefaultFetchSize();
    }
    fetchSize = rows;
  }

  public void updateNull(int columnIndex) throws SQLException
  {
    setColValue(columnIndex, Types.NULL, null, 0);
    //throw new SQLFeatureNotSupportedException("updateNull(int columnIndex)");
  }

  public boolean absolute(int rowNum) throws SQLException
  {
    checkOpen();
    checkScrollable();

    if (rowNum > rowData.size()) {
      rowPtr = rowData.size();
      pos = POS_AFTER_LAST;
      currentRow = null;
      return false;

    } else if (rowNum < -rowData.size()) {
      rowPtr = -1;
      pos = POS_BEFORE_FIRST;
      currentRow = null;
      return false;
    }

    if (rowNum > 0) {
      rowPtr = rowNum - 1;
      pos = rowNum;

    } else if (rowNum < 0) {
      rowPtr = rowData.size() + rowNum;
      pos = rowPtr + 1;

    } else {
      // Move to before the first row.
      rowPtr = -1;
      pos = POS_BEFORE_FIRST;
      currentRow = null;
      return false;
    }

    currentRow = rowData.get(rowPtr);
    return true;
  }

  public boolean getBoolean(int columnIndex) throws SQLException
  {
    return ((Boolean) TypeConversion.convert(this, getColumn(columnIndex), JdbcStatement.BOOLEAN, null)).booleanValue();
  }

  public boolean relative(int offset) throws SQLException
  {
    checkOpen();
    checkScrollable();

    if (rowPtr < 0 && offset <= 0) {
      // stay before the first row
      return false;

    } else if (rowPtr >= rowsInResult && offset >= 0) {
      // stay after the last row
      return false;
    }

    int rowNum = rowPtr + offset + 1;

    if (rowNum < 0) {
      rowPtr = -1;
      pos = POS_BEFORE_FIRST;
      currentRow = null;
      return false;
    }

    return absolute(rowNum);
  }

  public byte[] getBytes(int columnIndex) throws SQLException
  {
    checkOpen();
    return (byte[]) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.BINARY, getConnection().getCharset());
  }

  public void updateByte(int columnIndex, byte x) throws SQLException
  {
    setColValue(columnIndex, Types.INTEGER, new Integer(x & 0xFF), 0);
  }

  public void updateDouble(int columnIndex, double x) throws SQLException
  {
    setColValue(columnIndex, Types.DOUBLE, new Double(x), 0);
  }

  public void updateFloat(int columnIndex, float x) throws SQLException
  {
    setColValue(columnIndex, Types.REAL, new Float(x), 0);
  }

  public void updateInt(int columnIndex, int x) throws SQLException
  {
    setColValue(columnIndex, Types.INTEGER, new Integer(x), 0);
  }

  public void updateLong(int columnIndex, long x) throws SQLException
  {
    setColValue(columnIndex, Types.BIGINT, new Long(x), 0);
  }

  public void updateShort(int columnIndex, short x) throws SQLException
  {
    setColValue(columnIndex, Types.INTEGER, new Integer(x), 0);
  }

  public void updateBoolean(int columnIndex, boolean x) throws SQLException
  {
    setColValue(columnIndex, Types.BIT, x ? Boolean.TRUE : Boolean.FALSE, 0);
  }

  public void updateBytes(int columnIndex, byte[] x) throws SQLException
  {
    setColValue(columnIndex, Types.VARBINARY, x, (x != null) ? x.length : 0);
  }

  public InputStream getAsciiStream(int columnIndex) throws SQLException
  {
    Clob clob = getClob(columnIndex);

    if (clob == null) {
      return null;
    }

    return clob.getAsciiStream();
  }

  public InputStream getBinaryStream(int columnIndex) throws SQLException
  {
    Blob blob = getBlob(columnIndex);

    if (blob == null) {
      return null;
    }

    return blob.getBinaryStream();
  }

  public InputStream getUnicodeStream(int columnIndex) throws SQLException
  {
    /*
    RdpClobImpl clob = (RdpClobImpl) getClob(columnIndex);

    if (clob == null) {
      return null;
    }

    return clob.getBlobBuffer().getUnicodeStream();
    */
    throw new SQLFeatureNotSupportedException("getUnicodeStream(int columnIndex)");

  }

  public void updateAsciiStream(int columnIndex, InputStream inputStream, int length)
      throws SQLException
  {
    if (inputStream == null || length < 0) {
      updateCharacterStream(columnIndex, null, 0);
    } else {
      try {
        updateCharacterStream(columnIndex, new InputStreamReader(inputStream, "US-ASCII"), length);
      } catch (UnsupportedEncodingException e) {
        // Should never happen!
      }
    }
  }

  public void updateBinaryStream(int columnIndex, InputStream inputStream, int length)
      throws SQLException
  {

    if (inputStream == null || length < 0) {
      updateBytes(columnIndex, null);
      return;
    }

    setColValue(columnIndex, java.sql.Types.VARBINARY, inputStream, length);
  }

  public Reader getCharacterStream(int columnIndex) throws SQLException
  {
    Clob clob = getClob(columnIndex);

    if (clob == null) {
      return null;
    }

    return clob.getCharacterStream();
  }

  public void updateCharacterStream(int columnIndex, Reader reader, int length)
      throws SQLException
  {

    if (reader == null || length < 0) {
      updateString(columnIndex, null);
      return;
    }

    setColValue(columnIndex, java.sql.Types.VARCHAR, reader, length);
  }

  public Object getObject(int columnIndex) throws SQLException
  {
    Object value = getColumn(columnIndex);

    // Don't return utilDateTime objects as the user won't know how to
    // handle them
    if (value instanceof utilDateTime) {
      return ((utilDateTime) value).toObject();
    }
    // If the user requested String/byte[] instead of LOBs, do the conversion
    if (!getConnection().getUseLOBs()) {
      value = TypeConversion.convertLOB(value);
    }

    return value;
  }

  public void updateObject(int columnIndex, Object x) throws SQLException
  {
    checkOpen();

    int length = 0;
    int jdbcType = Types.VARCHAR; // Use for NULL values

    if (x != null) {
      // Need to do some conversion and testing here
      jdbcType = TypeHelper.getJdbcTypeFromObject(x);

      if (x instanceof BigDecimal) {
        int prec = getConnection().getMaxPrecision();
        x = TypeConversion.normalizeBigDecimal((BigDecimal) x, prec);

      } else if (x instanceof Blob) {
        Blob blob = (Blob) x;
        x = blob.getBinaryStream();
        length = (int) blob.length();

      } else if (x instanceof Clob) {
        Clob clob = (Clob) x;
        x = clob.getCharacterStream();
        length = (int) clob.length();

      } else if (x instanceof String) {
        length = ((String) x).length();

      } else if (x instanceof byte[]) {
        length = ((byte[]) x).length;
      }

      if (jdbcType == Types.JAVA_OBJECT) {
        // Unsupported class of object
        if (columnIndex < 1 || columnIndex > visibleColumnCount) {
          throw new SQLException("error.resultset.colindex", "07009");
        }

        ColInfo ci = columns[columnIndex - 1];
        throw new SQLException("error.convert.badtypes", "22005");
      }
    }

    setColValue(columnIndex, jdbcType, x, length);
  }

  public void updateObject(int columnIndex, Object x, int scale) throws SQLException
  {
    checkOpen();
    if (scale < 0 || scale > getConnection().getMaxPrecision()) {
      throw new SQLException("error.generic.badscale", "HY092");
    }

    if (x instanceof BigDecimal) {
      updateObject(columnIndex, ((BigDecimal) x).setScale(scale, BigDecimal.ROUND_HALF_UP));
    } else if (x instanceof Number) {
      synchronized (f) {
        f.setGroupingUsed(false);
        f.setMaximumFractionDigits(scale);
        updateObject(columnIndex, f.format(x));
      }
    } else {
      updateObject(columnIndex, x);
    }
  }

  public String getCursorName() throws SQLException
  {
    checkOpen();

    throw new SQLFeatureNotSupportedException("getCursorName()");

//    if (cursorName != null) {
//      return cursorName;
//    }
//    throw new SQLException("error.resultset.noposupdate", "24000");
  }

  public String getString(int columnIndex) throws SQLException
  {
    Object tmp = getColumn(columnIndex);

    if (tmp instanceof String) {
      return (String) tmp;
    }
    String ret = (String) TypeConversion.convert(this, tmp, java.sql.Types.VARCHAR, getConnection().getCharset());

    return (String) ret;
  }

  public void updateString(int columnIndex, String x) throws SQLException
  {
    setColValue(columnIndex, Types.VARCHAR, x, (x != null) ? x.length() : 0);
  }

  public byte getByte(String columnName) throws SQLException
  {
    if (findColumn(columnName) >= 0) {
      return getByte(findColumn(columnName));
    } else {
      throw new SQLFeatureNotSupportedException(" getByte(String columnName)");
    }
  }

  public double getDouble(String columnName) throws SQLException
  {
    return getDouble(findColumn(columnName));
  }

  public float getFloat(String columnName) throws SQLException
  {
    return getFloat(findColumn(columnName));
  }

  public int findColumn(String columnName) throws SQLException
  {
    checkOpen();

    if (columnName == null) {
      throw new SQLException("error.resultset.nullcolumnname");
    }

    // See if the column is already in the map
    Integer pos = columnMap.get(columnName.toUpperCase());
    if (pos != null) {
      return pos;
    }

    // Not found in map, so search the columns directly.
    if (columns != null) {

      for (int i = 0; i < columns.length; i++) {
        if (columns[i].name.equalsIgnoreCase(columnName)) {
          // Put this mapping into the map for next time.
          columnMap.put(columnName.toUpperCase(), new Integer(i + 1));
          return i + 1;
        }
      }
    }

    // Still not found! Give up!
    throw new SQLException("error.resultset.colname", "07009");
  }

  public int getInt(String columnName) throws SQLException
  {
    return getInt(findColumn(columnName));
  }

  public long getLong(String columnName) throws SQLException
  {
    return getLong(findColumn(columnName));
  }

  public short getShort(String columnName) throws SQLException
  {
    return getShort(findColumn(columnName));
  }

  public void updateNull(String columnName) throws SQLException
  {
    //updateNull(findColumn(columnName));
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public boolean getBoolean(String columnName) throws SQLException
  {
    return getBoolean(findColumn(columnName));
  }

  public byte[] getBytes(String columnName) throws SQLException
  {
    return getBytes(findColumn(columnName));

//    if (columnName == null || columnName.isEmpty()) {
//      throw new SQLFeatureNotSupportedException("getBytes(String columnName)");
//    }
//    int idx = -1;
//    try {
//     idx = findColumn(columnName);
//    } catch (SQLException se) {
//      throw new SQLFeatureNotSupportedException("getBytes(String columnName)", se);
//    }
//    return getBytes(idx);
  }

  public void updateByte(String columnName, byte x) throws SQLException
  {
    //updateByte(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public void updateDouble(String columnName, double x) throws SQLException
  {
    //updateDouble(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public void updateFloat(String columnName, float x) throws SQLException
  {
    updateFloat(findColumn(columnName), x);
  }

  public void updateInt(String columnName, int x) throws SQLException
  {
    if (findColumn(columnName) >= 0) {
      updateInt(findColumn(columnName), x);
    } else {
      throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
    }
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public void updateLong(String columnName, long x) throws SQLException
  {
    //updateLong(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public void updateShort(String columnName, short x) throws SQLException
  {
    //updateShort(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public void updateBoolean(String columnName, boolean x) throws SQLException
  {
    //updateBoolean(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public void updateBytes(String columnName, byte[] x) throws SQLException
  {
    //updateBytes(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateInt(String columnName, int x)");
  }

  public BigDecimal getBigDecimal(int columnIndex) throws SQLException
  {
    return (BigDecimal) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.DECIMAL, null);
  }

  public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException
  {
    BigDecimal result = (BigDecimal) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.DECIMAL, null);

    if (result == null) {
      return null;
    }

    return result.setScale(scale, BigDecimal.ROUND_HALF_UP);
  }

  public void updateBigDecimal(int columnIndex, BigDecimal x)
      throws SQLException
  {
    checkOpen();
    /*
    checkUpdateable();
    if (x != null) {
      int prec = getConnection().getMaxPrecision();
      x = TypeConversion.normalizeBigDecimal(x, prec);
    }
    setColValue(columnIndex, Types.DECIMAL, x, 0);
    */
    throw new SQLFeatureNotSupportedException("updateBigDecimal(int columnIndex, BigDecimal x)");
  }

  public URL getURL(int columnIndex) throws SQLException
  {
    /*
    String url = getString(columnIndex);

    try {
      return new java.net.URL(url);
    } catch (MalformedURLException e) {
      throw new SQLException("error.resultset.badurl", "22000");
    }*/
    throw new SQLFeatureNotSupportedException("getURL(int columnIndex)");
  }

  public Array getArray(int columnIndex) throws SQLException
  {
    checkOpen();
    notImplemented("ResultSet.getArray()");
    return null;
  }

  public void updateArray(int columnIndex, Array x) throws SQLException
  {
    checkOpen();
    //checkUpdateable();

    throw new SQLFeatureNotSupportedException("updateArray(int columnIndex, Array x)");
  }

  public Blob getBlob(int columnIndex) throws SQLException
  {
    return (Blob) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.BLOB, null);
  }

  public void updateBlob(int columnIndex, Blob x) throws SQLException
  {
    if (x == null) {
      updateBinaryStream(columnIndex, null, 0);
    } else {
      updateBinaryStream(columnIndex, x.getBinaryStream(), (int) x.length());
    }
    throw new SQLFeatureNotSupportedException("updateBlob(int columnIndex, Blob x)");
  }

  public Clob getClob(int columnIndex) throws SQLException
  {
    return (Clob) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.CLOB, null);
  }

  public void updateClob(int columnIndex, Clob x) throws SQLException
  {
    if (x == null) {
      updateCharacterStream(columnIndex, null, 0);
    } else {
      updateCharacterStream(columnIndex, x.getCharacterStream(), (int) x.length());
    }
    throw new SQLFeatureNotSupportedException("updateClob(int columnIndex, Clob x)");
  }

  public Date getDate(int columnIndex) throws SQLException
  {
    return (java.sql.Date) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.DATE, null);
  }

  public void updateDate(int columnIndex, Date x) throws SQLException
  {
    setColValue(columnIndex, Types.DATE, x, 0);
  }

  public Ref getRef(int columnIndex) throws SQLException
  {
    checkOpen();
    notImplemented("ResultSet.getRef()");

    return null;
  }

  public void updateRef(int columnIndex, Ref x) throws SQLException
  {
    checkOpen();
    notImplemented("ResultSet.updateRef()");
    checkUpdateable();
  }

  public ResultSetMetaData getMetaData() throws SQLException
  {
    checkOpen();

    // If this is a DatabaseMetaData built result set, avoid getting an
    // exception because the statement is closed and assume no LOBs
    boolean useLOBs = !(this instanceof CachedResultSet && statement.isClosed()) && getConnection().getUseLOBs();
    return new JdbcResultSetMetaData(columns, visibleColumnCount, useLOBs);
  }

  public SQLWarning getWarnings() throws SQLException
  {
    checkOpen();

    return statement.getWarnings();
  }

  public Statement getStatement() throws SQLException
  {
    checkOpen();

    return statement;
  }

  public Time getTime(int columnIndex) throws SQLException
  {
    return (java.sql.Time) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.TIME, null);
  }

  public void updateTime(int columnIndex, Time x) throws SQLException
  {
    setColValue(columnIndex, Types.TIME, x, 0);
  }

  public Timestamp getTimestamp(int columnIndex) throws SQLException
  {
    return (Timestamp) TypeConversion.convert(this, getColumn(columnIndex), java.sql.Types.TIMESTAMP, null);
  }

  public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException
  {
    setColValue(columnIndex, Types.TIMESTAMP, x, 0);
  }

  public InputStream getAsciiStream(String columnName) throws SQLException
  {
    return getAsciiStream(findColumn(columnName));
  }

  public InputStream getBinaryStream(String columnName) throws SQLException
  {
    return getBinaryStream(findColumn(columnName));
  }

  public InputStream getUnicodeStream(String columnName) throws SQLException
  {
    //return getUnicodeStream(findColumn(columnName));
    throw new SQLFeatureNotSupportedException("getUnicodeStream(String columnName)");
  }

  public void updateAsciiStream(String columnName, InputStream x, int length)
      throws SQLException
  {
    //updateAsciiStream(findColumn(columnName), x, length);
    throw new SQLFeatureNotSupportedException("updateAsciiStream(String columnName, InputStream x, int length)");
  }

  public void updateBinaryStream(String columnName, InputStream x, int length)
      throws SQLException
  {
    updateBinaryStream(findColumn(columnName), x, length);
  }

  public Reader getCharacterStream(String columnName) throws SQLException
  {
    return getCharacterStream(findColumn(columnName));
  }

  public void updateCharacterStream(String columnName, Reader x, int length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateCharacterStream");
    //updateCharacterStream(findColumn(columnName), x, length);
  }

  public Object getObject(String columnName) throws SQLException
  {
    return getObject(findColumn(columnName));
  }

  public void updateObject(String columnName, Object x) throws SQLException
  {
    updateObject(findColumn(columnName), x);
  }

  public void updateObject(String columnName, Object x, int scale)
      throws SQLException
  {
    updateObject(findColumn(columnName), x, scale);
  }

  public Object getObject(int columnIndex, Map map) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("ResultSet.getObject(int, Map)");
    //notImplemented("ResultSet.getObject(int, Map)");
    //return null;
  }

  public String getString(String columnName) throws SQLException
  {
    return getString(findColumn(columnName));
  }

  public void updateString(String columnName, String x) throws SQLException
  {
    updateString(findColumn(columnName), x);
  }

  public BigDecimal getBigDecimal(String columnName) throws SQLException
  {
    return getBigDecimal(findColumn(columnName));
  }

  public BigDecimal getBigDecimal(String columnName, int scale)
      throws SQLException
  {
    return getBigDecimal(findColumn(columnName), scale);
  }

  public void updateBigDecimal(String columnName, BigDecimal x)
      throws SQLException
  {
    updateObject(findColumn(columnName), x);
  }

  public URL getURL(String columnName) throws SQLException
  {
    //return getURL(findColumn(columnName));
    throw new SQLFeatureNotSupportedException("getURL(String columnName)");
  }

  public Array getArray(String columnName) throws SQLException
  {
    return getArray(findColumn(columnName));
  }

  public void updateArray(String columnName, Array x) throws SQLException
  {
    //updateArray(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateArray(String columnName, Array x)");
  }

  public Blob getBlob(String columnName) throws SQLException
  {
    return getBlob(findColumn(columnName));
  }

  public void updateBlob(String columnName, Blob x) throws SQLException
  {
    updateBlob(findColumn(columnName), x);
  }

  public Clob getClob(String columnName) throws SQLException
  {
    return getClob(findColumn(columnName));
  }

  public void updateClob(String columnName, Clob x) throws SQLException
  {
    updateClob(findColumn(columnName), x);
  }

  public Date getDate(String columnName) throws SQLException
  {
    return getDate(findColumn(columnName));
  }

  public void updateDate(String columnName, Date x) throws SQLException
  {
    //updateDate(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateDate(String columnName, Date x)");
  }

  public Date getDate(int columnIndex, Calendar cal) throws SQLException
  {
    checkOpen();

    // First, get the date as a timestamp. If the column genuinely is a timestamp
    // then we should do all timezone conversions with this full date and time data,
    // otherwise it will be inaccurate.
    java.sql.Timestamp tsp = getTimestamp(columnIndex);

    if (tsp == null) {
      return null;
    }

    // Do any timezone conversion.
    if(cal != null) {
      Date date = TypeConversion.timestampToDateWithZone(tsp, cal);
      return date;
    }

    // All dates should have their time component zeroed out.
    GregorianCalendar localCal = new GregorianCalendar();
    localCal.setTimeInMillis(tsp.getTime());
    localCal.set(Calendar.HOUR, 0);
    localCal.set(Calendar.MINUTE, 0);
    localCal.set(Calendar.SECOND, 0);
    localCal.set(Calendar.MILLISECOND, 0);

    java.sql.Date date = new Date(localCal.getTimeInMillis());
    return date;
  }

  public Ref getRef(String columnName) throws SQLException
  {
    return getRef(findColumn(columnName));
  }

  public void updateRef(String columnName, Ref x) throws SQLException
  {
    //updateRef(findColumn(columnName), x);
    throw new SQLFeatureNotSupportedException("updateRef(String columnName, Ref x)");
  }

  public Time getTime(String columnName) throws SQLException
  {
    return getTime(findColumn(columnName));
  }

  public void updateTime(String columnName, Time x) throws SQLException
  {
    updateTime(findColumn(columnName), x);
  }

  /**
   * Gets the time from the given column and interprets it in the timezone of the
   * parameter cal. Returns a Time object that represents this in the current timezone
   * of the JVM.
   * @param columnIndex
   * @param cal
   * @return
   * @throws SQLException
   */
  public Time getTime(int columnIndex, Calendar cal) throws SQLException
  {
    checkOpen();

    // First, get the time as a timestamp. If the column genuinely is a timestamp
    // then we should do all timezone conversions with this full date and time data,
    // otherwise it will be inaccurate.
    java.sql.Timestamp tsp = getTimestamp(columnIndex);

    if (tsp == null) {
      return null;
    }

    // Do any timezone conversion.
    if(cal != null) {
      Time time = TypeConversion.timestampToTimeWithZone(tsp, cal);
      return time;
    }

    // All times should have their date component zeroed out to the epoch.
    GregorianCalendar localCal = new GregorianCalendar();
    localCal.setTimeInMillis(tsp.getTime());
    localCal.set(Calendar.YEAR, 1970);
    localCal.set(Calendar.MONTH, 0); // zero based
    localCal.set(Calendar.DAY_OF_MONTH, 1);

    java.sql.Time time = new Time(localCal.getTimeInMillis());
    return time;
  }

  public Timestamp getTimestamp(String columnName) throws SQLException
  {
    return getTimestamp(findColumn(columnName));
  }

  public void updateTimestamp(String columnName, Timestamp x)
      throws SQLException
  {
    updateTimestamp(findColumn(columnName), x);
  }

  public Timestamp getTimestamp(int columnIndex, Calendar cal)
      throws SQLException
  {
    checkOpen();
    Timestamp timestamp = getTimestamp(columnIndex);

    if (timestamp != null && cal != null) {
      timestamp = TypeConversion.timestampToZone(timestamp, cal);
    }

    return timestamp;
  }

  public Object getObject(String columnName, Map map) throws SQLException
  {
    return getObject(findColumn(columnName), map);
  }

  public Date getDate(String columnName, Calendar cal) throws SQLException
  {
    return getDate(findColumn(columnName), cal);
  }

  public Time getTime(String columnName, Calendar cal) throws SQLException
  {
    return getTime(findColumn(columnName), cal);
  }

  public Timestamp getTimestamp(String columnName, Calendar cal)
      throws SQLException
  {
    return getTimestamp(findColumn(columnName), cal);
  }

  /////// JDBC4 demarcation, do NOT put any JDBC3 code below this line ///////

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getHoldability()
   */
  public int getHoldability() throws SQLException
  {
    checkOpen();
    return CLOSE_CURSORS_AT_COMMIT;
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getNCharacterStream(int)
   */
  public Reader getNCharacterStream(int columnIndex) throws SQLException
  {
    notImplemented("getNCharacterStream(int columnIndex)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getNCharacterStream(java.lang.String)
   */
  public Reader getNCharacterStream(String columnLabel) throws SQLException
  {
    notImplemented("getNCharacterStream(String columnLabel)");
    return null;
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getNClob(int)
   */
  public NClob getNClob(int columnIndex) throws SQLException
  {
    notImplemented("getNClob(int columnIndex)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getNClob(java.lang.String)
   */
  public NClob getNClob(String columnLabel) throws SQLException
  {
    notImplemented("getNClob(String columnLabel)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getNString(int)
   */
  public String getNString(int columnIndex) throws SQLException
  {
    notImplemented("getNString(int columnIndex)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getNString(java.lang.String)
   */
  public String getNString(String columnLabel) throws SQLException
  {
    notImplemented("getNString(String columnLabel)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getRowId(int)
   */
  public RowId getRowId(int columnIndex) throws SQLException
  {
    notImplemented("getRowId(int columnIndex)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getRowId(java.lang.String)
   */
  public RowId getRowId(String columnLabel) throws SQLException
  {
    notImplemented("getRowId(String columnLabel)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getSQLXML(int)
   */
  public SQLXML getSQLXML(int columnIndex) throws SQLException
  {
    notImplemented("getSQLXML(int columnIndex)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#getSQLXML(java.lang.String)
   */
  public SQLXML getSQLXML(String columnLabel) throws SQLException
  {
    notImplemented("getSQLXML(String columnLabel)");
    return null; // not reached
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateAsciiStream(int, java.io.InputStream)
   */
  public void updateAsciiStream(int columnIndex, InputStream x)
      throws SQLException
  {
    notImplemented("updateAsciiStream(int columnIndex, InputStream x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateAsciiStream(java.lang.String, java.io.InputStream)
   */
  public void updateAsciiStream(String columnLabel, InputStream x)
      throws SQLException
  {
    notImplemented("updateAsciiStream(String columnLabel, InputStream x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateAsciiStream(int, java.io.InputStream, long)
   */
  public void updateAsciiStream(int columnIndex, InputStream x, long length)
      throws SQLException
  {
    notImplemented("updateAsciiStream(int columnIndex, InputStream x, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateAsciiStream(java.lang.String, java.io.InputStream, long)
   */
  public void updateAsciiStream(String columnLabel, InputStream x, long length)
      throws SQLException
  {

    throw new SQLFeatureNotSupportedException("updateAsciiStream");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBinaryStream(int, java.io.InputStream)
   */
  public void updateBinaryStream(int columnIndex, InputStream x)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateBinaryStream(int columnIndex, InputStream x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBinaryStream(java.lang.String, java.io.InputStream)
   */
  public void updateBinaryStream(String columnLabel, InputStream x)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateBinaryStream(String columnLabel, InputStream x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBinaryStream(int, java.io.InputStream, long)
   */
  public void updateBinaryStream(int columnIndex, InputStream x, long length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateBinaryStream(int columnIndex, InputStream x, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBinaryStream(java.lang.String, java.io.InputStream, long)
   */
  public void updateBinaryStream(String columnLabel, InputStream x,
                                 long length) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateBinaryStream(String columnLabel, InputStream x, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBlob(int, java.io.InputStream)
   */
  public void updateBlob(int columnIndex, InputStream inputStream)
      throws SQLException
  {

    throw new SQLFeatureNotSupportedException("updateBlob(int columnIndex, InputStream inputStream)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBlob(java.lang.String, java.io.InputStream)
   */
  public void updateBlob(String columnLabel, InputStream inputStream)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateBlob(String columnLabel, InputStream inputStream)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBlob(int, java.io.InputStream, long)
   */
  public void updateBlob(int columnIndex, InputStream inputStream, long length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateBlob(int columnIndex, InputStream inputStream, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateBlob(java.lang.String, java.io.InputStream, long)
   */
  public void updateBlob(String columnLabel, InputStream inputStream,
                         long length) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateBlob(String columnLabel, InputStream inputStream, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateCharacterStream(int, java.io.Reader)
   */
  public void updateCharacterStream(int columnIndex, Reader x)
      throws SQLException
  {
    notImplemented("updateCharacterStream(int columnIndex, Reader x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateCharacterStream(java.lang.String, java.io.Reader)
   */
  public void updateCharacterStream(String columnLabel, Reader reader)
      throws SQLException
  {
    notImplemented("updateCharacterStream(String columnLabel, Reader reader)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateCharacterStream(int, java.io.Reader, long)
   */
  public void updateCharacterStream(int columnIndex, Reader x, long length)
      throws SQLException
  {
    notImplemented("updateCharacterStream(int columnIndex, Reader x, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateCharacterStream(java.lang.String, java.io.Reader, long)
   */
  public void updateCharacterStream(String columnLabel, Reader reader,
                                    long length) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateCharacterStream(String columnLabel, Reader reader,long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateClob(int, java.io.Reader)
   */
  public void updateClob(int columnIndex, Reader reader) throws SQLException
  {
    notImplemented("updateClob(int columnIndex, Reader reader)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateClob(java.lang.String, java.io.Reader)
   */
  public void updateClob(String columnLabel, Reader reader)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateClob(String columnLabel, Reader reader)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateClob(int, java.io.Reader, long)
   */
  public void updateClob(int columnIndex, Reader reader, long length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateClob(int columnIndex, Reader reader, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateClob(java.lang.String, java.io.Reader, long)
   */
  public void updateClob(String columnLabel, Reader reader, long length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateClob(String columnLabel, Reader reader, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNCharacterStream(int, java.io.Reader)
   */
  public void updateNCharacterStream(int columnIndex, Reader x)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNCharacterStream(int columnIndex, Reader x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNCharacterStream(java.lang.String, java.io.Reader)
   */
  public void updateNCharacterStream(String columnLabel, Reader reader)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNCharacterStream(String columnLabel, Reader reader)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNCharacterStream(int, java.io.Reader, long)
   */
  public void updateNCharacterStream(int columnIndex, Reader x, long length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNCharacterStream(int columnIndex, Reader x, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNCharacterStream(java.lang.String, java.io.Reader, long)
   */
  public void updateNCharacterStream(String columnLabel, Reader reader,
                                     long length) throws SQLException
  {

    throw new SQLFeatureNotSupportedException("updateNCharacterStream");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNClob(int, java.sql.NClob)
   */
  public void updateNClob(int columnIndex, NClob clob) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNClob(int columnIndex, NClob clob)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNClob(java.lang.String, java.sql.NClob)
   */
  public void updateNClob(String columnLabel, NClob clob) throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNClob(String columnLabel, NClob clob)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNClob(int, java.io.Reader)
   */
  public void updateNClob(int columnIndex, Reader reader) throws SQLException
  {

    throw new SQLFeatureNotSupportedException("updateNClob(int columnIndex, Reader reader)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNClob(java.lang.String, java.io.Reader)
   */
  public void updateNClob(String columnLabel, Reader reader)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNClob(String columnLabel, Reader reader)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNClob(int, java.io.Reader, long)
   */
  public void updateNClob(int columnIndex, Reader reader, long length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNClob(int columnIndex, Reader reader, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNClob(java.lang.String, java.io.Reader, long)
   */
  public void updateNClob(String columnLabel, Reader reader, long length)
      throws SQLException
  {
    throw new SQLFeatureNotSupportedException("updateNClob(String columnLabel, Reader reader, long length)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNString(int, java.lang.String)
   */
  public void updateNString(int columnIndex, String string)
      throws SQLException
  {
    notImplemented("updateNString(int columnIndex ,String string)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateNString(java.lang.String, java.lang.String)
   */
  public void updateNString(String columnLabel, String string)
      throws SQLException
  {
    notImplemented("updateNString(String columnLabel, String string)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateRowId(int, java.sql.RowId)
   */
  public void updateRowId(int columnIndex, RowId x) throws SQLException
  {
    notImplemented("updateRowId(int columnIndex, RowId x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateRowId(java.lang.String, java.sql.RowId)
   */
  public void updateRowId(String columnLabel, RowId x) throws SQLException
  {
    notImplemented("updateRowId(String columnLabel, RowId x)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateSQLXML(int, java.sql.SQLXML)
   */
  public void updateSQLXML(int columnIndex, SQLXML xmlObject)
      throws SQLException
  {
    notImplemented("updateSQLXML(int columnIndex, SQLXML xmlObject)");
  }

  /* (non-Javadoc)
   * @see java.sql.ResultSet#updateSQLXML(java.lang.String, java.sql.SQLXML)
   */
  public void updateSQLXML(String columnLabel, SQLXML xmlObject)
      throws SQLException
  {
    notImplemented("updateSQLXML(String columnLabel, SQLXML xmlObject)");
  }

  /* (non-Javadoc)
   * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
   */
  public boolean isWrapperFor(Class arg0) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

  /* (non-Javadoc)
   * @see java.sql.Wrapper#unwrap(java.lang.Class)
   */
  public Object unwrap(Class arg0) throws SQLException
  {
    // TODO Auto-generated method stub
    throw new AbstractMethodError();
  }

  //// JDBC4.1 demarcation, do NOT put any JDBC3/4.0 code below this line ////

  @Override
  public <T> T getObject(int columnIndex, Class<T> classType) throws SQLException
  {
    int jdbcType = TypeHelper.getJdbcTypeFromClass(classType);

    Object obj = TypeConversion.convert(this, getColumn(columnIndex), jdbcType, null);

    if (obj == null) {
      return (T) obj;
    }

    if (classType.isInstance(obj)) {
      return (T) obj;
    }

    // We need to do some manual conversion.
    final String errMsg = "Cannot convert object of type " + obj.getClass().getSimpleName() + " to " + classType.getSimpleName();

    try {
      if (classType == Byte.class || classType == byte.class) {
        // obj should be an Integer, which cannot be dynamically cast to a Byte, so we need to help it.
        obj = ((Number) obj).byteValue();

      } else if (classType == Short.class || classType == short.class) {
        // obj should be an Integer, which cannot be dynamically cast to a Short, so we need to help it.
        obj = ((Number) obj).shortValue();

      } else if (classType == int.class) {
        // obj should be an Integer, which cannot be dynamically cast to a int, so we need to help it.
        obj = ((Number) obj).intValue();

      } else if (classType == Long.class || classType == long.class) {
        // obj should be an Integer, which cannot be dynamically cast to a Long, so we need to help it.
        obj = ((Number) obj).longValue();

      } else if (classType == float.class) {
        // obj should be an Float, which cannot be dynamically cast to a float, so we need to help it.
        obj = ((Number) obj).floatValue();

      } else if (classType == double.class) {
        // obj should be an Double, which cannot be dynamically cast to a double, so we need to help it.
        obj = ((Number) obj).doubleValue();

      } else {
        throw new SQLException(errMsg);
      }

    } catch (ClassCastException e) {
      throw new SQLException(errMsg);
    }

    return (T) obj;
  }

  @Override
  public <T> T getObject(String columnLabel, Class<T> type) throws SQLException
  {
    // TODO Auto-generated method stub
    notImplemented("getObject(String columnLabel, Class<T> type)");
    return null; // never reached
  }
}