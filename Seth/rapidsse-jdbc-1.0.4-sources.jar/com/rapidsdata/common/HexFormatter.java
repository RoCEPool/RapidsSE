// Copyright 2015 Boray Data Co. Ltd.  All rights reserved.

package com.rapidsdata.common;

import java.io.File;
import java.nio.file.Files;

/**
 * Hexadecimal formatting utility.
 */
public class HexFormatter
{
  /**
   * Formats a binary array as hexadecimal and ascii, much like
   * a hex editor would. Outputs 16 bytes per line with byte numbers
   * printed down the first column.
   * @param bytes the array of bytes to print
   * @return a nicely formatted string containing a hexadecimal
   * and ascii representation of the bytes, where each line is
   * < 80 bytes long.
   */
  public static String format(byte[] bytes)
  {
    /*
      Example output:

      0000: 68 6f 73 74 6e 61 6d 65 3d 6c 6f 63 61 6c 68 6f    hostname=localho
      0010: 73 74 0a 70 6f 72 74 3d 32 31 38 32 0a 69 6e 69    st.port=2182.ini
      0020: 74 69 61 6c 44 69 72 3d 2f 72 64 70 0a             tialDir=/rdp.
    */

    if (bytes == null) {
      return "Cannot hex format a null byte array.";
    }

    if (bytes.length == 0) {
      return "Cannot hex format an empty byte array.";
    }

    StringBuilder line = new StringBuilder(bytes.length * 4);

    // How many bytes per line to print.
    final int LENGTH = 16;

    // The output of the binary in hexadecimal and ascii.
    StringBuilder hexLine = new StringBuilder(LENGTH * 3);
    StringBuilder asciiLine = new StringBuilder(LENGTH);

    int counter = 0;

    for (byte b : bytes) {
      int i = b & 0xFF;  // handle negative bytes

      // Byte values < 16 need to be zero padded.
      String paddingZero = (i < 16) ? "0" : "";

      // Convert the byte to hexadecimal.
      hexLine.append(paddingZero)
          .append(Integer.toHexString(i))
          .append(" ");

      // Print the ascii interpretation of the byte if it is >= <space>
      // and <= '~'. Otherwise just print a period character if it
      // is outside of this range.
      char c = (i >= 32 && i <= 126) ? (char) i : '.';
      asciiLine.append(c);

      counter++;

      // Have we printed 16 bytes for the current line?
      if (counter % LENGTH == 0) {
        int byteNum = counter - LENGTH;

        // Write the line, with the byte number in the first column.
        line.append(String.format("%04x", byteNum));
        line.append(": ");

        line.append(hexLine);
        line.append("   ");
        line.append(asciiLine);
        line.append("\n");

        hexLine.setLength(0);
        asciiLine.setLength(0);
      }
    }

    // No more bytes, but is there a partial line that we need to print?
    if (asciiLine.length() < LENGTH) {

      int byteNum = counter - asciiLine.length();

      line.append(String.format("%04x", byteNum));
      line.append(": ");

      line.append(hexLine);

      for (int i = asciiLine.length(); i <= LENGTH; i++) {
        line.append("   ");
      }

      line.append(asciiLine);
      line.append("\n");
    }

    // The string containing the hex-formatted bytes.
    return line.toString();
  }

  /**
   * For testing.
   * @param args the path to the file to read in.
   * @throws Exception
   */
  public static void main(String[] args) throws Exception
  {
    if (args.length < 1) {
      System.err.println("Missing argument 1 - path to the file to print.");
      System.exit(1);
    }

    File f = new File(args[0]);
    byte[] bytes = Files.readAllBytes(f.toPath());

    String s = format(bytes);
    System.out.print(s);
  }
}
